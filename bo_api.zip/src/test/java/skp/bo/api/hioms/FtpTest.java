package skp.bo.api.hioms;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;

import org.junit.Before;
import org.junit.Test;

import com.sun.net.httpserver.Authenticator.Success;

import skp.bo.api.util.FtpClient;
import skp.bo.api.util.StaticPropertyUtil;

public class FtpTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() throws Exception{

		String realFilePath = "C:\\tmp\\puser\\jirafile\\2017\\0810\\123908\\";
		String realFileNm = "[첨부1] 생활보안 체크리스트.ppt";
		File realFile = new File(realFilePath + realFileNm);
		System.out.println(realFile.getName() + ", " + realFile.exists());

		ftpHioms().storeFile(new FileInputStream(realFile), realFile.getName(), "");
//		ftpSil().storeFile(new FileInputStream(realFile), realFile.getName(), "");

		assertTrue(true);

	}


	public FtpClient ftpHioms() {

		String ftpIp = "203.235.210.94";
		int ftpPort = 21;
		String ftpId = "ftp_oms";
		String ftpPw = "ftpuser!2";
		String ftpRemoteDir = "";
		FtpClient ftp = null;
		try {
			ftp = new FtpClient(ftpIp, ftpPort, ftpId, ftpPw, ftpRemoteDir);
		} catch (Exception e) {
			System.out.println("Ftp Connect Error ");
		}
		return ftp;
	}

	public FtpClient ftpSil() {

		String ftpIp = "10.110.10.61";
		int ftpPort = 21;
		String ftpId = "ftpuser1";
		String ftpPw = "ghkfkdekaqo13!#";
		String ftpRemoteDir = "/SR_ATTACH";
		FtpClient ftp = null;
		try {
			ftp = new FtpClient(ftpIp, ftpPort, ftpId, ftpPw, ftpRemoteDir);
		} catch (Exception e) {
			System.out.println("Ftp Connect Error ");
		}
		return ftp;
	}

}
