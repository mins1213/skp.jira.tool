package skp.bo.api.hioms;

import static org.junit.Assert.*;

import java.io.StringWriter;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.junit.Test;

import skp.bo.api.hioms.Type.HiOmsReqType;
import skp.bo.api.hioms.xml.ReqBaseXml;
import skp.bo.api.hioms.xml.Svci00001;
import skp.bo.api.hioms.xml.Svci00003;
import skp.bo.api.util.StaticPropertyUtil;

public class HiomsTest {


	private String sys_key = "BS3JQAuXgFjGUVo9RGuFMA==";
	private String requestNumber = "I00000267544";
	private String prc_eno = "9999993";


	@Test
	public void ci00001() {

		try {

			Svci00001 ci01 = new Svci00001();
			ci01.setSys_key(sys_key);	//OMS시스템에서 각 연계시스템 별로 발급 한 Key
			ci01.setSvc_id("svci00001");				//요청하고자 하는 연계서비스 아이디
			ci01.setCust_co_cll_no(requestNumber);									//고객사_요청_번호
			ci01.setCll_cust_co_cd("34");		//요청_고객사_코드
			ci01.setCll_cust_co_busi_unt_cd("01");				//요청_고객사_사업_단위_코드
			ci01.setCust_co_apv_no("A"+requestNumber);		//고객사_승인_번호
			ci01.setCll_eno(prc_eno);							//요청_사원번호
			ci01.setOs_cll_tp_cd("6402");			//OS_요청_유형_코드
			ci01.setOs_cll_kind_cd("640205"); 		//OS_요청_종류_코드
			ci01.setCll_dt("20170913"); 												//요청_일자
			ci01.setHope_dt("20171031"); 											//희망_일자
			ci01.setCll_rsn_bdwn("[IT요청관리]작업이 필요한 문서입니다.");			//요청_사유_내역
			ci01.setCll_titl("담당자 데이터 확인 용");								//요청_제목
			ci01.setCll_cntn("작성자 : 테스트"); 							//요청_내용
			ci01.setPrc_cust_co_busi_unt_cd("01"); 				//처리_고객사_사업_단위_코드
			ci01.setPrc_cust_co_cd("34"); 		//처리_고객사_코드

			ReqBaseXml xml = new ReqBaseXml();
			xml.setCi01(new ArrayList<Svci00001>());
			xml.getCi01().add(ci01);

			JAXBContext context = JAXBContext.newInstance(ReqBaseXml.class);
			Marshaller m = context.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
//	        m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);

	     // Write to System.out
	        Writer writer = new StringWriter();
	        m.marshal(xml, writer);

			String strInParam = writer.toString();
//			strInParam = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + strInParam;
			System.out.println(strInParam);
//				"<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
//				"<request>"+
//				"<dataSet>"+
//				"	<fields>"+
//				"	<sys_key><![CDATA[BS3JQAuXgFjGUVo9RGuFMA==]]></sys_key>"+
//				"	<svc_id><![CDATA[svci00001]]></svc_id>"+
//				"	<sc_strt_dt><![CDATA[20130116]]></sc_strt_dt>"+
//				"  	<sc_end_dt><![CDATA[20130212]]></sc_end_dt>"+
//				"	<sc_cb_cust><![CDATA[34]]></sc_cb_cust>"+
//				"	<sc_prc_yn><![CDATA[E]]></sc_prc_yn>"+
//				"	</fields>"+
//				"</dataSet>"+
//			    "</request>";

			// 웹 서비스 access point 지정
	        String endpoint =
	        "http://203.235.210.94:9280/omwebservice/services/OmWebserviceImpl";

	        // 원격 웹 서비스에 대한 Service 객체 생성후, Call 객체 생성
	        org.apache.axis.client.Service service = new org.apache.axis.client.Service();
	        Call call = (Call) service.createCall();

	        // 입출력 인자정보 및 웹 서비스 access point 를 Call 객체에 바인딩
	        call.setTargetEndpointAddress( new URL(endpoint) );
	        call.setOperationName(
	        		new QName("http://webservice.om.skcc.com","getOmWebservice")  );
	        			call.addParameter("request", XMLType.XSD_STRING, ParameterMode.IN);
	        			call.setReturnType(XMLType.XSD_STRING);

	        // 입력 인자값을 가지고 웹 서비스 호출하여 실행결과 얻어옴
	        String result = (String)call.invoke(new Object[] {new String(strInParam)});

			// 결과값 출력
			System.out.println(result);


		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void ci00003() throws Exception{

		ReqBaseXml xml = new ReqBaseXml();

		Svci00003 ci03 = new Svci00003();
		ci03.setSys_key(sys_key);
		ci03.setSvc_id(HiOmsReqType.SVCI00003_SVCID.getValue());
		ci03.setCust_co_cll_no(requestNumber);
		ci03.setCll_cust_co_cd(HiOmsReqType.CLL_CUST_CO_CD.getValue());		//요청_고객사_코드
		ci03.setIf_sno(HiOmsReqType.IF_SNO.getValue());
		ci03.setPrc_eno(prc_eno);
		ci03.setCtrl_twr_yn("");
		xml.setCi03(new ArrayList<Svci00003>());
		xml.getCi03().add(ci03);

		JAXBContext context = JAXBContext.newInstance(ReqBaseXml.class);
		Marshaller m = context.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        Writer writer = new StringWriter();
        m.marshal(xml, writer);

		String strInParam = writer.toString();
		System.out.println(strInParam);

		// 웹 서비스 access point 지정
        String endpoint = "http://203.235.210.94:9280/omwebservice/services/OmWebserviceImpl";

        // 원격 웹 서비스에 대한 Service 객체 생성후, Call 객체 생성
        org.apache.axis.client.Service service = new org.apache.axis.client.Service();
        Call call = (Call) service.createCall();

        // 입출력 인자정보 및 웹 서비스 access point 를 Call 객체에 바인딩
        call.setTargetEndpointAddress( new URL(endpoint) );
        call.setOperationName(
        		new QName("http://webservice.om.skcc.com","getOmWebservice")  );
        			call.addParameter("request", XMLType.XSD_STRING, ParameterMode.IN);
        			call.setReturnType(XMLType.XSD_STRING);

        // 입력 인자값을 가지고 웹 서비스 호출하여 실행결과 얻어옴
        String result = (String)call.invoke(new Object[] {new String(strInParam)});

		// 결과값 출력
		System.out.println(result);

	}

}
