package skp.bo.api.hioms;

import static org.junit.Assert.*;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;

import skp.bo.api.hioms.xml.Response.ResBaseXml;

public class JaxbTest {

	private String svci01res =
	"<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
	"<response> "+
		"<transaction> "+
			"<id>skcc.om.EXTIF.EXTIFMgr#svci00001</id>    "+
			"<startDate>2017-08-10T11:28:50.621</startDate>  "+
			"<endDate>2017-08-10T11:28:50.723</endDate> "+
		"</transaction>  "+
		"<dataSet>   "+
			"<message>     "+
				"<result>FAIL</result>     "+
				"<messageId>SKEX9001</messageId>  "+
				"<messageName>쿼리 수행 도중 에러가 발생하였습니다. 쿼리 확인 필요.</messageName>    "+
				"<messageReason></messageReason>"+
				"<messageRemark></messageRemark>  "+
			"</message>    "+
			"<fields>      "+
				"<reqtNo>EXT-000046-00001-0016754</reqtNo>   "+
			"</fields>  "+
		"</dataSet>"+
	"</response> ";

	@Test
	public void testUnMarshall() throws Exception{

//		Unmarshaller um = JAXBContext.newInstance(ResBaseXml.class).createUnmarshaller();

//		ResBaseXml xmlVO = (ResBaseXml)um.unmarshal(new StringReader(svci01res));

		ResBaseXml xmlVO = (ResBaseXml)unmarshaller(svci01res, new ResBaseXml());
		System.out.println(xmlVO.getTransaction().getId());

	}

	public Object unmarshaller(String xml, Object clxz) throws Exception{

		Unmarshaller um = JAXBContext.newInstance(clxz.getClass()).createUnmarshaller();

		Object rtn = (Object)um.unmarshal(new StringReader(xml));

		return rtn;
	}

}
