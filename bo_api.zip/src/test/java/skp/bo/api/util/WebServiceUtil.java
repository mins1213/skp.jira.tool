package skp.bo.api.util;

import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import skp.bo.api.http.BoResponseErrorHandler;
import skp.bo.api.util.StaticPropertyUtil;

public class WebServiceUtil {

	public static void main(String[] args) {

		sendRequest("ITREQ-17");
	}

	public static boolean sendRequest(String ticketKey){

		String reqTicketInfoUrl = "http://172.21.40.31:8090/api/jira/send/transition/"+ticketKey;

		RestTemplate restTemplate = new RestTemplate();

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);

        ResponseEntity<Map> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.GET, null, Map.class);
        Boolean rst = (Boolean)responseEntity.getBody().get("result");
        System.out.println(rst);
		return true;
	}

}
