package skp.bo.api.util;

import static org.junit.Assert.*;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.junit.Test;

public class FtpClientTest {

	@Test
	public void test() {

		/*
		 * hioms.ftp.ip=203.235.210.94
hioms.ftp.port=21
hioms.ftp.id=ftp_oms
hioms.ftp.pw=ftpuser!2

silhouette.ip=10.110.10.61
silhouette.port=8001
silhouette.ws.url=http://nxmscm.okcashbag.com:8001/soap
#devlopment : test, real : prod
silhouette.pActionType=test
silhouette.ftp.port=21
silhouette.ftp.id=ftpuser1
silhouette.ftp.pw=ghkfkdekaqo13!#
silhouette.ftp.upload.dir=/SR_ATTACH
		 */
		String ip = "10.110.10.61";
		int port = 21;
		String id = "ftpuser1";
		String pw = "ghkfkdekaqo13!#";
		String remoteDir = "/SR_ATTACH/IT요청관리";

//		String ip = "10.40.29.50";
//		int port = 21;
//		String id = "appuser";
//		String pw = "5*bssapp$0";
//		String remoteDir = "/home/appuser/tmp0";


		File targetFile = new File("c:\\Temp\\0\\upload_test.txt");
		System.out.println(targetFile.exists());
		System.out.println(targetFile.getName());

		try {
			FtpClient ftp = new FtpClient(ip, port, id, pw, "/SR_ATTACH");

			ftp.storeFile(new FileInputStream(targetFile), targetFile.getName(), "");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		assertTrue(true);
	}

}
