package skp.bo.api.http;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestClientException;

public class BoResponseErrorHandler implements ResponseErrorHandler{

	private static final Logger logger = LoggerFactory.getLogger(BoResponseErrorHandler.class);

	private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();


	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {

		if(!response.getStatusCode().is2xxSuccessful()){
			logger.error("Response Error status code : {}" , response.getStatusCode());
			logger.error("Response Error status msg: {}" , response.getStatusText());
			Scanner s = new Scanner(response.getBody()).useDelimiter("\\A");
			String result = s.hasNext() ? s.next() : "";
			logger.error("Response Error body: {}" , result);
			if(StringUtils.isNotEmpty(result)){
				if(result.length() > 4000){
					result = result.substring(0, 3900);
				}
			}
			response.getHeaders().add("error_body_string", result);
		}

//		return errorHandler.hasError(response);
		return false;
	}

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {

		List<String> header = response.getHeaders().get("x-app-err-id");

		String errorMsgId = "";
		if(header != null){
			errorMsgId = header.get(0);
		}

		try {
			errorHandler.handleError(response);
		} catch (RestClientException e) {
			logger.error(errorMsgId, e);
		}

	}}
