package skp.bo.api.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.apache.commons.lang.CharSet;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.commons.net.ftp.FTPReply;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.nio.cs.ext.EUC_KR;

/**
 *  FTP 전송 유틸
 *
 * @author fw
 * @see
 * @since
 **/
public class FtpClient  {
	private static final Logger logger = LoggerFactory.getLogger(FtpClient.class);

	private String ftpHost;// ftp ip address
	private int ftpPort; // ftp port
	private String userId; // ftp user id
	private String password; // ftp password
	private String rootDir; // ftp 초기 접속 디렉토리

	public FtpClient(String ftpHost, int ftpPort, String userId, String password, String rootDir) {
		this.ftpHost = ftpHost;
		this.ftpPort = ftpPort;
		this.userId = userId;
		this.password = password;
		this.rootDir = rootDir;
	}

	public String getFtpHost() {
		return ftpHost;
	}

	public void setFtpHost(String ftpHost) {
		this.ftpHost = ftpHost;
	}

	public int getFtpPort() {
		return ftpPort;
	}

	public void setFtpPort(int ftpPort) {
		this.ftpPort = ftpPort;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRootDir() {
		return rootDir;
	}

	public void setRootDir(String rootDir) {
		this.rootDir = rootDir;
	}

	/**
	 * ftp로 해당파일을 저장
	 *
	 */
	public boolean storeFile(InputStream inputStream, String targetFileName, String dir) throws Exception {
		FTPClient ftp = new FTPClient();

		try {

			ftp = connect();

            ftp.setFileType(FTP.BINARY_FILE_TYPE);
			ftp.setFileTransferMode(FTP.STREAM_TRANSFER_MODE);
			Charset charset = ftp.getCharset();

			logger.info("working dir : {} , charset : {}",ftp.printWorkingDirectory(), ftp.getCharset().name());

			boolean result = false;
			String[] tempSaveDir = dir.split("[/]");
			for(String temp:tempSaveDir) {
    			result = ftp.changeWorkingDirectory(temp);
    			logger.info("ftp change dir {} , dir is {}", result, temp );
			    if (!result) {
	             //하위디렉토리 생성
			    	result = ftp.makeDirectory(temp);
                    logger.info("ftp make dir----------------" + result);
                    result = ftp.changeWorkingDirectory(temp);
                    logger.info("ftp change dir2---------------" + result);
                }
			}
			logger.info("working dir : {} , charset : {}",ftp.printWorkingDirectory(), charset.name());
			String tmpFileNm = new String(targetFileName.getBytes("utf-8"), "iso_8859_1");
			result = ftp.storeFile(tmpFileNm, inputStream);

			logger.info("ftp store file----------------{}", result);

			ftp.logout();

		} catch (IOException e) {
			logger.error("ftp IOexception", e);
			return false;
		} catch (Exception e) {
			logger.error("ftp exception", e);
			return false;
		} finally {
			disconnect(ftp);
		}
		return true;
	}


	/**
	 * ftp로 해당파일을 읽어옴
	 *
	 * @return
	 */
	public InputStream retrieveFile(String fileName, String dir, String subDir, java.io.OutputStream os) throws Exception {
		FTPClient ftp = null;
		InputStream is = null;
		try {
			ftp = connect();
			if (ftp == null) {
				logger.error("ftp connection error-retrieveFile brncd="
						+ subDir);
				return null;
			}
			ftp.changeWorkingDirectory(dir);
			ftp.changeWorkingDirectory(subDir);
			if (os == null)
				is = new java.io.BufferedInputStream(
						ftp.retrieveFileStream(fileName), ftp.getBufferSize());
			else
				ftp.retrieveFile(fileName, os);
			ftp.logout();
		} catch (IOException e) {
			logger.error("ftp ioexception", e);
			return null;
		} catch (Exception e) {
			logger.error("ftp exception", e);
			return null;
		} finally {
			disconnect(ftp);
		}
		return is;
	}

	/**
	 * ftp접속후 파일을 삭제
	 *
	 * @param fileName
	 *            대상파일명
	 * @param dir
	 *            저장된 디렉토리 상위 폴더명
	 * @param subDir
	 *            저장된 디렉토리 하위폴더명
	 * @return
	 */
	public boolean deleteFile(String fileName, String dir, String subDir)
			throws Exception {
		FTPClient ftp = null;
		boolean result = true;
		try {
			ftp = connect();
			if (ftp == null) {
				logger.error("ftp connection error - deleteFile brncd="
						+ subDir + " fileName=" + fileName);
				return false;
			}
			ftp.changeWorkingDirectory(dir);
			ftp.changeWorkingDirectory(subDir);
			result = ftp.deleteFile(fileName);
			logger.info("ftp:: delete result =[" + result + "] brncd=" + subDir
					+ " fileName=" + fileName);
			ftp.logout();
		} catch (IOException e) {
			logger.error("ftp ioexception", e);
			return false;
		} catch (Exception e) {
			logger.error("ftp exception", e);
			return false;
		} finally {
			disconnect(ftp);
		}
		return result;
	}

	/**
	 * ftp 접속
	 *
	 * @param ftp
	 * @return
	 */
	protected FTPClient connect(String ip, int port, String id, String pw, String rootDir) throws Exception {
		FTPClient ftp = new FTPClient();
		try {
			int reply;
			FTPClientConfig conf = new FTPClientConfig(FTPClientConfig.SYST_NT);
			ftp.configure(conf);

			ftp.connect(ip, port);
			logger.info("ftp.getReplyString()=" + ftp.getReplyString());

			reply = ftp.getReplyCode();
			logger.info("FTP Reply Code is : {}", reply);
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				logger.error("FTP server refused connection.");
				return null;
			}
			boolean isLogin = ftp.login(id, pw);
			if (!isLogin) {
				logger.error("login error");
				return null;
			}
			// ftp.setFileTransferMode(FTP.BINARY_FILE_TYPE);
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
			ftp.enterLocalPassiveMode();
			if (rootDir != null)
				ftp.changeWorkingDirectory(rootDir);// "/fsdata");

			return ftp;
		} catch (Exception e) {
			logger.error("ftp connection exception :", e);
			return null;
		}
	}

	/**
	 * properties값으로 (fw.properties) ftp접속
	 *
	 * @param ftp
	 * @return
	 * @throws CryptoException
	 */
	protected FTPClient connect() throws Exception {

		String ip = this.getFtpHost();
		int port = this.getFtpPort();
		String id = this.getUserId();
		String pw = this.getPassword();
		String rootDir = this.getRootDir();

		return connect(ip, port, id, pw, rootDir);
	}

	/**
	 * ftp 접속해제
	 *
	 * @param ftp
	 */
	private void disconnect(FTPClient ftp) {
		if (ftp.isConnected()) {
			try {
				ftp.disconnect();
			} catch (IOException ioe) {
				logger.error(ioe.getMessage());
				// do nothing
			}
		}
		logger.info("disconnected");
	}

	public static void main(String[] args) throws Exception{

		String ip = "10.110.10.61";
		int port = 21;
		String id = "ftpuser1";
		String pw = "ghkfkdekaqo13!#";
		String remoteDir = "/SR_ATTACH";


		File targetFile = new File("c:\\Temp\\0\\upload_test.txt");

		System.out.println(targetFile.exists());

		try {
			FtpClient ftp = new FtpClient(ip, port, id, pw, "");

			ftp.storeFile(new FileInputStream(targetFile), targetFile.getName(), remoteDir);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
