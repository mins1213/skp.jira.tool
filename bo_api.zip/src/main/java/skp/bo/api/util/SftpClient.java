package skp.bo.api.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SftpClient {

	private static final Logger logger = LoggerFactory.getLogger(SftpClient.class);

	private String ftpHost;// ftp ip address
	private int ftpPort; // ftp port
	private String userId; // ftp user id
	private String password; // ftp password
	private String remoteDir; // ftp remote 디렉토리

	public SftpClient(String ftpHost, int ftpPort, String userId, String password, String remoteDir) {
		this.ftpHost = ftpHost;
		this.ftpPort = ftpPort;
		this.userId = userId;
		this.password = password;
		this.remoteDir = remoteDir;
	}

	private Session session = null;
	private Channel channel = null;
	private ChannelSftp channelSftp = null;

	// SFTP 서버연결
	public void init() {
		String url = this.getFtpHost();
		Integer port = this.getFtpPort();
		String user = this.getUserId();
		String password = this.getPassword();

		System.out.println(url);
		// JSch 객체 생성
		com.jcraft.jsch.JSch jsch = new com.jcraft.jsch.JSch();
		try {
			// 세션객체 생성 ( user , host, port )
			session = jsch.getSession(user, url, port);
			// password 설정
			session.setPassword(password);

			// 세션관련 설정정보 설정
			java.util.Properties config = new java.util.Properties();

			// 호스트 정보 검사하지 않는다.
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);

			// 접속
			session.connect();

			// sftp 채널 접속
			channel = session.openChannel("sftp");
			channel.connect();

		} catch (JSchException e) {
			e.printStackTrace();
			logger.error("SFTP connect Error! \n", e.getCause());
		}
		channelSftp = (ChannelSftp) channel;
		logger.info("SFtp connect OK. Dest is {}:{} ", url, port);
	}

	// 단일 파일 업로드
	public void upload(File file) {

		init();
		String dir = this.getRemoteDir();
		FileInputStream in = null;
		logger.info("SFTP Upload Target File : {}", file.getAbsolutePath());
		try { // 파일을 가져와서 inputStream에 넣고 저장경로를 찾아 put
			in = new FileInputStream(file);
			channelSftp.cd(dir);
			channelSftp.put(in, file.getName());
		} catch (SftpException se) {
			se.printStackTrace();
			logger.error("SFTP file upload Error! \n", se.getCause());
		} catch (FileNotFoundException fe) {
			fe.printStackTrace();
			logger.error("SFTP File Not Found Error! \n", fe);
		} finally {
			try {
				in.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
				logger.error("SFTP IOException \n", ioe);
			}
			disconnect();
		}
	}

	// 파일서버와 세션 종료
    public void disconnect(){
        channelSftp.quit();
        session.disconnect();
        logger.info("SFTP is disconnected.");
    }






	public String getFtpHost() {
		return ftpHost;
	}

	public void setFtpHost(String ftpHost) {
		this.ftpHost = ftpHost;
	}

	public int getFtpPort() {
		return ftpPort;
	}

	public void setFtpPort(int ftpPort) {
		this.ftpPort = ftpPort;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRemoteDir() {
		return remoteDir;
	}

	public void setRemoteDir(String remoteDir) {
		this.remoteDir = remoteDir;
	}

	public static void main(String[] args) {

		String url = "10.40.29.50";
		String user = "appuser";
		String password = "5*bssapp$0";
		String localFile = "c:\\tmp\\1한글.txt";
		String remoteDir = "/home/appuser/msg";

		SftpClient sftp = new SftpClient(url, 22, user, password, remoteDir);

		sftp.upload(new File(localFile));

	}

}
