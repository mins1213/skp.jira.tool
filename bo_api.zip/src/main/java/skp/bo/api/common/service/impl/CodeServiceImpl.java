package skp.bo.api.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import skp.bo.api.common.mapper.CodeMapper;
import skp.bo.api.common.service.CodeService;
import skp.bo.api.common.vo.Code;

@Service("skp.bo.api.common.service.CodeService")
public class CodeServiceImpl implements CodeService{

	@Autowired
	CodeMapper mapper;

	@Override
	public Code getCodeByName(String parent, String name) throws Exception{

		Code vo =  new Code();
		vo.setParentCodeId(parent);
		vo.setCodeName(name);

		return mapper.selectOne(vo);

	}

	@Override
	public Code getCodeById(String parent, String id) throws Exception{

		Code vo =  new Code();
		vo.setParentCodeId(parent);
		vo.setCodeId(id);

		return mapper.selectOne(vo);

	}

}
