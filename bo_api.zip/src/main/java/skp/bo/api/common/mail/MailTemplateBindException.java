package skp.bo.api.common.mail;

public class MailTemplateBindException extends RuntimeException {

	private static final long serialVersionUID = 572122635718247982L;
	
	public MailTemplateBindException(String message) {
		super(message);
	}

}
