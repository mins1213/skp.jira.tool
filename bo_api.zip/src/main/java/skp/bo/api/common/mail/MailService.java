package skp.bo.api.common.mail;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import skp.bo.api.util.StaticPropertyUtil;

public class MailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MailService.class);

	public static Integer sendMail(List<MailProperties> list) {
		int successCount = 0;
		int failCount = 0;
		LOGGER.info("메일 전송 건 수 : " + list.size());
		for (MailProperties item : list) {

			if (mailing(item)) {
				successCount++;
			} else {
				failCount++;
			}
		}
		LOGGER.info("Success Count : " + successCount);
		LOGGER.info("Fail Count : " + failCount);
		return successCount;
	}

	public static Boolean sendMail(MailProperties item) {
		try {

			return mailing(item);
		} catch (RuntimeException e) {
			return false;
		}
	}

	private static Boolean mailing(MailProperties item) {

		Properties props = new Properties();
//		props.put("mail.smtp.starttls.enable","true");
		props.put("mail.smtp.host", StaticPropertyUtil.getProperty("ibas.mail.smtp.ip"));
//		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", StaticPropertyUtil.getProperty("ibas.mail.smtp.port"));

//		Session session = Session.getDefaultInstance(props,
//				new javax.mail.Authenticator() {
//					protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
//						return new javax.mail.PasswordAuthentication(username, password);
//					}
//				});
		Session session = Session.getDefaultInstance(props);

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(item.getFrom()));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(item.getTo()));
			if(item.getCc() != null){
				message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(Arrays.toString(item.getCc())));
			}
			message.setSubject(item.getSubject());
			message.setContent(item.getMainText(), "text/html; charset=utf-8");
			Transport.send(message);
		} catch (MessagingException e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}
		return true;
	}

}
