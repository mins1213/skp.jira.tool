package skp.bo.api.common.mapper;

import skp.bo.api.common.vo.Code;

public interface CodeMapper {

	public Code selectOne(Code code) throws Exception;
}
