package skp.bo.api.common.mail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import skp.bo.api.util.StaticPropertyUtil;

public class MailTemplate {

	private static final Logger LOGGER = LoggerFactory.getLogger(MailTemplate.class);


	public static String getTemplate(String fileName) throws IOException {

		String filePath = StaticPropertyUtil.getProperty("ibas.bo.api.mail.template.path")+ fileName;

		LOGGER.info("filePath : " + filePath);
		File file = new File(filePath);

		StringBuffer stringBuffer = new StringBuffer();
		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"));

			String temp = null;
			while ((temp = bufferedReader.readLine()) != null) {
				stringBuffer.append(temp);
			}
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			LOGGER.error(e.getMessage(), e);
			throw new MailTemplateGenerateException(e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new MailTemplateGenerateException(e.getMessage());
		} finally {
			if(bufferedReader != null) bufferedReader.close();
		}

		return stringBuffer.toString();
	}

	public static String setTemplateValue(String template, Object valueObject) {
		Pattern pattern = Pattern.compile("#\\{[^\\s.]+\\}");
		Matcher matcher = pattern.matcher(template);

		String reaultTemplate = new String(template);
		try {
			while (matcher.find()) {
				String variableName = matcher.group().replaceAll("[#\\{\\}]", "");
				String replaceValue = getObjectValue(variableName, valueObject);

				reaultTemplate = reaultTemplate.replaceAll("#\\{" + variableName + "\\}", replaceValue);
			}
		} catch (SecurityException | IllegalArgumentException e) {
			LOGGER.error(e.getMessage(), e);
			throw new MailTemplateBindException(e.getMessage());
		}

		return reaultTemplate;
	}

	private static String getObjectValue(String variableName, Object data) {
		Pattern pattern = Pattern.compile("^[\\w]{1}");
		Matcher matcher = pattern.matcher(variableName);

		Object value = null;
		try {
			if (matcher.find()) {
				String getMethodName = matcher.replaceAll("get" + matcher.group().toUpperCase());
				Method getMethod = data.getClass().getDeclaredMethod(getMethodName);

				value = getMethod.invoke(data);
			} else {
				LOGGER.error("Replace value is empty!");
				throw new MailTemplateBindException("Replace value is empty!");
			}
		} catch (NoSuchMethodException | SecurityException e) {
			LOGGER.error(e.getMessage(), e);
			throw new MailTemplateBindException(e.getMessage());
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			LOGGER.error(e.getMessage(), e);
			throw new MailTemplateBindException(e.getMessage());
		}
		return value.toString();
	}

	public static String setTemplateValue(String template, Map<String, String> valueMap) {
		Pattern pattern = Pattern.compile("#\\{[^\\s.]+\\}");
		Matcher matcher = pattern.matcher(template);

		String reaultTemplate = new String(template);
		while (matcher.find()) {
			String variableName = matcher.group().replaceAll("[#\\{\\}]", "");
			String replaceValue = valueMap.get(variableName);
			if (replaceValue == null || "".equals(replaceValue)) {
				replaceValue = " ";
			}
			reaultTemplate = reaultTemplate.replaceAll("#\\{" + variableName + "\\}", replaceValue);
		}

		return reaultTemplate;
	}

}
