package skp.bo.api.common.mail;

public class MailTemplateGenerateException extends RuntimeException {

	private static final long serialVersionUID = 6748993489200813114L;

	public MailTemplateGenerateException(String message) {
		super(message);
	}
}
