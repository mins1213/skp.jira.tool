package skp.bo.api.common.service;

import skp.bo.api.common.vo.Code;

public interface CodeService {

	public Code getCodeByName(String parent, String name) throws Exception;

	public Code getCodeById(String parent, String id) throws Exception;

}
