package skp.bo.api.silhouette.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import skp.bo.api.SystemConstant;
import skp.bo.api.hioms.Type.HiOmsReqType;
import skp.bo.api.hioms.mapper.HiOmsMapper;
import skp.bo.api.hioms.vo.HiOmsRequestInfoVO;
import skp.bo.api.hioms.vo.HiOmsUserVO;
import skp.bo.api.hioms.vo.ILMpersonInfoVO;
import skp.bo.api.jira.mapper.JiraTicketMapper;
import skp.bo.api.jira.vo.AttachmentVO;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.silhouette.service.SilhouetteService;
import skp.bo.api.silhouette.type.SilhouetteReqType;
import skp.bo.api.silhouette.vo.NewSrVO;
import skp.bo.api.silhouette.vo.ResponseVO;
import skp.bo.api.silhouette.ws.WebClientUtil;
import skp.bo.api.util.DateUtil;
import skp.bo.api.util.FtpClient;
import skp.bo.api.util.StaticPropertyUtil;

@Service("skp.bo.api.silhouette.service.silhouetteService")
public class SilhouetteServiceImpl implements SilhouetteService {

	private static final Logger logger = LoggerFactory.getLogger(SilhouetteServiceImpl.class);
	private static final Logger ifLog = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_SILHOUET);

	@Autowired
	JiraTicketMapper jiraTicketMapper;

	@Autowired
	HiOmsMapper hiOmsMapper;

	@Override
	public String sendTicketRequestToSilhouette(String ticketId, String corpGubun) throws Exception{

		TicketInfoVO paramSelectTicketInfo = new TicketInfoVO();
        paramSelectTicketInfo.setTicketId(Integer.parseInt(ticketId));
        paramSelectTicketInfo.setCorpGubun(corpGubun);

        TicketInfoVO ticket = jiraTicketMapper.selectTicketInfo(paramSelectTicketInfo);
		List<HiOmsUserVO> omsUserInfo = hiOmsMapper.selectHiOmsUserList(ticket.getAssigneeKey());
		int silYnCnt = 0;
		for (HiOmsUserVO hiOmsUserVO : omsUserInfo) {
			//실루엣 인터페이스 전송자가 있는지 확인
			if("Y".equals(hiOmsUserVO.getSilhouetteYn())){
				silYnCnt++;
			}
		}
		//실루엣 인터페이스 전송자가 1명도 없을 경우 그대로 완료처리
		if(silYnCnt <= 0){
			return null;
		}

		String sRID = SilhouetteReqType.REQUEST_NUM_PREFIX.getValue() + ticket.getCorpGubun() + StringUtils.leftPad(Integer.toString(ticket.getTicketId()), 10, "0");

		/*
		 * 1. 첨부파일 FTP 전송
		 */
		String pAttachFiles = "";
		String seperator = "/";
		AttachmentVO paramSelectAttachmentList = new AttachmentVO();
		paramSelectAttachmentList.setTicketId(Integer.parseInt(ticketId));
		paramSelectAttachmentList.setCorpGubun(corpGubun);
		List<AttachmentVO> attachment = jiraTicketMapper.selectAttachmentList(paramSelectAttachmentList);
        if(attachment.size() > 0){
        	for(int i=0; i < attachment.size(); i++){
        		if(i == attachment.size() - 1)
        			seperator = "";
        		AttachmentVO fileInfo = attachment.get(i);
        		pAttachFiles += fileInfo.getSaveFileName() + seperator;
        		String newFileNm = fileInfo.getSaveFilePath() + sRID + "_" + (i+1);
            	Files.copy(Paths.get(fileInfo.getSaveFilePath() + fileInfo.getSaveFileName()), Paths.get(newFileNm),StandardCopyOption.REPLACE_EXISTING);
            	File realFile = new File(newFileNm);
            	ifLog.info("SILHOUETTE FTP Upload target File : {} , {}",fileInfo.getSaveFilePath()+fileInfo.getSaveFileName(), realFile.getName());

            	if(realFile.exists()){
            		ftp().storeFile(new FileInputStream(realFile), realFile.getName(), "");
            	}else{
            		ifLog.error("SILHOUETTE FTP FILEUPLOAD ERROR. FILE NOT FOUND! API_ATTACHMENT.ATTACH_ID : {}",fileInfo.getAttachId());
            	}

        	}//for(int i=0; i < attachment.size(); i++){ END

        }//if(attachment.size() > 0){ END

//		ILMpersonInfoVO personInfo = hiOmsMapper.selectILMpersonInfo(ticket.getReporterKey());
        String reporterName = ticket.getReporterName().substring(0, ticket.getReporterName().indexOf("/"));
        String reporterDept = ticket.getReporterName().substring(ticket.getReporterName().indexOf("/")+1, ticket.getReporterName().length());

		NewSrVO vo = new NewSrVO();
		vo.setpActionType(StaticPropertyUtil.getProperty("silhouette.pActionType"));
		vo.setpSRID(sRID);
		vo.setpTitle(ticket.getSummary());
		vo.setpDesc(ticket.getDescription());
		if(StringUtils.isEmpty(ticket.getDueDate())){
			vo.setpDueDate(DateUtil.currentTime("yyyy-MM-dd"));
		}else{
			vo.setpDueDate(ticket.getDueDate());
		}
		vo.setpUserName(reporterName);
		vo.setpDeptName(reporterDept);
		vo.setpAttachFiles(pAttachFiles);

		ResponseVO response = WebClientUtil.sendNewSR(vo);

		HiOmsRequestInfoVO hiomsVO = new HiOmsRequestInfoVO();
		hiomsVO.setTicketId(ticket.getTicketId());
    	hiomsVO.setTicketKey(ticket.getTicketKey());
    	hiomsVO.setIfGubun("S");	//인터페이스 구분 : H - hioms, S - 실루엣
    	hiomsVO.setCorpGubun(corpGubun);
    	hiomsVO.setRequestNumber(sRID);
    	if(SilhouetteReqType.REQ_COMPLETED.getValue().equals(response.getReturnCode())){
    		hiomsVO.setRequestSendYn(HiOmsReqType.IF_SEND_COMPLETE.getValue());
		}else{
			hiomsVO.setRequestSendYn(HiOmsReqType.IF_INCOMPLETE.getValue());
		}
    	/*
    	 * request_result_yn 값은 어떻게 처리 할까??
    	 * -> 실루엣 연동 결과 확인은 실루엣 >> hioms 로 넘겨주며 ibas 스케줄러의 hioms 결과확인을 통해서 확인이 가능하다.
    	 */
    	hiomsVO.setRequestSendDay("NOW");
    	hiomsVO.setRequestUserId(ticket.getReporterKey());
    	hiomsVO.setRequestOmsUserId(ticket.getAssigneeKey());
    	hiOmsMapper.insertRequestInfo(hiomsVO);

		return null;

	}

	public FtpClient ftp() {

		String ftpIp = StaticPropertyUtil.getProperty("silhouette.ip");
		int ftpPort = Integer.parseInt(StaticPropertyUtil.getProperty("silhouette.ftp.port"));
		String ftpId = StaticPropertyUtil.getProperty("silhouette.ftp.id");
		String ftpPw = StaticPropertyUtil.getProperty("silhouette.ftp.pw");
		String ftpRemoteDir = StaticPropertyUtil.getProperty("silhouette.ftp.upload.dir");
		FtpClient ftp = null;
		try {
			ftp = new FtpClient(ftpIp, ftpPort, ftpId, ftpPw, ftpRemoteDir);
		} catch (Exception e) {
			ifLog.error("Ftp Connect Error ",e);
		}
		return ftp;
	}

}
