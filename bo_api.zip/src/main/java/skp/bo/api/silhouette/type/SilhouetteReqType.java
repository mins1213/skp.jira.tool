package skp.bo.api.silhouette.type;

public enum SilhouetteReqType {

	REQUEST_NUM_PREFIX("S"),

	IF_SEND_COMPLETE("Y"),
	IF_SEND_INCOMPLETE("N"),
	IF_COMPLETED("Y"),
	IF_INCOMPLETE("N"),
	IF_MSG_FAIL("F"),
	IF_ERROR("E"),
	IF_ERROR_MSG("인터페이스 처리중 에러가 발생 하였습니다"),


	REQ_COMPLETED("1"),
	REQ_INCOMPLETE("미완료"),

	OK("OK");

	private String reqType;

	private SilhouetteReqType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}

}
