package skp.bo.api.silhouette.service;

public interface SilhouetteService {

	public String sendTicketRequestToSilhouette(String ticketId, String corpGubun) throws Exception;

}
