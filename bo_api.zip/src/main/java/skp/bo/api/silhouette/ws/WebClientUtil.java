package skp.bo.api.silhouette.ws;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.MessageFormat;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import skp.bo.api.SystemConstant;
import skp.bo.api.http.BoResponseErrorHandler;
import skp.bo.api.silhouette.vo.NewSrVO;
import skp.bo.api.silhouette.vo.ResponseVO;
import skp.bo.api.util.StaticPropertyUtil;

public class WebClientUtil {

	private static final Logger logger = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_SILHOUET);

	public static ResponseVO sendNewSR(NewSrVO vo) throws Exception {
		logger.info("skp.bo.api.silhouette.ws.WebClientUtil start : {}", vo.getpSRID());

		String url = StaticPropertyUtil.getProperty("silhouette.ws.url");
//		String url = "http://172.22.221.200:8001/soap?service=OpenAPIService";

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));

		restTemplate.setErrorHandler(new BoResponseErrorHandler());
        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_XML);
        reqHeaders.add("SOAPAction", "urn:OpenAPILibrary-OpenAPIService#NewSR");
        String xmlBody = strNewsr(vo);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(xmlBody, reqHeaders);

        logger.info("Silhouette {} IF REQUEST XML : \n{}", vo.getpSRID(), xmlBody);
        ResponseEntity<String> responseEntity = restTemplate.exchange(url,  HttpMethod.POST, requestEntity, String.class);
        logger.info("Silhouette {} IF RESPONSE XML : \n{}", vo.getpSRID(), responseEntity.getBody());

        ResponseVO response = getResponseVo(responseEntity.getBody());

        return response;

	}


	public static String strNewsr(NewSrVO vo){

		String rtn =
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
		+"<soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
		+"<soapenv:Header/>\n"
			+"<soapenv:Body>\n"
				+"<NewSR xmlns=\"urn:OpenAPILibrary-OpenAPIService\">\n"
					+"<pActionType xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{0}]]></pActionType>\n"
					+"<pSRID xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{1}]]></pSRID>\n"
					+"<pTitle xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{2}]]></pTitle>\n"
					+"<pDesc xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{3}]]></pDesc>\n"
					+"<pDueDate xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{4}]]></pDueDate>\n"
					+"<pUserName xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{5}]]></pUserName>\n"
					+"<pDeptName xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{6}]]></pDeptName>\n"
					+"<pAttachFiles xsi:type=\"xsd:string\" xs:type=\"type:string\" xmlns:xs=\"http://www.w3.org/2000/XMLSchema-instance\"><![CDATA[{7}]]></pAttachFiles>\n"
				+"</NewSR>\n"
			+"</soapenv:Body>\n"
		+"</soapenv:Envelope>\n";

		rtn = MessageFormat.format(rtn
				, vo.getpActionType()
				, vo.getpSRID()
				, transSpace(vo.getpTitle())
				, transSpace(vo.getpDesc())
				, vo.getpDueDate()
				, vo.getpUserName()
				, vo.getpDeptName()
				, vo .getpAttachFiles());

		System.out.println(rtn);
		return rtn;

	}

	public static ResponseVO getResponseVo(String xml) throws Exception{

		ResponseVO rtnVO = null;

		if(StringUtils.isNotEmpty(xml)){
			System.out.println(xml);
			String code = xml.substring(xml.indexOf("ReturnCode xsi:type=\"xsd:int\">"), xml.indexOf("</ReturnCode"));
			code = code.substring(code.lastIndexOf(">")+1, code.length());
			String desc = xml.substring(xml.indexOf("ReturnDesc xsi:type=\"xsd:string\">"), xml.indexOf("</ReturnDesc"));
			desc = desc.substring(desc.lastIndexOf(">")+1, desc.length());

			rtnVO = new ResponseVO();
			rtnVO.setReturnCode(code);
			rtnVO.setReturnDesc(desc);

		}

		System.out.println(rtnVO.toString());

		return rtnVO;
	}

	public static void main(String[] args)throws Exception {

		NewSrVO vo = new NewSrVO();
		vo.setpActionType("prod");
		vo.setpSRID("I10000276325");
		vo.setpTitle("인트라넷 개발요청 테스트 티켓 서비스이용료 차감 -> 미차감으로 변경 요청");
		vo.setpDesc("인트라넷 개발요청 테스트 티켓 내용\n\r서비스이용료 차감 -> 미차감으로 변경 요청 서비스이용료 차감 -> 미차감으로 변경 요청");
		vo.setpDueDate("2018-01-30");
		vo.setpUserName("박상헌");
		vo.setpDeptName("BoSS운영팀");
		vo.setpAttachFiles("");

		sendNewSR(vo);
	}

	private static String transSpace(String str) {

		String result = "";

		try {
			String encEuc = URLEncoder.encode(str, "euc-kr");
			encEuc = encEuc.replaceAll("%3F", "+");
			result = URLDecoder.decode(encEuc, "euc-kr");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return result;
	}

}
