package skp.bo.api.silhouette.vo;

public class NewSrVO {

	private String pActionType;
	private String pSRID;
	private String pTitle;
	private String pDesc;
	private String pDueDate;
	private String pUserName;
	private String pDeptName;
	private String pAttachFiles;

	public String getpActionType() {
		return pActionType;
	}
	public void setpActionType(String pActionType) {
		this.pActionType = pActionType;
	}
	public String getpSRID() {
		return pSRID;
	}
	public void setpSRID(String pSRID) {
		this.pSRID = pSRID;
	}
	public String getpTitle() {
		return pTitle;
	}
	public void setpTitle(String pTitle) {
		this.pTitle = pTitle;
	}
	public String getpDesc() {
		return pDesc;
	}
	public void setpDesc(String pDesc) {
		this.pDesc = pDesc;
	}
	public String getpDueDate() {
		return pDueDate;
	}
	public void setpDueDate(String pDueDate) {
		this.pDueDate = pDueDate;
	}
	public String getpUserName() {
		return pUserName;
	}
	public void setpUserName(String pUserName) {
		this.pUserName = pUserName;
	}
	public String getpDeptName() {
		return pDeptName;
	}
	public void setpDeptName(String pDeptName) {
		this.pDeptName = pDeptName;
	}
	public String getpAttachFiles() {
		return pAttachFiles;
	}
	public void setpAttachFiles(String pAttachFiles) {
		this.pAttachFiles = pAttachFiles;
	}



}
