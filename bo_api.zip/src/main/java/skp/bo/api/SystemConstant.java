package skp.bo.api;

public class SystemConstant {

	public static final String IBAS_API_ID = "IbasAPI";
	public static final String LOG4J_LOCATION = "log4j.location";
	public static final String FILE_UPLOAD_DIR = "file.upload.dir";
	public static final String JSON_VIEW = "jsonView";
	public static final String CORP_GUBUN_11ST = "E";	//11번가 Eleven
	public static final String CORP_GUBUN_SKP = "S";	//SK플래닛 S

	public static final String HIOMS_SVCI00001_SVCID = "svci00001";
	public static final String HIOMS_SVCI00002_SVCID = "svci00002";
	public static final String HIOMS_SVCI00003_SVCID = "svci00003";

	public static final String HIOMS_SVCS00001_SVCID = "svcs00001";
	public static final String HIOMS_SVCS00032_SVCID = "svcs00032";

	public static final String HIOMS_REQUEST_NUM_PREFIX = "I";
	public static final String HIOMS_CUST_CO_APV_NO_PREFIX = "A";
	public static final String HIOMS_CLL_CUST_CO_CD = "34";	//고객사_요청_번호
	public static final String HIOMS_CLL_CUST_CO_BUSI_UNT_CD = "01";	//요청_고객사_사업_단위_코드
	public static final String HIOMS_OS_CLL_TP_CD = "6402";	//OS_요청_유형_코드(시스템개선 요청)
	public static final String HIOMS_OS_CLL_KIND_CD = "640205";	//OS_요청_종류_코드
	public static final String HIOMS_CLL_RSN_BDWN = "[IT요청관리]작업이 필요한 문서입니다.";	//요청_사유_내역

	public static final String LOG4J_APPENDER_JIRA = "IF_JIRA_LOG";
	public static final String LOG4J_APPENDER_HIOMS = "IF_HIOMS_LOG";
	public static final String LOG4J_APPENDER_SILHOUET = "IF_SILHOUET_LOG";







}
