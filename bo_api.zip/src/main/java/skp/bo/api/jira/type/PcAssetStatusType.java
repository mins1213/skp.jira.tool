package skp.bo.api.jira.type;

import java.util.HashMap;
import java.util.Map;

public enum PcAssetStatusType {

	장비입고("created"),
	임시직행플로우("161"),
	지급대기("11"),
	반납대기("91"),
	수령확인("71"),
	사용중("81"),
	정기교체대상("131"),
	유휴("101"),
	유휴수령확인("121"),
	폐기대상("141"),
	자산폐기("151"),

	OK("OK");


	private String reqType;

	private PcAssetStatusType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}

	private static final Map<String, PcAssetStatusType> stringToEnum = new HashMap<String, PcAssetStatusType>();
	static{
		for(PcAssetStatusType type : values())
			stringToEnum.put(type.name(), type);
	}

	public static PcAssetStatusType fromString(String string){
		return stringToEnum.get(string);
	}

	private static final Map<String, PcAssetStatusType> stringToEnum2 = new HashMap<String, PcAssetStatusType>();
	static{
		for(PcAssetStatusType type : values())
			stringToEnum2.put(type.getValue(), type);
	}

	public static PcAssetStatusType toValuefromString(String value){
		return stringToEnum2.get(value);
	}
}
