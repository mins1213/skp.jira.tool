package skp.bo.api.jira.vo.pc;

public class OaRequestDtVO {

	private String tagNo;
	private String useName;
	private String requestCodeNm;
	private String requestId;
	private String requestName;
	private String requestDept;
	private String adminId;
	private String adminName;
	private String adminDept;
	private String userId;
	private String userName;
	private String userDept;
	private String machinType;
	private String useLocation;
	private String useLocationDt;
	private String requestCode;
	private String regiTime;
	private String ticketTime;
	private String payMethod;
	private String payDate;
	private String pridSeq;
	private String chgNote;


	public String getTagNo() {
		return tagNo;
	}
	public void setTagNo(String tagNo) {
		this.tagNo = tagNo;
	}
	public String getUseName() {
		return useName;
	}
	public void setUseName(String useName) {
		this.useName = useName;
	}
	public String getRequestCodeNm() {
		return requestCodeNm;
	}
	public void setRequestCodeNm(String requestCodeNm) {
		this.requestCodeNm = requestCodeNm;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getRequestName() {
		return requestName;
	}
	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}
	public String getRequestDept() {
		return requestDept;
	}
	public void setRequestDept(String requestDept) {
		this.requestDept = requestDept;
	}
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminDept() {
		return adminDept;
	}
	public void setAdminDept(String adminDept) {
		this.adminDept = adminDept;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserDept() {
		return userDept;
	}
	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}
	public String getMachinType() {
		return machinType;
	}
	public void setMachinType(String machinType) {
		this.machinType = machinType;
	}
	public String getUseLocation() {
		return useLocation;
	}
	public void setUseLocation(String useLocation) {
		this.useLocation = useLocation;
	}
	public String getUseLocationDt() {
		return useLocationDt;
	}
	public void setUseLocationDt(String useLocationDt) {
		this.useLocationDt = useLocationDt;
	}
	public String getRequestCode() {
		return requestCode;
	}
	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}
	public String getRegiTime() {
		return regiTime;
	}
	public void setRegiTime(String regiTime) {
		this.regiTime = regiTime;
	}
	public String getTicketTime() {
		return ticketTime;
	}
	public void setTicketTime(String ticketTime) {
		this.ticketTime = ticketTime;
	}
	public String getPayMethod() {
		return payMethod;
	}
	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}
	public String getPayDate() {
		return payDate;
	}
	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}
	public String getPridSeq() {
		return pridSeq;
	}
	public void setPridSeq(String pridSeq) {
		this.pridSeq = pridSeq;
	}
	public String getChgNote() {
		return chgNote;
	}
	public void setChgNote(String chgNote) {
		this.chgNote = chgNote;
	}



}
