package skp.bo.api.jira.vo.pc;

public class PcApiVO {

	/*
	 * PC Tag_NO
	 */
	private String tagNo;
	/*
	 * PC Asset 상태값 정의
	 */
	private String machinUseStatus;

	public String getTagNo() {
		return tagNo;
	}
	public void setTagNo(String tagNo) {
		this.tagNo = tagNo;
	}
	public String getMachinUseStatus() {
		return machinUseStatus;
	}
	public void setMachinUseStatus(String machinUseStatus) {
		this.machinUseStatus = machinUseStatus;
	}





}
