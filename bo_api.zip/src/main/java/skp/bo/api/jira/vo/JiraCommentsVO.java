package skp.bo.api.jira.vo;

import java.util.List;

public class JiraCommentsVO {

	private List<JiraCommentVO> comments;

	public List<JiraCommentVO> getComments() {
		return comments;
	}

	public void setComments(List<JiraCommentVO> comments) {
		this.comments = comments;
	}


}
