package skp.bo.api.jira.vo.hook;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class HookIssueVO {

	private String id;
	private String key;
	private String corpGubun;

	private HookFieldsVO fields;



	public String getCorpGubun() {
		return corpGubun;
	}



	public void setCorpGubun(String corpGubun) {
		this.corpGubun = corpGubun;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getKey() {
		return key;
	}



	public void setKey(String key) {
		this.key = key;
	}



	public HookFieldsVO getFields() {
		return fields;
	}



	public void setFields(HookFieldsVO fields) {
		this.fields = fields;
	}



	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
