package skp.bo.api.jira.type;

public enum JiraRequestType {

	TRANSITONS_COMPLETED("31"),

	OK("OK");


	private String reqType;

	private JiraRequestType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}
}
