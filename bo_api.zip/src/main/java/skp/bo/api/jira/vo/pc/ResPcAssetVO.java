package skp.bo.api.jira.vo.pc;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * PC asset 신규생성 시 res
 * @author SONY
 *
 */
//@JsonIgnoreProperties({ "result", "expand"})
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResPcAssetVO {

	//{"id":"296282","key":"ASSET-26","self":"http://172.19.108.59/rest/api/2/issue/296282"}
	private String id;
	private String key;
	private String self;
	private boolean result;

	private PcAssetBasicVO fields;


	public PcAssetBasicVO getFields() {
		return fields;
	}
	public void setFields(PcAssetBasicVO fields) {
		this.fields = fields;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}

	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}



	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE).toString();
	}

}
