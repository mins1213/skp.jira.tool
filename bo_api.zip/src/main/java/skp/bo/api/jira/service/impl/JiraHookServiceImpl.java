package skp.bo.api.jira.service.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import skp.bo.api.SystemConstant;
import skp.bo.api.hioms.mapper.HiOmsMapper;
import skp.bo.api.hioms.service.HiOmsService;
import skp.bo.api.hioms.vo.HiOmsRequestInfoVO;
import skp.bo.api.hioms.vo.HiOmsUserVO;
import skp.bo.api.http.BoResponseErrorHandler;
import skp.bo.api.jira.mapper.JiraTicketMapper;
import skp.bo.api.jira.mapper.PcMapper;
import skp.bo.api.jira.service.AssetService;
import skp.bo.api.jira.service.JiraHookService;
import skp.bo.api.jira.type.JiraResponseType;
import skp.bo.api.jira.vo.AttachmentVO;
import skp.bo.api.jira.vo.JiraAttachmentVO;
import skp.bo.api.jira.vo.JiraCommentVO;
import skp.bo.api.jira.vo.JiraCommonVO;
import skp.bo.api.jira.vo.TicketCommentVO;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.jira.vo.hook.HookBasicVO;
import skp.bo.api.jira.vo.hook.HookFieldsVO;
import skp.bo.api.jira.vo.hook.HookIssueVO;
import skp.bo.api.jira.vo.pc.PcVO;
import skp.bo.api.silhouette.service.SilhouetteService;
import skp.bo.api.util.StaticPropertyUtil;

@Service
public class JiraHookServiceImpl implements JiraHookService{

	private static final Logger logger = LoggerFactory.getLogger(JiraHookServiceImpl.class);
	private static final Logger ifLog = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_JIRA);

	@Autowired
	JiraTicketMapper jiraTicketMapper;

	@Autowired
	HiOmsMapper hiOmsMapper;

	@Autowired
	PcMapper pcMapper;

	@Autowired
	HiOmsService hiOmsService;

	@Autowired
	SilhouetteService silhouetteService;

	@Autowired
	AssetService assetService;

	@Override
	@Transactional
	public void requestJiraTicketInfo(HookBasicVO hookBasicVO) throws Exception{

		ifLog.info("PROCESS JIRA HOOK TICKET KEY : " + hookBasicVO.getIssue().getKey());
		logger.info("PROCESS JIRA HOOK TICKET KEY : " + hookBasicVO.getIssue().getKey());

		String corpGubun = hookBasicVO.getIssue().getCorpGubun();

        /*
         * 1. 티켓 기본 정보 등록
         */
        TicketInfoVO paramTicketInfoVO = setBasicTicketInfo(hookBasicVO);


        /*
         * PC asset용 프로세스
         * 1. 장비교체, 장비반납 SR 티켓이 '작업중' 상태일때 대상OA asset의 상태를 '반납대기'로 변경한다
         * OA asset 임시저장 로직 신규로 인해 기능 막음
         */
//        if(paramTicketInfoVO.getDivision().startsWith("OA"))
//        	assetService.processOAasset(paramTicketInfoVO);

        /*
         * SW asset용 프로세스
         * 1. division이 SW사용신청 이고 티켓 status가  작업중 일때 요청 SW를 설치확인 으로 변경 (신청자에게 설치방법 안내 메일발송 로직추가)
         * 2. division이 SW반납신청 일때 티켓이 들어오자마자 반납 요청 SW Asset를 사용중 >> 반납대기 로 변경.
         */

        if(paramTicketInfoVO.getDivision().startsWith("SW"))
        	assetService.processSwAsset(paramTicketInfoVO);


        /*
         * 1.1 코멘트 정보 등록
         */
        setCommentInfo(hookBasicVO.getIssue());
        /*
         * 1.2 첨부파일 정보 등록
         */
        setAttachment(hookBasicVO.getIssue());

        /**
         * 2. HI OMS & 실루엣 연동
         * assignee key값이 hioms_user 테이블에 존재할 경우 hioms & 실루엣 연동을 한다.
         * 1회만 인터페이스 한다. 다만 첫 req에 assignee가 없을 수 있다.
         * 티켓 상태가 '작업중' 이며  assignee가 존재하며 hioms_user 에 있을경우, api_hioms_request_info 테이블 조회하여 데이터 없을때만 인터페이스 실행(and 조건)
         */
        Integer iTicketId = Integer.parseInt(hookBasicVO.getIssue().getId());

        if(JiraResponseType.TICKET_STATUS_ING.getValue().equals(paramTicketInfoVO.getStatus())){
        	if(paramTicketInfoVO.getAssigneeKey() != null && StringUtils.isNotEmpty(paramTicketInfoVO.getAssigneeKey())){
            	if(!JiraResponseType.DEVICE_REQ.getValue().equals(paramTicketInfoVO.getDivision())){

            		List<HiOmsUserVO> omsUserInfoList = hiOmsMapper.selectHiOmsUserList(paramTicketInfoVO.getAssigneeKey());

            		if(omsUserInfoList != null && omsUserInfoList.size() > 0){

                    	HiOmsRequestInfoVO paramHioms = new HiOmsRequestInfoVO();
                    	paramHioms.setTicketId(iTicketId);
                    	paramHioms.setIfGubun("H");
                    	paramHioms.setCorpGubun(corpGubun);
                    	HiOmsRequestInfoVO hiomsInfo = hiOmsMapper.selectHiomsInfoById(paramHioms);
                    	if(hiomsInfo == null){
                    		//1. hioms 연동
                        	hiOmsService.sendTicketRequestToHiOms(Integer.toString(paramTicketInfoVO.getTicketId()), corpGubun);
                    	}//if(hiomsInfo == null){ END

                    	paramHioms = new HiOmsRequestInfoVO();
                    	paramHioms.setTicketId(iTicketId);
                    	paramHioms.setIfGubun("S");
                    	paramHioms.setCorpGubun(corpGubun);
                    	hiomsInfo = hiOmsMapper.selectHiomsInfoById(paramHioms);
                    	if(hiomsInfo == null){
                        	//2. 실루엣 연동
                        	silhouetteService.sendTicketRequestToSilhouette(Integer.toString(paramTicketInfoVO.getTicketId()), corpGubun);
                    	}//if(hiomsInfo == null){ END

                    }
                }
            }
        }//JiraResponseType.TICKET_STATUS_ING END

	}

	private TicketInfoVO setBasicTicketInfo(HookBasicVO hookBasicVO) throws Exception {

		HookIssueVO issueVO = hookBasicVO.getIssue();
		HookFieldsVO fieldsVO = hookBasicVO.getIssue().getFields();

		TicketInfoVO paramTicketInfoVO = new TicketInfoVO();

        paramTicketInfoVO.setTicketId(Integer.parseInt(issueVO.getId()));	//티켓ID
        paramTicketInfoVO.setTicketKey(issueVO.getKey());	//티켓
        paramTicketInfoVO.setCorpGubun(issueVO.getCorpGubun());	//회사 구분자

        String summary = fieldsVO.getSummary();
        if(StringUtils.isNotEmpty(summary)) summary = Normalizer.normalize(summary, Normalizer.Form.NFC);	//JIRA에서 제목을 수정시에 자음모음 분리현상이 일어난다
        paramTicketInfoVO.setSummary(summary);	//제목
        /**
         * NXMILE용 내용 (SKP JIRA의 렌더러 문제로 html tag가 과도하게 들어와 html tag가 없는 nxmile용 내용 커스텀필드가 추가됨
         */
        if(issueVO.getKey().startsWith("NXMILE")){
        	if(fieldsVO.getCustomfield_19101() == null){
        		paramTicketInfoVO.setDescription(fieldsVO.getDescription());	//내용상세
        	}else{
        		paramTicketInfoVO.setDescription(fieldsVO.getCustomfield_19101());	//NXMILE 내용상세
        	}
        }else{
        	paramTicketInfoVO.setDescription(fieldsVO.getDescription());	//내용상세
        }

        paramTicketInfoVO.setCreateDate(fieldsVO.getCreated());	//생성일시
        paramTicketInfoVO.setUpdateDate(fieldsVO.getUpdated());	//수정일시
        paramTicketInfoVO.setDueDate(fieldsVO.getDuedate());	//완료요청일

        if(fieldsVO.getResolution() != null){
        	paramTicketInfoVO.setResolution(fieldsVO.getResolution().getName());	//해결상태
        	paramTicketInfoVO.setResolutionDate(fieldsVO.getResolutiondate());	//해결일시
        }

        paramTicketInfoVO.setReporterKey(fieldsVO.getReporter().getName());			//생성자ID
        paramTicketInfoVO.setReporterName(fieldsVO.getReporter().getDisplayName());	//생성자명
        if(fieldsVO.getAssignee().getName() == null){
        	paramTicketInfoVO.setAssigneeKey(fieldsVO.getAssignee().getKey());			//처리자ID (JIRA의 key 값은 pnet empno 가 아닌 경우가 종종 있음)
        }else{
        	paramTicketInfoVO.setAssigneeKey(fieldsVO.getAssignee().getName());			//처리자ID
        }
        paramTicketInfoVO.setAssigneeName(fieldsVO.getAssignee().getDisplayName());	//처리자명

        //승인자 필드는 리스트지만 최종 1명만 값이 넘어온다.
        List<JiraCommonVO> approverList = fieldsVO.getCustomfield_16304();
        if(approverList != null){
            for (JiraCommonVO approver : approverList) {
            	paramTicketInfoVO.setApproverKey(approver.getName());			//승인자ID
                paramTicketInfoVO.setApproverName(approver.getDisplayName());	//승인자명
    		}
        }

        paramTicketInfoVO.setCategory(fieldsVO.getProject().getName());	//대분류

        String division = fieldsVO.getIssuetype().getName();
        if(StringUtils.isNotEmpty(division))
        	paramTicketInfoVO.setDivision(division.trim());	//중분류(Type)


        JiraCommonVO customMap = new JiraCommonVO();
        //인트라넷 개발요청
        if(JiraResponseType.INTRANET_DEV_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = fieldsVO.getCustomfield_17104();
        }
        //인트라넷 권한신청 & 운영지원요처
        else if(JiraResponseType.INTRANET_AUTH_REQ.getValue().equals(paramTicketInfoVO.getDivision())
        		|| JiraResponseType.INTRANET_HELP_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = fieldsVO.getCustomfield_17105();
        }
        //메인배너 등록요청
        else if(JiraResponseType.MAIN_BANNER_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = fieldsVO.getCustomfield_17103();
        }
		//ERP 기본권한신청
		else if(JiraResponseType.ERP_BASIC_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = fieldsVO.getCustomfield_17101();
		}
        //ERP 특수권한신청
		else if(JiraResponseType.ERP_SPECIAL_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = fieldsVO.getCustomfield_17102();
		}
        //ERP 개발요청 & 운영지원요청
		else if(JiraResponseType.ERP_DEV_REQ.getValue().equals(paramTicketInfoVO.getDivision())
				|| JiraResponseType.ERP_HELP_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = fieldsVO.getCustomfield_17100();
		}
        //단말신청
  		else if(JiraResponseType.DEVICE_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
      			customMap = fieldsVO.getCustomfield_17106();
      	}
        if(customMap != null && StringUtils.isNotEmpty(customMap.getValue()))
        	paramTicketInfoVO.setSection(customMap.getValue());	//소분류(신청타입3)

        paramTicketInfoVO.setStatus(fieldsVO.getStatus().getName());	//티켓상태
        paramTicketInfoVO.setPriority(fieldsVO.getPriority().getName());	//티켓중요도

        /**
         * OA 신청용 필드 시작
         */
        //1. 대상장비
        //SKP11NM00003 (애플 MacBook Pro MD314KH/A(11)) 형식 값 잘라 넣기.
        String pcUserId = "";
        String pcAdminId = "";
        if(JiraResponseType.OA_CHANGE.getValue().equals(paramTicketInfoVO.getDivision())){
        	//OA장비교체신청일때 customfield_17603 / 보유자산(교체대상)
            String tagNo = fieldsVO.getCustomfield_17603();
            if(StringUtils.isNotEmpty(tagNo)){
            	if(tagNo.indexOf(" ") > -1){
            		paramTicketInfoVO.setChangeTagNo(tagNo.substring(0, tagNo.indexOf(" ")));
            		PcVO paramPc = new PcVO();
                    paramPc.setTagNo(paramTicketInfoVO.getChangeTagNo());
                    PcVO pcInfo = pcMapper.selectPcInfo(paramPc);
                    pcUserId = pcInfo.getUserId();
                    pcAdminId = pcInfo.getAdminId();
            	}else{
            		paramTicketInfoVO.setChangeTagNo(tagNo);
            	}
            }

        }else if(JiraResponseType.OA_RETURN.getValue().equals(paramTicketInfoVO.getDivision())){
            //OA장비반납신청 customfield_17207
            String tagNo = fieldsVO.getCustomfield_17207();
            if(StringUtils.isNotEmpty(tagNo)){
            	if(tagNo.indexOf(" ") > -1){
            		paramTicketInfoVO.setReturnTagNo(tagNo.substring(0, tagNo.indexOf(" ")));
            		PcVO paramPc = new PcVO();
                    paramPc.setTagNo(paramTicketInfoVO.getReturnTagNo());
                    PcVO pcInfo = pcMapper.selectPcInfo(paramPc);
                    pcUserId = pcInfo.getUserId();
                    pcAdminId = pcInfo.getAdminId();
            	}else{
            		paramTicketInfoVO.setReturnTagNo(tagNo);
            	}
            }
        }
        //지급장비 customfield_17604
        String tagNo = fieldsVO.getCustomfield_17604();
        if(StringUtils.isNotEmpty(tagNo)){
        	paramTicketInfoVO.setTagNo(tagNo);
        }

        //1.1 OA사용자
        JiraCommonVO pcUserIdMap = fieldsVO.getCustomfield_17205();
        if(pcUserIdMap != null){
        	paramTicketInfoVO.setPcUserId(pcUserIdMap.getName());
        }else{
        	paramTicketInfoVO.setPcUserId(pcUserId);
        }
        //1.2 OA관리자
        JiraCommonVO pcAdminIdMap = fieldsVO.getCustomfield_17313();
        if(pcAdminIdMap != null){
        	paramTicketInfoVO.setPcAdminId(pcAdminIdMap.getName());
        }else{
        	paramTicketInfoVO.setPcAdminId(pcAdminId);
        }

        //2. 근무사옥
        JiraCommonVO useLocationMap = fieldsVO.getCustomfield_17314();
        if(useLocationMap != null) paramTicketInfoVO.setUseLocation(useLocationMap.getValue());
        //3. 근무층
        String useLocationFloor = fieldsVO.getCustomfield_17315();
        if(StringUtils.isNotEmpty(useLocationFloor)) paramTicketInfoVO.setUseLocationFloor(useLocationFloor);

        //4. 기기구분
        String machinType = fieldsVO.getCustomfield_17503();
        if(StringUtils.isNotEmpty(machinType)) paramTicketInfoVO.setMachinType(machinType);
        //5.반납예정일 (대여용 장비 대상) customfield_17602 2020-01-29T10:16:00.000+0900 returnPlanDate
        String returnPlanDate = fieldsVO.getCustomfield_17602();
        if(StringUtils.isNotEmpty(returnPlanDate)) paramTicketInfoVO.setReturnPlanDate(returnPlanDate);


        /**
         * SW 신청용 필드
         */
        //1. SW용도
        JiraCommonVO usageTypeMap = fieldsVO.getCustomfield_17309();
        if(usageTypeMap != null) paramTicketInfoVO.setUsageType(usageTypeMap.getValue());
        //2. SW이름
        //MS Project Pro (SKPSW17102700025) 형식 값 잘라 넣기.
        if(fieldsVO.getCustomfield_19221() != null){
        	String swManagementNo = fieldsVO.getCustomfield_19221().getValue();
        	if(StringUtils.isNotEmpty(swManagementNo)) paramTicketInfoVO.setSwManagementNo(swManagementNo.substring(swManagementNo.lastIndexOf("(")+1, swManagementNo.lastIndexOf(")")));
        }
        //3. 반납대상SW Asset key
        //SW-2 (IntelliJ IDEA 2017) 형식 값 잘라 넣기.
        //JIRA 버그로 서비스데스크의 DB조회 불가. 반납시 수동처리로 변경됨 190404
//        String swlAssetKey = fieldsVO.getCustomfield_17311();
//        if(StringUtils.isNotEmpty(swlAssetKey)) paramTicketInfoVO.setSwlAssetKey(swlAssetKey.substring(0, swlAssetKey.indexOf(" ")));

        /*
         * 0. 기등록된 티켓인지 확인.
         */
        TicketInfoVO ticketInfo = jiraTicketMapper.selectTicketInfo(paramTicketInfoVO);

        if(ticketInfo == null){
        	jiraTicketMapper.insertTicketInfo(paramTicketInfoVO);
        }else{
        	jiraTicketMapper.updateTicketInfo(paramTicketInfoVO);
        }

		return paramTicketInfoVO;
	}


	private void setCommentInfo(HookIssueVO request) throws Exception{

		if(request.getFields().getComment() == null) return;

		List<JiraCommentVO> commentList = request.getFields().getComment().getComments();

		for (JiraCommentVO commentInfo : commentList) {
			TicketCommentVO vo = new TicketCommentVO();
			vo.setTicketId(Integer.parseInt(request.getId()));
			vo.setCommentId(Integer.parseInt(commentInfo.getId()));
			vo.setCorpGubun(request.getCorpGubun());
			vo.setContents(commentInfo.getBody());
			vo.setCreateDate(commentInfo.getCreated());
			vo.setUpdateDate(commentInfo.getUpdated());
			vo.setCreatorKey(commentInfo.getAuthor().getName());
			vo.setCreatorName(commentInfo.getAuthor().getDisplayName());

			TicketCommentVO param = new TicketCommentVO();
			param.setCommentId(vo.getCommentId());
			TicketCommentVO dbInfo = jiraTicketMapper.selectTicketCommentInfo(param);
			if(dbInfo == null){
				jiraTicketMapper.insertTicketComment(vo);
			}else{
				jiraTicketMapper.updateTicketComment(vo);
			}
		}
	}

	private void setAttachment(HookIssueVO request) throws Exception{

		if(request.getFields().getAttachment() == null) return;

		Integer ticketId = Integer.parseInt(request.getId());

		for (JiraAttachmentVO attach : request.getFields().getAttachment()) {
			String contentUrl = attach.getContent();
			String fileName = attach.getFilename();
			Integer attachId = Integer.parseInt(attach.getId());
			//파일 다운로드
			String saveFilePath = downloadFileByUrl2(ticketId, request.getCorpGubun(), contentUrl, fileName);

			if(StringUtils.isNotEmpty(saveFilePath)){
				logger.debug("DOWNLOAD FILE PATH :: {} / {}", saveFilePath , fileName);

				AttachmentVO vo = new AttachmentVO();
				vo.setTicketId(ticketId);
				vo.setAttachId(attachId);
				vo.setCorpGubun(request.getCorpGubun());
				vo.setFileDownloadUrl(contentUrl);
				vo.setFileName(fileName);
				vo.setSaveFilePath(saveFilePath);
				vo.setSaveFileName(fileName);
				vo.setMimeType(attach.getMimeType());
				vo.setFileSize(attach.getSize());
				vo.setCreateDate(attach.getCreated());
				vo.setCreatorKey(attach.getAuthor().getName());
				vo.setCreatorName(attach.getAuthor().getDisplayName());

				AttachmentVO param = new AttachmentVO();
				param.setAttachId(attachId);
				param.setCorpGubun(request.getCorpGubun());
				AttachmentVO attachInfo = jiraTicketMapper.selectAttachmentInfo(param);
				if(attachInfo == null){
					jiraTicketMapper.insertAttachment(vo);
				}else{
					jiraTicketMapper.updateAttachment(vo);
				}
			}
		}
	}

	private String downloadFileByUrl2(Integer ticketId, String corpGubun, String fileUrl, String fileName) throws Exception{

		String defaultFilePath = StaticPropertyUtil.getProperty("jira.restapi.download.filepath");

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new BoResponseErrorHandler());

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

        ifLog.info("JIRA Download Attachment start. ticket id : {}", ticketId);
        ResponseEntity<byte[]> response = restTemplate.getForEntity(fileUrl, byte[].class);

        if(HttpStatus.OK.equals(response.getStatusCode())){
        	ifLog.debug("JIRA Download Attachment Success. ticket id : {}", ticketId);
        	Calendar cal = Calendar.getInstance();
            String yyyy = (new SimpleDateFormat("yyyy")).format(cal.getTime());
            String MMdd = (new SimpleDateFormat("MMdd")).format(cal.getTime());
            String saveFilePath = defaultFilePath + "/" + corpGubun + "/" + yyyy + "/" + MMdd + "/" + ticketId + "/";

            File dir = new File(saveFilePath);
            if(!dir.exists())
            	dir.mkdirs();

            File downloadedFile = new File(saveFilePath, fileName);
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(downloadedFile));
            try {
				bos.write(response.getBody());
				bos.flush();
				bos.close();
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("File flush error. TICKET_ID : {} \tFilename : {}", ticketId, fileName);
			} finally {
				bos.flush();
				bos.close();
			}

            return saveFilePath;

        }else{
        	ifLog.error("JIRA Download Attachment FAIL. HttpStatus : {}", response.getStatusCodeValue());
        	ifLog.error("JIRA Download Attachment FAIL. TICKET_ID : {} \n URL : {}", ticketId, fileUrl);
        }

        return null;
	}


}
