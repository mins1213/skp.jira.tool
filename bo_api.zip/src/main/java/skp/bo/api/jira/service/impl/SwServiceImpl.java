package skp.bo.api.jira.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import skp.bo.api.SystemConstant;
import skp.bo.api.common.service.CodeService;
import skp.bo.api.hioms.mapper.HiOmsMapper;
import skp.bo.api.hioms.service.HiOmsService;
import skp.bo.api.jira.mapper.JiraTicketMapper;
import skp.bo.api.jira.mapper.PcMapper;
import skp.bo.api.jira.mapper.SwMapper;
import skp.bo.api.jira.service.AssetService;
import skp.bo.api.jira.service.SwService;
import skp.bo.api.silhouette.service.SilhouetteService;

public class SwServiceImpl implements SwService{

	private static final Logger ifLog = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_JIRA);
	private static final Logger log = LoggerFactory.getLogger(SwServiceImpl.class);

	@Autowired
	JiraTicketMapper jiraTicketMapper;

	@Autowired
	HiOmsMapper hiOmsMapper;

	@Autowired
	SwMapper swMapper;

	@Autowired
	PcMapper pcMapper;

	@Autowired
	HiOmsService hiOmsService;

	@Autowired
	SilhouetteService silhouetteService;

	@Autowired
	CodeService codeService;

	@Autowired
	AssetService assetService;


}
