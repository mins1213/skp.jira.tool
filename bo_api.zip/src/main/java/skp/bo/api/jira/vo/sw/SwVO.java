package skp.bo.api.jira.vo.sw;

public class SwVO {

	private String seq;
	private String softwareBaseSeq;
	private String userId;
	private String userName;
	private String departmentName;
	private String useStatus;
	private String license;
	private String note;
	private String firstReqDate;
	private String introductionDate;
	private String regDate;
	private String modDate;
	private String regUserId;
	private String modUserId;
	private String ticketId;
	private String ticketKey;
	private String jiraResult;
	private String jiraResultMsg;
	private String swManagementNo;


	public String getSwManagementNo() {
		return swManagementNo;
	}
	public void setSwManagementNo(String swManagementNo) {
		this.swManagementNo = swManagementNo;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getSoftwareBaseSeq() {
		return softwareBaseSeq;
	}
	public void setSoftwareBaseSeq(String softwareBaseSeq) {
		this.softwareBaseSeq = softwareBaseSeq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getUseStatus() {
		return useStatus;
	}
	public void setUseStatus(String useStatus) {
		this.useStatus = useStatus;
	}
	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getFirstReqDate() {
		return firstReqDate;
	}
	public void setFirstReqDate(String firstReqDate) {
		this.firstReqDate = firstReqDate;
	}
	public String getIntroductionDate() {
		return introductionDate;
	}
	public void setIntroductionDate(String introductionDate) {
		this.introductionDate = introductionDate;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getModDate() {
		return modDate;
	}
	public void setModDate(String modDate) {
		this.modDate = modDate;
	}
	public String getRegUserId() {
		return regUserId;
	}
	public void setRegUserId(String regUserId) {
		this.regUserId = regUserId;
	}
	public String getModUserId() {
		return modUserId;
	}
	public void setModUserId(String modUserId) {
		this.modUserId = modUserId;
	}
	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	public String getTicketKey() {
		return ticketKey;
	}
	public void setTicketKey(String ticketKey) {
		this.ticketKey = ticketKey;
	}
	public String getJiraResult() {
		return jiraResult;
	}
	public void setJiraResult(String jiraResult) {
		this.jiraResult = jiraResult;
	}
	public String getJiraResultMsg() {
		return jiraResultMsg;
	}
	public void setJiraResultMsg(String jiraResultMsg) {
		this.jiraResultMsg = jiraResultMsg;
	}



}
