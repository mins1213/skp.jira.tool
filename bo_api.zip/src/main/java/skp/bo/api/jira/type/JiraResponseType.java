package skp.bo.api.jira.type;

public enum JiraResponseType {

	INTRANET_DEV_REQ("인트라넷 개발요청"),
	INTRANET_AUTH_REQ("인트라넷 권한신청"),
	INTRANET_HELP_REQ("인트라넷 운영지원요청"),
	MAIN_BANNER_REQ("메인배너 등록요청"),
	ERP_BASIC_REQ("ERP 기본권한신청"),
	ERP_SPECIAL_REQ("ERP 특수권한신청"),
	ERP_DEV_REQ("ERP 개발요청"),
	ERP_HELP_REQ("ERP 운영지원요청"),
	DEVICE_REQ("단말신청"),
	TICKET_STATUS_ING("작업중"),
	OA_REQ("OA장비신청"),
	OA_CHANGE("OA장비교체신청"),
	OA_RETURN("OA장비반납신청"),
	OA_HELP("OA지원요청"),

	OK("OK");


	private String reqType;

	private JiraResponseType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}
}
