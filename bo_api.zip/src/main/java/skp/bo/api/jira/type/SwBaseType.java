package skp.bo.api.jira.type;

public enum SwBaseType {

	계약수량초과설치가능("CT01"),
	계약수량초과설치불가능("CT02"),
	HELPDESK방문후설치("IS01"),
	사용자직접설치("IS02"),
	공용인증키("CK01"),
	개별인증키("CK02"),


	OK("OK");


	private String reqType;

	private SwBaseType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}
}
