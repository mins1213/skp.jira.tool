package skp.bo.api.jira.service;

import java.util.List;

import skp.bo.api.jira.type.SwAssetStatusType;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.jira.vo.pc.PcApiVO;
import skp.bo.api.jira.vo.sw.SwApiVO;

public interface AssetService {

	public boolean chgJiraOaAssetStatus(String tagNo, String useStatus) throws Exception;

	public boolean chgJiraOaAssetStatus(List<PcApiVO> apiList) throws Exception;

	public Boolean requestSwAsset(TicketInfoVO ticketInfo)throws Exception;

	public Boolean returnSwAsset(TicketInfoVO ticketInfo)throws Exception;

	public Boolean processSwAsset(TicketInfoVO ticketInfo)throws Exception;

	public Boolean processOAasset(TicketInfoVO ticketInfo)throws Exception;

	public boolean chgJiraSwAssetStatus(String seq, SwAssetStatusType reqStatus) throws Exception;

	public boolean chgJiraSwAssetStatus(List<SwApiVO> apiList) throws Exception;

	public void updatePcAssetForceSync(String assetId) throws Exception;

	public void migrationJiraSwAsset() throws Exception;

	public void migrationJiraSwAsset2(String seq) throws Exception;

}
