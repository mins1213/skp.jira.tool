package skp.bo.api.jira.service;

public interface SwService {

}
