package skp.bo.api.jira.vo.hook;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import skp.bo.api.jira.vo.JiraAttachmentVO;
import skp.bo.api.jira.vo.JiraCommentsVO;
import skp.bo.api.jira.vo.JiraCommonVO;

public class HookFieldsVO {

	/**
	 * ASSET 고정값
	 */
	private JiraCommonVO project = null;

	/**
	 * 제목
	 */
	private String summary = null;

	/**
	 * 내용
	 */
	private String description = null;

	/**
	 * NXMILE용 내용 (SKP JIRA의 렌더러 문제로 html tag가 과도하게 들어와 html tag가 없는 nxmile용 내용 커스텀필드가 추가됨
	 */
	private String customfield_19101 = null;

	/**
	 * OA자산 고정값
	 */
	private JiraCommonVO issuetype = null;

	/**
	 * 반납예정일
	 */
	private String duedate = null;
	/**
	 * 자산코드 tag_no
	 */
	private String customfield_17200 = null;
	/**
	 * 모델명 model_code
	 */
	private String customfield_17201 = null;
	/**
	 * OA기기용도 use_code
	 */
	private JiraCommonVO customfield_17202 = null;
	/**
	 * OA기기구분
	 */
	private JiraCommonVO customfield_17312 = null;
	/**
	 * OA사용자 정보 user_name
	 */
	private JiraCommonVO customfield_17205 = null;

	/**
	 * OA관리자 admin_id
	 */
	private JiraCommonVO customfield_17313 = null;
	/**
	 * assignee
	 */
	private JiraCommonVO assignee = null;

	/**
	 * status 상태.
	 */
	private JiraCommonVO status = null;
	/**
	 * 티켓중요도
	 */
	private JiraCommonVO priority = null;

	/**
	 * 코멘트 객체
	 */
	private JiraCommentsVO comment = null;

	/**
	 * 첨부파일 객체
	 */
	private List<JiraAttachmentVO> attachment = null;

	/**
	 * 생성일
	 */
	private String created = null;
	/**
	 * 수정일
	 */
	private String updated = null;

	/**
	 * 완료처리된 날짜
	 */
	private String resolutiondate = null;

	/**
	 * 완료처리된 상태값
	 */
	private JiraCommonVO resolution = null;

	/**
	 * 리포터
	 */
	private JiraCommonVO reporter = null;

	/**
	 * 승인자 리스트
	 */
	private List<JiraCommonVO> customfield_16304 = null;

	/**
	 * 인트라넷 개발요청
	 */
	private JiraCommonVO customfield_17104 = null;
	/**
	 * 인트라넷 권한신청 & 운영지원요청
	 */
	private JiraCommonVO customfield_17105 = null;
	/**
	 * 메인배너 등록요청
	 */
	private JiraCommonVO customfield_17103 = null;
	/**
	 * ERP 기본권한신청
	 */
	private JiraCommonVO customfield_17101 = null;
	/**
	 * ERP 특수권한신청
	 */
	private JiraCommonVO customfield_17102 = null;
	/**
	 * ERP 개발요청 & 운영지원요청
	 */
	private JiraCommonVO customfield_17100 = null;
	/**
	 * 단말신청
	 */
	private JiraCommonVO customfield_17106 = null;

	/**
	 * OA장비교체 tagno
	 */
	private String customfield_17603 = null;
	/**
	 * OA장비반납 tagno
	 */
	private String customfield_17207 = null;
	/**
	 * OA지급장비 tagno
	 */
	private String customfield_17604 = null;
	/**
	 * OA근무사옥
	 */
	private JiraCommonVO  customfield_17314 = null;
	/**
	 * OA근무층
	 */
	private String  customfield_17315 = null;
	/**
	 * OA기기구분
	 */
	private String  customfield_17503 = null;
	/**
	 * OA반납예정일 (대여용 장비 대상)
	 */
	private String  customfield_17602 = null;

	/**
	 * SW용도
	 */
	private JiraCommonVO  customfield_17309 = null;

	/**
	 * SW이름
	 */
	private JiraCommonVO  customfield_19221 = null;
	/**
	 * 반납대상SW Asset key
	 */
	private String  customfield_17311 = null;



	public String getCustomfield_19101() {
		return customfield_19101;
	}

	public void setCustomfield_19101(String customfield_19101) {
		this.customfield_19101 = customfield_19101;
	}

	public JiraCommonVO getCustomfield_17309() {
		return customfield_17309;
	}

	public void setCustomfield_17309(JiraCommonVO customfield_17309) {
		this.customfield_17309 = customfield_17309;
	}



	public JiraCommonVO getCustomfield_19221() {
		return customfield_19221;
	}

	public void setCustomfield_19221(JiraCommonVO customfield_19221) {
		this.customfield_19221 = customfield_19221;
	}

	public String getCustomfield_17311() {
		return customfield_17311;
	}

	public void setCustomfield_17311(String customfield_17311) {
		this.customfield_17311 = customfield_17311;
	}

	public JiraCommonVO getCustomfield_17314() {
		return customfield_17314;
	}

	public void setCustomfield_17314(JiraCommonVO customfield_17314) {
		this.customfield_17314 = customfield_17314;
	}

	public String getCustomfield_17315() {
		return customfield_17315;
	}

	public void setCustomfield_17315(String customfield_17315) {
		this.customfield_17315 = customfield_17315;
	}

	public String getCustomfield_17503() {
		return customfield_17503;
	}

	public void setCustomfield_17503(String customfield_17503) {
		this.customfield_17503 = customfield_17503;
	}

	public String getCustomfield_17602() {
		return customfield_17602;
	}

	public void setCustomfield_17602(String customfield_17602) {
		this.customfield_17602 = customfield_17602;
	}

	public String getCustomfield_17604() {
		return customfield_17604;
	}

	public void setCustomfield_17604(String customfield_17604) {
		this.customfield_17604 = customfield_17604;
	}

	public String getCustomfield_17207() {
		return customfield_17207;
	}

	public void setCustomfield_17207(String customfield_17207) {
		this.customfield_17207 = customfield_17207;
	}

	public String getCustomfield_17603() {
		return customfield_17603;
	}

	public void setCustomfield_17603(String customfield_17603) {
		this.customfield_17603 = customfield_17603;
	}

	public JiraCommonVO getPriority() {
		return priority;
	}

	public void setPriority(JiraCommonVO priority) {
		this.priority = priority;
	}

	public JiraCommonVO getCustomfield_17104() {
		return customfield_17104;
	}

	public void setCustomfield_17104(JiraCommonVO customfield_17104) {
		this.customfield_17104 = customfield_17104;
	}

	public JiraCommonVO getCustomfield_17105() {
		return customfield_17105;
	}

	public void setCustomfield_17105(JiraCommonVO customfield_17105) {
		this.customfield_17105 = customfield_17105;
	}

	public JiraCommonVO getCustomfield_17103() {
		return customfield_17103;
	}

	public void setCustomfield_17103(JiraCommonVO customfield_17103) {
		this.customfield_17103 = customfield_17103;
	}

	public JiraCommonVO getCustomfield_17101() {
		return customfield_17101;
	}

	public void setCustomfield_17101(JiraCommonVO customfield_17101) {
		this.customfield_17101 = customfield_17101;
	}

	public JiraCommonVO getCustomfield_17102() {
		return customfield_17102;
	}

	public void setCustomfield_17102(JiraCommonVO customfield_17102) {
		this.customfield_17102 = customfield_17102;
	}

	public JiraCommonVO getCustomfield_17100() {
		return customfield_17100;
	}

	public void setCustomfield_17100(JiraCommonVO customfield_17100) {
		this.customfield_17100 = customfield_17100;
	}

	public JiraCommonVO getCustomfield_17106() {
		return customfield_17106;
	}

	public void setCustomfield_17106(JiraCommonVO customfield_17106) {
		this.customfield_17106 = customfield_17106;
	}

	public List<JiraCommonVO> getCustomfield_16304() {
		return customfield_16304;
	}

	public void setCustomfield_16304(List<JiraCommonVO> customfield_16304) {
		this.customfield_16304 = customfield_16304;
	}

	public JiraCommonVO getReporter() {
		return reporter;
	}

	public void setReporter(JiraCommonVO reporter) {
		this.reporter = reporter;
	}

	public String getResolutiondate() {
		return resolutiondate;
	}

	public void setResolutiondate(String resolutiondate) {
		this.resolutiondate = resolutiondate;
	}

	public JiraCommonVO getResolution() {
		return resolution;
	}

	public void setResolution(JiraCommonVO resolution) {
		this.resolution = resolution;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getUpdated() {
		return updated;
	}

	public void setUpdated(String updated) {
		this.updated = updated;
	}

	public JiraCommonVO getStatus() {
		return status;
	}

	public void setStatus(JiraCommonVO status) {
		this.status = status;
	}

	public List<JiraAttachmentVO> getAttachment() {
		return attachment;
	}

	public void setAttachment(List<JiraAttachmentVO> attachment) {
		this.attachment = attachment;
	}

	public JiraCommentsVO getComment() {
		return comment;
	}

	public void setComment(JiraCommentsVO comment) {
		this.comment = comment;
	}


	public JiraCommonVO getProject() {
		return project;
	}

	public void setProject(JiraCommonVO project) {
		this.project = project;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public JiraCommonVO getIssuetype() {
		return issuetype;
	}

	public void setIssuetype(JiraCommonVO issuetype) {
		this.issuetype = issuetype;
	}

	public String getDuedate() {
		return duedate;
	}

	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}

	public String getCustomfield_17200() {
		return customfield_17200;
	}

	public void setCustomfield_17200(String customfield_17200) {
		this.customfield_17200 = customfield_17200;
	}



	public JiraCommonVO getAssignee() {
		return assignee;
	}

	public void setAssignee(JiraCommonVO assignee) {
		this.assignee = assignee;
	}

	public String getCustomfield_17201() {
		return customfield_17201;
	}

	public void setCustomfield_17201(String customfield_17201) {
		this.customfield_17201 = customfield_17201;
	}



	public JiraCommonVO getCustomfield_17202() {
		return customfield_17202;
	}

	public void setCustomfield_17202(JiraCommonVO customfield_17202) {
		this.customfield_17202 = customfield_17202;
	}

	public JiraCommonVO getCustomfield_17312() {
		return customfield_17312;
	}

	public void setCustomfield_17312(JiraCommonVO customfield_17312) {
		this.customfield_17312 = customfield_17312;
	}

	public JiraCommonVO getCustomfield_17205() {
		return customfield_17205;
	}

	public void setCustomfield_17205(JiraCommonVO customfield_17205) {
		this.customfield_17205 = customfield_17205;
	}

	public JiraCommonVO getCustomfield_17313() {
		return customfield_17313;
	}

	public void setCustomfield_17313(JiraCommonVO customfield_17313) {
		this.customfield_17313 = customfield_17313;
	}

	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
