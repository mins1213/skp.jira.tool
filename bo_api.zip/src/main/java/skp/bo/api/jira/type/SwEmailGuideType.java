package skp.bo.api.jira.type;

public enum SwEmailGuideType {

	설치완료("US01"),
	수량초과불가_헬프데스크문의("US02"),

	OK("OK");


	private String reqType;

	private SwEmailGuideType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}
}
