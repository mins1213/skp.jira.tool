package skp.bo.api.jira.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import skp.bo.api.SystemConstant;
import skp.bo.api.jira.service.AssetService;
import skp.bo.api.jira.service.JiraHookService;
import skp.bo.api.jira.service.JiraRespService;
import skp.bo.api.jira.vo.hook.HookBasicVO;
import skp.bo.api.jira.vo.pc.PcApiVO;
import skp.bo.api.jira.vo.pc.ResPcAssetVO;
import skp.bo.api.jira.vo.sw.SwApiVO;
import skp.bo.api.jira.vo.pc.ReqBasicVO;
import skp.bo.api.silhouette.service.SilhouetteService;

@RestController
public class JiraRespController {

	private static final Logger logger = LoggerFactory.getLogger(JiraRespController.class);

	@Autowired
	private JiraRespService jiraRespService;

	@Autowired
	private JiraHookService jiraHookService;

	@Autowired
	AssetService assetService;

	@Autowired
	SilhouetteService silhouetteService;

	/**
	 * JIRA >>> BOAPI
	 * JIRA ITSR 티켓 정보를 수신한다.(JIRA 티켓이 갱신될때마다 수신함)
	 */
	@RequestMapping(value = "/inbound/jirarequest", consumes="application/json")
	public void receiveJiraTicketId2(@RequestBody HookBasicVO hookBasicVO, Model model, HttpServletRequest request)throws Exception {

		try {
			String ip2 = request.getRemoteAddr();

			logger.info("========================================================================================================");
			logger.info("request.getRemoteAddr ip : "+ ip2);
			logger.info("========================================================================================================");

			if("10.40.132.193".equals(ip2)){
				hookBasicVO.getIssue().setCorpGubun(SystemConstant.CORP_GUBUN_SKP); //SK플래닛 구분자 (NXMILE 용)
			}else{
				hookBasicVO.getIssue().setCorpGubun(SystemConstant.CORP_GUBUN_11ST); //11번가 구분자
			}

			jiraHookService.requestJiraTicketInfo(hookBasicVO);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("JiraRespController.receiveJiraTicketId ERROR", e);
		}

	}

	/**
	 * JIRA >>> BOAPI
	 * JIRA PC asset의 상태값 정보를 받아온다.
	 */
	@RequestMapping(value = "/inbound/jiraasset", consumes="application/json")
	public void receiveJiraAsset(@RequestBody ReqBasicVO jsonbody, Model model)throws Exception {

		if("ASSET".equals(jsonbody.getIssue().getFields().getProject().getKey())){
			if("자산실사".equals(jsonbody.getIssue().getFields().getIssuetype().getName())){
				// 자산실사 처리
				String ticketId = jsonbody.getIssue().getId();
				jiraRespService.updatePcReal(ticketId);
			}
			else
			{
				jiraRespService.updatePcAsset(jsonbody);
			}
		}else if("SW".equals(jsonbody.getIssue().getFields().getProject().getKey())){
			jiraRespService.updateSwAsset(jsonbody);
		}
		logger.debug("#### /api/inbound/jirarequest request body ####\n{}", jsonbody.toString());
	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * SR티켓의 상태값을 완료로 변경한다
	 * @param ticketKey
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/transition/{ticketKey}", method = RequestMethod.GET)
	public Map<String, Boolean> sendTransition(@PathVariable("ticketKey")String ticketKey, Model model)throws Exception {

		Boolean result = jiraRespService.sendTicketStatusCompleted(ticketKey);

		Map<String, Boolean> rst = new HashMap<String, Boolean>();
		rst.put("result", result);

		return rst;

	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * SR티켓의 상태값을 완료로 변경한다
	 * @param ticketKey
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/transition/{ticketKey}/{code}", method = RequestMethod.GET)
	public Map<String, Boolean> sendTransition(@PathVariable("ticketKey")String ticketKey, @PathVariable("code")String code, Model model)throws Exception {

		Boolean result = jiraRespService.sendTicketStatusCompleted(ticketKey, code);

		Map<String, Boolean> rst = new HashMap<String, Boolean>();
		rst.put("result", result);

		return rst;

	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * SR티켓에 코멘트를 등록한다
	 * @param ticketKey
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/comment/{ticketKey}", method = RequestMethod.GET)
	public void sendComment(@PathVariable("ticketKey")String ticketKey, Model model)throws Exception {

		jiraRespService.sendTicketComment(ticketKey, "코멘트 테스트 test");

	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * PC Asset 티켓을 생성 한다
	 * @param jsonbody
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/createPcAsset", consumes="application/json")
	public boolean createPcAsset(@RequestBody List<String> tagNoList)throws Exception {

		logger.debug("List<HashMap<String,String>> tagNoList : {}", tagNoList.size());

		return jiraRespService.createJiraPcAsset(tagNoList);

	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * PC Asset 티켓을 수정한다
	 * @param jsonbody
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/updatePcAsset", consumes="application/json")
	public boolean updatePcAsset(@RequestBody List<String> jsonbody)throws Exception {

		logger.debug("List<HashMap<String,String>> jsonbody : {}", jsonbody.toString());

		return jiraRespService.updateJiraPcAsset(jsonbody);
	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * SW Asset 티켓을 생성 한다
	 * @param jsonbody
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/createSwAsset", consumes="application/json")
	public boolean createSwAsset(@RequestBody List<String> jsonbody)throws Exception {

		logger.debug("List<HashMap<String,String>> jsonbody : {}", jsonbody.size());

		return jiraRespService.createJiraSwAsset(jsonbody);

	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * SW Asset 티켓을 수정한다
	 * @param jsonbody
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/updateSwAsset", consumes="application/json")
	public boolean updateSwAsset(@RequestBody List<String> jsonbody)throws Exception {

		logger.debug("List<HashMap<String,String>> jsonbody : {}", jsonbody.toString());

		return jiraRespService.updateJiraSwAsset(jsonbody);
	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * PC asset의 상태를 수정한다
	 * @param jsonbody
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/updatePcStatus", consumes="application/json")
	public boolean updatePcStatus(@RequestBody List<PcApiVO> pcApiVoList)throws Exception {

		logger.debug("List<PcApiVO> pcApiVoList Size : {}", pcApiVoList.size());

		return assetService.chgJiraOaAssetStatus(pcApiVoList);

	}

	/**
	 * BOADM >>> BOAPI >>> JIRA
	 * SW asset의 상태를 수정한다
	 * @param jsonbody
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/jira/send/updateSwStatus", consumes="application/json")
	public boolean updateStatus(@RequestBody List<SwApiVO> jsonbody)throws Exception {

		logger.debug("List<SwApiVO> jsonbody : {}", jsonbody.size());

		return assetService.chgJiraSwAssetStatus(jsonbody);

	}

	///api/jira/send/forceSyncOaAsset/
	@RequestMapping(value = "/jira/send/forceSyncOaAsset/{assetId}", method = RequestMethod.GET)
	public void forceSyncOaAsset(@PathVariable("assetId")String assetId, Model model)throws Exception {

		assetService.updatePcAssetForceSync(assetId);

	}

	@RequestMapping(value = "/jira/migSw/", method = RequestMethod.GET)
	public void migSwAsset(Model model)throws Exception {

		assetService.migrationJiraSwAsset();

	}

	@RequestMapping(value = "/jira/migSw/{swSeq}", method = RequestMethod.GET)
	public void migSwAsset2(@PathVariable("swSeq")String swSeq, Model model)throws Exception {

		assetService.migrationJiraSwAsset2(swSeq);

	}












//	@RequestMapping(value = "/test", consumes="application/json")
	@RequestMapping(value = "/test")
	public ResPcAssetVO test(@RequestBody String jsonbody, Model model, HttpServletRequest request)throws Exception {

		String ip = request.getHeader("X-FORWARDED-FOR");
		String ip2 = request.getRemoteAddr();

		logger.info("========================================================================================================");
		logger.info("X-FORWARDED-FOR if : "+ ip);
		logger.info("request.getRemoteAddr ip : "+ ip2);
		logger.info("========================================================================================================");

		logger.info(jsonbody);

		ResPcAssetVO response = new ResPcAssetVO();

		response.setId("true");

		return response;
//		return "/sample/home";
	}

//	@RequestMapping(value = "/test2/{tagNo}")
	public ResPcAssetVO test2(@PathVariable("tagNo")String tagNo, Model model)throws Exception {

		if(StringUtils.isNotEmpty(tagNo)){

//		jiraRespService.createJiraPcAsset(tagNo);
			silhouetteService.sendTicketRequestToSilhouette(tagNo, SystemConstant.CORP_GUBUN_SKP);
		}

		ResPcAssetVO response = new ResPcAssetVO();

		response.setId("true");

		return response;
//		return "/sample/home";
	}

//	@RequestMapping(value = "/test3/{tagNo}")
	public ResPcAssetVO test3(@PathVariable("tagNo")String tagNo, Model model)throws Exception {

		jiraRespService.updateJiraPcAsset(tagNo);

		ResPcAssetVO response = new ResPcAssetVO();

		response.setId("true");

		return response;
//		return "/sample/home";
	}
//
//	@RequestMapping(value = "/test4/{tagNo}")
//	public ResPcAssetVO test4(@PathVariable("tagNo")String tagNo, Model model)throws Exception {
//
//		jiraRespService.createJiraSwAsset(tagNo);
//
//		ResPcAssetVO response = new ResPcAssetVO();
//
//		response.setId("true");
//
//		return response;
////		return "/sample/home";
//	}
//
//	@RequestMapping(value = "/test5/{tagNo}")
//	public ResPcAssetVO test5(@PathVariable("tagNo")String tagNo, Model model)throws Exception {
//
//		jiraRespService.updateJiraSwAsset(tagNo);
//
//		ResPcAssetVO response = new ResPcAssetVO();
//
//		response.setId("true");
//
//		return response;
////		return "/sample/home";
//	}
//
//	@RequestMapping(value = "/test6", consumes="application/json")
//	public void test6(@RequestBody String jsonbody, Model model)throws Exception {
//
//		logger.info(jsonbody);
//
//	}
//
////	@RequestMapping(value = "/test", consumes="application/json")
//	@RequestMapping(value = "/test7")
//	public ResPcAssetVO test7()throws Exception {
//
////		logger.info(jsonbody);
//
//		assetService.getTest();
//
//		ResPcAssetVO response = new ResPcAssetVO();
//
//		response.setId("true");
//
//		return response;
////		return "/sample/home";
//	}

}
