package skp.bo.api.jira.type;

import java.util.HashMap;
import java.util.Map;

public enum SwAssetStatusType {

	SW입고("created"),
	사용대기("71"),	//SW입고 >>>[SW등록71]>>> 사용대기
	설치확인("81"),
	SW파기("141"),
	사용중("91"),
	반납대기("101"),
	관리자초기화_사용대기("151"),	//사용중 >>>[관리자초기화151]>>>사용대기
	반납확인("111"),
	라이선스_초기화("121"),
	라이선스초기화_사용대기("131"),	//라이선스 초기화>>>[사용대기전환131]>>>사용대기

	OK("OK");


	private String reqType;

	private SwAssetStatusType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}

	private static final Map<String, SwAssetStatusType> stringToEnum = new HashMap<String, SwAssetStatusType>();
	static{
		for(SwAssetStatusType type : values())
			stringToEnum.put(type.name(), type);
	}

	public static SwAssetStatusType fromString(String string){
		if(string != null){
			string = string.replaceAll(" ", "_");
		}
		return stringToEnum.get(string);
	}

	private static final Map<String, SwAssetStatusType> stringToEnum2 = new HashMap<String, SwAssetStatusType>();
	static{
		for(SwAssetStatusType type : values())
			stringToEnum2.put(type.getValue(), type);
	}

	public static SwAssetStatusType toValuefromString(String value){
		return stringToEnum2.get(value);
	}
}
