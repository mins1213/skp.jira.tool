package skp.bo.api.jira.service;

import java.util.List;
import skp.bo.api.jira.vo.pc.ReqBasicVO;
import skp.bo.api.jira.vo.sw.SwApiVO;

public interface JiraRespService {

	public void requestJiraTicketInfo(String ticketId, String ticketKey, String corpGubun) throws Exception;

	public boolean sendTicketStatusCompleted(String ticketKey) throws Exception;
	public boolean sendTicketStatusCompleted(String ticketKey, String transitionCode) throws Exception;

	public boolean sendTicketStatus(String ticketKey, String transitionId) throws Exception;

	public void sendTicketComment(String ticketKey, String comment) throws Exception;

	public boolean createJiraPcAsset(String tagNo) throws Exception;
	public boolean createJiraPcAsset(List<String> tagNoList) throws Exception;

	public Boolean updateJiraPcAsset(String tagNo) throws Exception;
	public Boolean updateJiraPcAsset(List<String> tagNoList) throws Exception;

	public void updatePcAsset(ReqBasicVO assetInfo) throws Exception;

	public boolean createJiraSwAsset(String seq) throws Exception;
	public boolean createJiraSwAsset(List<String> seq) throws Exception;

	public boolean updateJiraSwAsset(String seq) throws Exception;
	public boolean updateJiraSwAsset(List<String> seq) throws Exception;

	public void updateSwAsset(ReqBasicVO assetInfo) throws Exception;

	public boolean chgJiraSwAssetStatus(List<SwApiVO> statusVO) throws Exception;

	public void updatePcReal(String TicketId) throws Exception;

	public void setCommentInfo(ReqBasicVO request) throws Exception;

	public void setAttachment(ReqBasicVO request) throws Exception;




}
