package skp.bo.api.jira.service;

import skp.bo.api.jira.vo.hook.HookBasicVO;

public interface JiraHookService {

	public void requestJiraTicketInfo(HookBasicVO hookBasicVO) throws Exception;

}
