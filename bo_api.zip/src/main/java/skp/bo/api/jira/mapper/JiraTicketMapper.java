package skp.bo.api.jira.mapper;

import java.util.List;

import skp.bo.api.jira.vo.AttachmentVO;
import skp.bo.api.jira.vo.TicketCommentVO;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.jira.vo.pc.PcVO;

public interface JiraTicketMapper {

	public Integer insertTicketInfo(TicketInfoVO vo) throws Exception;

	public TicketInfoVO selectTicketInfo(TicketInfoVO vo) throws Exception;
//	public TicketInfoVO selectTicketInfo(String ticketId, String corpGubun) throws Exception;

//	public TicketInfoVO selectTicketInfoByTagNo(TicketInfoVO ticket) throws Exception;

	public List<TicketInfoVO> selectCheckTicketList() throws Exception;

//	public void updateTicketStatus(TicketInfoVO vo) throws Exception;

	public void updateTicketInfo(TicketInfoVO vo) throws Exception;

	public void insertTicketComment(TicketCommentVO vo) throws Exception;

	public void updateTicketComment(TicketCommentVO vo) throws Exception;

	public TicketCommentVO selectTicketCommentInfo(TicketCommentVO vo) throws Exception;

//	public List<TicketCommentVO> selectTicketCommentList(TicketCommentVO vo) throws Exception;

	public void insertAttachment(AttachmentVO vo) throws Exception;

	public void updateAttachment(AttachmentVO vo) throws Exception;

	public List<AttachmentVO> selectAttachmentList(AttachmentVO vo) throws Exception;
//	public List<AttachmentVO> selectAttachmentList(String ticketId, String corpGubun) throws Exception;

	public AttachmentVO selectAttachmentInfo(AttachmentVO vo) throws Exception;

	public TicketInfoVO selectSubTicketInfo(String ticketId) throws Exception;
	public Integer insertSubTicketInfo(TicketInfoVO vo) throws Exception;
	public void updateSubTicketInfo(TicketInfoVO vo) throws Exception;

}
