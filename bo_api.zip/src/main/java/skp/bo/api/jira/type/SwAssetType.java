package skp.bo.api.jira.type;

public enum SwAssetType {

	PROJECT_KEY("SW"),
	ISSUE_TYPE("OA Software"),

	OK("OK");


	private String reqType;

	private SwAssetType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}
}
