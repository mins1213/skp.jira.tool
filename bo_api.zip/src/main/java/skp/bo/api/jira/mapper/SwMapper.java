package skp.bo.api.jira.mapper;

import java.util.List;

import skp.bo.api.jira.vo.sw.SwBaseVO;
import skp.bo.api.jira.vo.sw.SwVO;

public interface SwMapper {

	public List<SwVO> selectSwList(SwVO vo) throws Exception;

	public SwVO selectSwInfo(SwVO vo) throws Exception;

	public SwVO selectAvailableSwInfo(SwVO vo) throws Exception;

	public void updateSwAsset(SwVO vo) throws Exception;

	public List<SwBaseVO> selectSwBaseList(SwBaseVO vo) throws Exception;

	public SwBaseVO selectSwBaseInfo(SwBaseVO vo) throws Exception;

	public void insertSwInfo(SwVO vo) throws Exception;

}
