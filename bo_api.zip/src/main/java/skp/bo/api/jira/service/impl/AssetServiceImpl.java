package skp.bo.api.jira.service.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import skp.bo.api.SystemConstant;
import skp.bo.api.common.mail.MailProperties;
import skp.bo.api.common.mail.MailService;
import skp.bo.api.common.mail.MailTemplate;
import skp.bo.api.common.service.CodeService;
import skp.bo.api.common.vo.Code;
import skp.bo.api.hioms.mapper.HiOmsMapper;
import skp.bo.api.hioms.vo.ILMpersonInfoVO;
import skp.bo.api.http.BoResponseErrorHandler;
import skp.bo.api.jira.mapper.PcMapper;
import skp.bo.api.jira.mapper.SwMapper;
import skp.bo.api.jira.service.AssetService;
import skp.bo.api.jira.service.JiraRespService;
import skp.bo.api.jira.type.PcAssetStatusType;
import skp.bo.api.jira.type.PcAssetType;
import skp.bo.api.jira.type.SwAssetStatusType;
import skp.bo.api.jira.type.SwAssetType;
import skp.bo.api.jira.type.SwBaseType;
import skp.bo.api.jira.type.SwEmailGuideType;
import skp.bo.api.jira.type.SwUseStatusType;
import skp.bo.api.jira.vo.JiraCommonVO;
import skp.bo.api.jira.vo.JiraTransitionVO;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.jira.vo.pc.OaRequestDtVO;
import skp.bo.api.jira.vo.pc.PcApiVO;
import skp.bo.api.jira.vo.pc.PcAssetBasicVO;
import skp.bo.api.jira.vo.pc.PcVO;
import skp.bo.api.jira.vo.pc.ReqBasicVO;
import skp.bo.api.jira.vo.pc.ReqIssueVO;
import skp.bo.api.jira.vo.pc.ResPcAssetVO;
import skp.bo.api.jira.vo.sw.SwApiVO;
import skp.bo.api.jira.vo.sw.SwBaseVO;
import skp.bo.api.jira.vo.sw.SwVO;
import skp.bo.api.util.DateUtil;
import skp.bo.api.util.StaticPropertyUtil;

@Service
public class AssetServiceImpl implements AssetService{

	private static final Logger logger = LoggerFactory.getLogger(AssetServiceImpl.class);

	@Autowired
	private SwMapper swMapper;

	@Autowired
	private PcMapper pcMapper;

	@Autowired
	private HiOmsMapper omsMapper;

	@Autowired
	private JiraRespService jiraService;

	@Autowired
	private CodeService codeService;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public boolean chgJiraOaAssetStatus(String tagNo, String machinUseStatus) throws Exception{

		boolean result = false;

		List<PcApiVO> apiList = new ArrayList<>();
		PcApiVO vo = new PcApiVO();
		vo.setTagNo(tagNo);
		vo.setMachinUseStatus(machinUseStatus);
		apiList.add(vo);
		result = chgJiraOaAssetStatus(apiList);

		return result;
	}

	@Override
	public boolean chgJiraOaAssetStatus(List<PcApiVO> apiList) throws Exception{

		boolean result = true;

		for (PcApiVO pcApiVO : apiList) {
			logger.info("chgJiraPcAssetStatus tagno : {} , status_code : {}", pcApiVO.getTagNo(), pcApiVO.getMachinUseStatus());

			Code code = codeService.getCodeById("machin_use_status", pcApiVO.getMachinUseStatus());
			String pcAssetStatusName = code.getCodeName();

			PcVO pc = new PcVO();
			pc.setTagNo(pcApiVO.getTagNo());
			pc = pcMapper.selectPcInfo(pc);
			if(StringUtils.isEmpty(pc.getTicketKey()))
				return false;

			ResponseEntity<ResPcAssetVO> jiraOaAsset = getJiraInfo(pc.getTicketKey());
			PcAssetStatusType jiraStatus = PcAssetStatusType.fromString(jiraOaAsset.getBody().getFields().getStatus().getName());
			PcAssetStatusType requestStatus = PcAssetStatusType.fromString(pcAssetStatusName);

			List<String> pathList = setPath(jiraStatus, requestStatus);

			HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
			httpRequestFactory.setConnectTimeout(5000);
			httpRequestFactory.setReadTimeout(5000);
			HttpClient httpClient = HttpClientBuilder.create()
			 .setMaxConnTotal(999)
			 .setMaxConnPerRoute(999)
			 .build();
			httpRequestFactory.setHttpClient(httpClient);

			RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
			MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
	        restTemplate.getMessageConverters().add(converter);
	        restTemplate.setErrorHandler(new BoResponseErrorHandler());
	        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
	        		StaticPropertyUtil.getProperty("jira.restapi.id"),
	        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

	        String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.completed.url");

			for (String statusCode : pathList) {
				reqTicketInfoUrl = MessageFormat.format(reqTicketInfoUrl, pc.getTicketKey());
				JiraTransitionVO transition = new JiraTransitionVO();
				transition.setId(statusCode);
		        HttpHeaders reqHeaders = new HttpHeaders();
		        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
		        HashMap<String,Object> map = new HashMap<String,Object>();
		        map.put("transition", transition);
		        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

		        ResponseEntity<String> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, String.class);
		        logger.debug(responseEntity.getBody());
				if(responseEntity.getStatusCode().is2xxSuccessful()){
					result = true;
				}
			}
		}
		return result;
	}


	@Override
	public boolean chgJiraSwAssetStatus(String seq, SwAssetStatusType reqStatus) throws Exception{

		boolean result = false;

		if(seq == null){
			logger.error("## chgJiraSwAssetStatus String seq is null ##");
			return false;
		}else if(reqStatus == null){
			logger.error("## chgJiraSwAssetStatus SwAssetStatusType reqStatus is null ##");
			return false;
		}

		List<SwApiVO> apiList = new ArrayList<>();
		SwApiVO vo = new SwApiVO();
		vo.setSeq(seq);
		vo.setStatusType(reqStatus);
		apiList.add(vo);
		result = chgJiraSwAssetStatus(apiList);

		return result;
	}

	@Override
	public boolean chgJiraSwAssetStatus(List<SwApiVO> apiList) throws Exception{

		boolean result = true;

		for (SwApiVO swApiVO : apiList) {
			logger.debug("chgJiraSwAssetStatus seq : {} , status_code : {}", swApiVO.getSeq(), swApiVO.getStatusType().name());


			SwVO sw = new SwVO();
			sw.setSeq(swApiVO.getSeq());
			sw = swMapper.selectSwInfo(sw);
			if(StringUtils.isEmpty(sw.getTicketKey()))
				return false;

			ResponseEntity<ResPcAssetVO> jiraSwAsset = getJiraInfo(sw.getTicketKey());
			SwAssetStatusType jiraStatus = SwAssetStatusType.fromString(jiraSwAsset.getBody().getFields().getStatus().getName());

			List<String> pathList = setSwPath(jiraStatus, swApiVO.getStatusType());

			HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
			httpRequestFactory.setConnectTimeout(5000);
			httpRequestFactory.setReadTimeout(5000);
			HttpClient httpClient = HttpClientBuilder.create()
			 .setMaxConnTotal(999)
			 .setMaxConnPerRoute(999)
			 .build();
			httpRequestFactory.setHttpClient(httpClient);

			RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
			MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
	        restTemplate.getMessageConverters().add(converter);
	        restTemplate.setErrorHandler(new BoResponseErrorHandler());
	        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
	        		StaticPropertyUtil.getProperty("jira.restapi.id"),
	        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

	        String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.completed.url");

			for (String statusCode : pathList) {
				reqTicketInfoUrl = MessageFormat.format(reqTicketInfoUrl, sw.getTicketKey());
				JiraTransitionVO transition = new JiraTransitionVO();
				transition.setId(statusCode);
		        HttpHeaders reqHeaders = new HttpHeaders();
		        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
		        HashMap<String,Object> map = new HashMap<String,Object>();
		        map.put("transition", transition);
		        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

		        ResponseEntity<String> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, String.class);
		        logger.debug(responseEntity.getBody());
				if(responseEntity.getStatusCode().is2xxSuccessful()){
					result = true;
				}
			}
		}
		return result;
	}


	public ResponseEntity<ResPcAssetVO> getJiraInfo(String ticketId) throws Exception{
		RestTemplate restTemplate = new RestTemplate();
		String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url")+ticketId;
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(converter);
        restTemplate.setErrorHandler(new BoResponseErrorHandler());

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(reqHeaders);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));
        ifLog.debug("JIRA getJiraInfo IF start. ticket id : {}", ticketId);
        ResponseEntity<ResPcAssetVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.GET, requestEntity, ResPcAssetVO.class);
//        logger.info((String)responseEntity.getBody());

        return responseEntity;

	}

	private List<String> setPath(PcAssetStatusType jiraStatus, PcAssetStatusType requestStatus) throws Exception{

		List<String> list = new ArrayList<String>();

		List<String> rtnList = new ArrayList<String>();
		if(jiraStatus == requestStatus){
			return rtnList;
		}


//		if(jiraStatus == PcAssetStatusType.장비입고 && requestStatus == PcAssetStatusType.유휴){
//			list.add(PcAssetStatusType.임시직행플로우.getValue());
//			return list;
//		}

		if(jiraStatus == PcAssetStatusType.유휴){
			if(requestStatus == PcAssetStatusType.수령확인){
				requestStatus = PcAssetStatusType.유휴수령확인;
			}
		}

		if(jiraStatus == PcAssetStatusType.자산폐기
				|| jiraStatus == PcAssetStatusType.폐기대상
				|| requestStatus == PcAssetStatusType.자산폐기
				|| requestStatus == PcAssetStatusType.폐기대상
				){
			/**
			 * 1. 지라 OA Asset 혹은 요청상태가 자산폐기 or 폐기대상일 경우
			 */
			rtnList.add("created");	//장비입고
			rtnList.add("11");	//지급대기
			rtnList.add("71");	//수령확인
			rtnList.add("81");	//사용중
			if(jiraStatus == PcAssetStatusType.정기교체대상
					|| requestStatus == PcAssetStatusType.정기교체대상){
				rtnList.add("131");	//정기교체대상
			}
			rtnList.add("91");	//반납대기
			rtnList.add("101");	//유휴
			rtnList.add("141");	//폐기대상
			rtnList.add("151");	//자산폐기
		}
		else if(jiraStatus == PcAssetStatusType.유휴){
			/**
			 * 2. 특이 경로 - 지라 OA Asset 상태가 유휴일 경우
			 */
			rtnList.add("101");	//유휴
			rtnList.add("121");	//유휴수령확인
			rtnList.add("81");	//사용중
			if(requestStatus == PcAssetStatusType.정기교체대상){
				rtnList.add("131");	//정기교체대상
			}
			rtnList.add("91");	//반납대기
			rtnList.add("101");	//유휴

		}
		else{
			System.out.println("IF else");
			/**
			 * 3. 표준 경로.
			 */
			rtnList.add("created");	//장비입고
			rtnList.add("11");	//지급대기
			rtnList.add("71");	//수령확인
			rtnList.add("81");	//사용중
			if(jiraStatus == PcAssetStatusType.정기교체대상
					|| requestStatus == PcAssetStatusType.정기교체대상){
				rtnList.add("131");	//정기교체대상
			}
			rtnList.add("91");	//반납대기
			rtnList.add("101");	//유휴
			rtnList.add("121");	//유휴수령확인
			rtnList.add("81");	//사용중
			if(jiraStatus == PcAssetStatusType.정기교체대상
					|| requestStatus == PcAssetStatusType.정기교체대상){
				rtnList.add("131");	//정기교체대상
			}
			rtnList.add("91");	//반납대기
			rtnList.add("101");	//유휴

		}


		boolean startFlag = false;
		for (int i = 0; i < rtnList.size(); i++) {

			PcAssetStatusType path = PcAssetStatusType.toValuefromString(rtnList.get(i));
			if(jiraStatus == path){
				startFlag = true;
				continue;
			}

			if(startFlag){
				list.add(rtnList.get(i));
			}

			if(requestStatus == path){
				if(startFlag){
					break;
				}
			}
		}


		return list;
	}

	private List<String> setSwPath(SwAssetStatusType jiraStatus, SwAssetStatusType requestStatus) throws Exception{

		List<String> list = new ArrayList<String>();

		List<String> rtnList = new ArrayList<String>();
		if(jiraStatus == requestStatus){
			return rtnList;
		}


		if(jiraStatus == SwAssetStatusType.사용중 && requestStatus == SwAssetStatusType.사용대기){
			list.add(SwAssetStatusType.관리자초기화_사용대기.getValue());
			return list;
		}

		if(jiraStatus != SwAssetStatusType.SW입고
				&& requestStatus == SwAssetStatusType.사용대기){
			requestStatus = SwAssetStatusType.라이선스초기화_사용대기;
		}

		/**
		 * 3. 표준 경로.
		 */
		rtnList.add(SwAssetStatusType.SW입고.getValue());	//SW입고
		rtnList.add(SwAssetStatusType.사용대기.getValue());	//사용대기
		if(requestStatus == SwAssetStatusType.SW파기){
			rtnList.add(SwAssetStatusType.SW파기.getValue());	//SW파기
		}
		rtnList.add(SwAssetStatusType.설치확인.getValue());	//설치확인
		rtnList.add(SwAssetStatusType.사용중.getValue());	//사용중
		rtnList.add(SwAssetStatusType.반납대기.getValue());	//반납대기
		rtnList.add(SwAssetStatusType.반납확인.getValue());	//반납확인
		rtnList.add(SwAssetStatusType.라이선스_초기화.getValue());	//라이선스_초기화
		rtnList.add(SwAssetStatusType.라이선스초기화_사용대기.getValue());	//라이선스초기화_사용대기
		if(requestStatus == SwAssetStatusType.SW파기){
			rtnList.add(SwAssetStatusType.SW파기.getValue());	//SW파기
		}
		rtnList.add(SwAssetStatusType.설치확인.getValue());	//설치확인
		rtnList.add(SwAssetStatusType.사용중.getValue());	//사용중
		rtnList.add(SwAssetStatusType.반납대기.getValue());	//반납대기
		rtnList.add(SwAssetStatusType.반납확인.getValue());	//반납확인
		rtnList.add(SwAssetStatusType.라이선스_초기화.getValue());	//라이선스_초기화
		rtnList.add(SwAssetStatusType.라이선스초기화_사용대기.getValue());	//라이선스초기화_사용대기


		boolean startFlag = false;
		for (int i = 0; i < rtnList.size(); i++) {

			SwAssetStatusType path = SwAssetStatusType.toValuefromString(rtnList.get(i));
			if(jiraStatus == path){
				startFlag = true;
				continue;
			}

			if(startFlag){
				list.add(rtnList.get(i));
			}

			if(requestStatus == path){
				if(startFlag){
					break;
				}
			}
		}


		return list;
	}

	@Override
	public Boolean processOAasset(TicketInfoVO ticketInfo)throws Exception{

		boolean result = false;

		if( "OA장비교체신청".equals(ticketInfo.getDivision())){
			result = changeOA(ticketInfo);
		}else if("OA장비반납신청".equals(ticketInfo.getDivision())){
			result = returnOA(ticketInfo);
		}

		return result;
	}

	public Boolean changeOA(TicketInfoVO ticketInfo)throws Exception{
		boolean result = false;

		if("작업중".equals(ticketInfo.getStatus())){

			PcVO pc = new PcVO();
			pc.setTagNo(ticketInfo.getTagNo());
			pc = pcMapper.selectPcInfo(pc);

			//pc asset 의 상태가 '사용중' 이면 '반납대기'로 변경한다
			Code code = codeService.getCodeById("machin_use_status", pc.getUseStatus());

			if(PcAssetStatusType.사용중.name().equals(code.getCodeName())){
				//JIRA에 status 변경( > 설치확인 < ) 인터페이스 한다.
				jiraService.sendTicketStatus(pc.getTicketKey(), PcAssetStatusType.반납대기.getValue());
			}

			result = true;

		}

		return result;
	}

	public Boolean returnOA(TicketInfoVO ticketInfo)throws Exception{
		boolean result = false;

		if("작업중".equals(ticketInfo.getStatus())){

			PcVO pc = new PcVO();
			pc.setTagNo(ticketInfo.getTagNo());
			pc = pcMapper.selectPcInfo(pc);

			//pc asset 의 상태가 '사용중' 이면 '반납대기'로 변경한다
			Code code = codeService.getCodeById("machin_use_status", pc.getUseStatus());

			if(PcAssetStatusType.사용중.name().equals(code.getCodeName())){
				//JIRA에 status 변경( > 설치확인 < ) 인터페이스 한다.
				jiraService.sendTicketStatus(pc.getTicketKey(), PcAssetStatusType.반납대기.getValue());
			}

			result = true;

		}

		return result;
	}

	@Override
	public Boolean processSwAsset(TicketInfoVO ticketInfo)throws Exception{
		boolean result = false;

		if("SW사용신청".equals(ticketInfo.getDivision())){
//			result = requestSwAsset(ticketInfo);	//일단 수동으로 처리토록 하기로함 190430
			result = true;
		}else if("SW반납신청".equals(ticketInfo.getDivision())){
			/**
			 * JIRA 서비스데스크에서 DB연동이 불가함에 따라(반납대상SW를 알수 없음) SW반납신청은 adm web에서 관리자가 수동으로 처리하도록 한다. 19/04/02
			 */
//			result = returnSwAsset(ticketInfo);
			result = true;
		}


		return result;
	}

	@Override
	public Boolean requestSwAsset(TicketInfoVO ticketInfo)throws Exception{

		boolean result = false;
		/**
		 * TODO:: division이 SW사용신청 이고  티켓 status가  작업중 일때
		 * 요청 SW asset의 정보 변경 >>status를 설치확인 요청으로 변경, assignee 등 사용자 정보 셋팅후 jira sw asset update
		 * 요청 SR티켓은 위의 작업 종료후 자동 Closed로 변경
		 * 하는 로직 구현 필요. (신청자에게 설치방법 안내 메일발송 로직추가)
		 */

		if("작업중".equals(ticketInfo.getStatus())){
			/**
			 * 1. swManagementNo 로  SW 테이블에서 가용 SW 1개를 가져온다.
			 */
			SwVO sw = new SwVO();
			sw.setSwManagementNo(ticketInfo.getSwManagementNo());
			sw.setUseStatus(SwUseStatusType.사용대기.getValue());
			sw = swMapper.selectAvailableSwInfo(sw);

			//SW Base Info
			SwBaseVO swBase = new SwBaseVO();
			swBase.setSwManagementNo(ticketInfo.getSwManagementNo());
			swBase = swMapper.selectSwBaseInfo(swBase);

			//SW 사용자 정보
			ILMpersonInfoVO reporter = omsMapper.selectILMpersonInfo(ticketInfo.getReporterKey());

			//SW 설치가이드 이메일 종류
			SwEmailGuideType emailType = SwEmailGuideType.설치완료;

			if(sw == null){
				/**
				 * 1.1 가용 SW가 없을때
				 * 1.1.1 초과설치 가능 여부 확인 (현재 초과설치 가능한 SW는 모두 공용인증키 타입임)
				 */
				if(SwBaseType.계약수량초과설치가능.getValue().equals(swBase.getCertificationType())){
					/**
					 * 초과설치 가능 하면
					 * 1.1.1.2 공용인증키 여부 확인 - 공용일경우  software 테이블에 신규데이터 인서트 하고 jira에 sw asset 신규생성한다.
					 */
					if(SwBaseType.공용인증키.getValue().equals(swBase.getCertificationKey())){

						//SOFTWARE 테이블에 신규 insert 한다
						SwVO newSw = new SwVO();
						newSw.setSoftwareBaseSeq(swBase.getSeq());
						newSw.setUserId(reporter.getEmpno());
						newSw.setUserName(reporter.getHname());
						newSw.setDepartmentName(reporter.getDeptnm());
						newSw.setUseStatus(SwUseStatusType.사용대기.getValue());
						newSw.setLicense(swBase.getLicense());
						newSw.setFirstReqDate(DateUtil.currentTime("yyyy-MM-dd"));
						newSw.setRegUserId(SystemConstant.IBAS_API_ID);
						swMapper.insertSwInfo(newSw);

						//JIRA에 위의 신규 sw를 sw asset으로 생성한다
						boolean createSwAsset = jiraService.createJiraSwAsset(newSw.getSeq());

						if(createSwAsset){
							chgJiraSwAssetStatus(newSw.getSeq(), SwAssetStatusType.설치확인);
							if(SwBaseType.사용자직접설치.getValue().equals(swBase.getInstallStep())){
								//JIRA SR 티켓을 Closed 처리 한다.
								jiraService.sendTicketStatusCompleted(ticketInfo.getTicketKey());
							}
							emailType = SwEmailGuideType.설치완료;
							sw = newSw;
						}

					}else{
						/**
						 * 1.1.1.3 개별인증키인 경우 헬프데스크에 문의바람 안내메일 발송 후 종료
						 */
						emailType = SwEmailGuideType.수량초과불가_헬프데스크문의;
					}

				}else{
					/**
					 * 1.1.2 초과설치불가 - 헬프데스크에 문의바람 안내메일 발송 후 종료
					 */
					emailType = SwEmailGuideType.수량초과불가_헬프데스크문의;

				}
			}else{
				/**
				 * 2. 가용 SW가 존재하면 가용 SW Asset의 관리자, 사용자 정보를 수정 후 db update 한다
				 */
				SwVO paramSw = new SwVO();
				paramSw.setSeq(sw.getSeq());
				paramSw.setUserId(ticketInfo.getReporterKey());
				paramSw.setUserName(reporter.getHname());
				paramSw.setDepartmentName(reporter.getDeptnm());
				paramSw.setFirstReqDate("NOW");
				paramSw.setModUserId(SystemConstant.IBAS_API_ID);
				//DB update 하고
				swMapper.updateSwAsset(paramSw);
				//JIRA 에 update된 SW Asset 정보 update 인터페이스 하고
				jiraService.updateJiraSwAsset(sw.getSeq());
				//JIRA에 status 변경( > 설치확인 < ) 인터페이스 한다.
				chgJiraSwAssetStatus(sw.getSeq(), SwAssetStatusType.설치확인);
				if(SwBaseType.사용자직접설치.getValue().equals(swBase.getInstallStep())){
					//JIRA SR 티켓을 Closed 처리 한다.
					jiraService.sendTicketStatusCompleted(ticketInfo.getTicketKey());
				}
				result = true;
			}

			/**
			 * 신청자에게 설치 방법 EMAIL을 전송한다.
			 */
//			sendSwGuideEmail(sw.getSeq(), swBase, reporter, emailType);

        }



		return result;
	}

	public Boolean sendSwGuideEmail(String swSeq, SwBaseVO swBase, ILMpersonInfoVO reporter, SwEmailGuideType emailType) throws Exception{

		boolean result = false;

		SwVO sw = new SwVO();
		sw.setSeq(swSeq);
		sw = swMapper.selectSwInfo(sw);

		String mainText = "";
		String todayDate = DateUtil.currentTime("yyyy-MM-dd");;

		if(SwEmailGuideType.설치완료 == emailType){

			if(SwBaseType.사용자직접설치.getValue().equals(swBase.getInstallStep())){
				String mailTemplate = MailTemplate.getTemplate("OaSWinstallGuide_user.html");
				Map<String, String> valueMap = new HashMap<>();

				valueMap.put("todayDate", todayDate);
				valueMap.put("empno", reporter.getEmpno());
				valueMap.put("userName", reporter.getHname());
				valueMap.put("swName", swBase.getSoftwareName());

				if(StringUtils.isNotEmpty(sw.getLicense())){
					valueMap.put("license", sw.getLicense());
				}else if(StringUtils.isNotEmpty(swBase.getLicense())){
					valueMap.put("license", swBase.getLicense());
				}else{
					valueMap.put("license", "");
				}
				valueMap.put("installStep", swBase.getInstallStep());
				valueMap.put("installType", swBase.getInstallType());
				valueMap.put("installUrl", swBase.getInstallUrl());

				mainText = MailTemplate.setTemplateValue(mailTemplate, valueMap);
			}else{
				//헬프데스크 문의
				String mailTemplate = MailTemplate.getTemplate("OaSWinstallGuide_helpdesk.html");
				Map<String, String> valueMap = new HashMap<>();

				valueMap.put("todayDate", todayDate);
				valueMap.put("empno", reporter.getEmpno());
				valueMap.put("userName", reporter.getHname());
				valueMap.put("swName", swBase.getSoftwareName());

				mainText = MailTemplate.setTemplateValue(mailTemplate, valueMap);

			}

		}else if(SwEmailGuideType.수량초과불가_헬프데스크문의 == emailType){

			//헬프데스크 문의
			String mailTemplate = MailTemplate.getTemplate("OaSWinstallGuide_helpdesk.html");
			Map<String, String> valueMap = new HashMap<>();

			valueMap.put("todayDate", todayDate);
			valueMap.put("empno", reporter.getEmpno());
			valueMap.put("userName", reporter.getHname());
			valueMap.put("swName", swBase.getSoftwareName());

			mainText = MailTemplate.setTemplateValue(mailTemplate, valueMap);

		}

		MailProperties mailProp = new MailProperties();
		mailProp.setFrom("11st.1900010@sk.com");
		mailProp.setTo(reporter.getEmail());
		mailProp.setCc(new String[]{"11st.1900010@sk.com"});
		mailProp.setSubject("[안내] Software 설치");
		mailProp.setMainText(mainText);

		try {
			result = MailService.sendMail(mailProp);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SOFTWARE EMAIL : "+mailProp.toString());
		}

		logger.info("SOFTWARE EMAIL : "+mailProp.toString());

		return result;
	}


	@Override
	public Boolean returnSwAsset(TicketInfoVO ticketInfo)throws Exception{

		boolean result = false;

		if("작업중".equals(ticketInfo.getStatus())){

			SwVO sw = new SwVO();
			sw.setTicketKey(ticketInfo.getSwlAssetKey());
			sw = swMapper.selectSwInfo(sw);

			//SW Asset 상태가 사용중 일 경우 반납대기로 변경한다
			if("US04".equals(sw.getUseStatus())){
				//JIRA에 status 변경( > 반납대기 < ) 인터페이스 한다.
//				jiraService.sendTicketStatus(ticketInfo.getSwlAssetKey(), SwAssetStatusType.반납대기.getValue());
				chgJiraSwAssetStatus(sw.getSeq(), SwAssetStatusType.반납대기);
			}

			result = true;
		}

		return result;
	}


	private static final Logger ifLog = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_JIRA);

	/**
	 * 마이그레이션 용
	 * BOAPI >>> JIRA PC Asset 등록
	 */
//	@Override
	public boolean migrationJiraPcAsset() throws Exception{

		boolean result = false;

		PcVO pc = new PcVO();
		/**
		 * TODO : 아래 tagno 입력시 1건 등록, 미입력시 전체 등록
		 */
		List<PcVO> pcList = new ArrayList<PcVO>();
		pcList = pcMapper.selectPcList(pc);

		int iLoop = 1;
		for (PcVO pcVO : pcList) {

			JiraCommonVO project = new JiraCommonVO();
			project.setKey(PcAssetType.PROJECT_KEY.getValue());
			JiraCommonVO issue = new JiraCommonVO();
			issue.setName(PcAssetType.ISSUE_TYPE.getValue());
			JiraCommonVO assignee = new JiraCommonVO();
			assignee.setName(pcVO.getAdminId());

			PcAssetBasicVO asset = new PcAssetBasicVO();
			asset.setProject(project);
			asset.setSummary(pcVO.getModelCode());
			asset.setDescription(pcVO.getNote());
			asset.setIssuetype(issue);
			asset.setDuedate(pcVO.getReturnPlanDate());
			asset.setAssignee(assignee);

			//OA관리자셋팅
			JiraCommonVO adminOA = new JiraCommonVO();
			adminOA.setName(pcVO.getAdminId());
			asset.setCustomfield_17313(adminOA);

			//OA사용자
			JiraCommonVO userOA = new JiraCommonVO();
			userOA.setName(pcVO.getUserId());
			asset.setCustomfield_17205(userOA);

			//OA자산코드
			asset.setCustomfield_17200(pcVO.getTagNo());

			//OA모델명
			asset.setCustomfield_17201(pcVO.getModelCode());

			//OA기기용도
			Code pcUseCodeInfo = codeService.getCodeById("machin_use", pcVO.getUseCode());
			JiraCommonVO assetUseCode = new JiraCommonVO();
			assetUseCode.setValue(pcUseCodeInfo.getCodeName()); //16600[일반용], 16601[대여용], 16603[개인용], 16604[교육용], 16605[해외용], 16606[임원용], 16607[SOC용]
			asset.setCustomfield_17202(assetUseCode);

			//OA기기구분
			pcUseCodeInfo = codeService.getCodeById("machin_type", pcVO.getMachinType());
			JiraCommonVO assetMachinType = new JiraCommonVO();
			assetMachinType.setValue(pcUseCodeInfo.getCodeName());
			asset.setCustomfield_17312(assetMachinType);


			String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url");
	        restTemplate.setErrorHandler(new BoResponseErrorHandler());

	        HttpHeaders reqHeaders = new HttpHeaders();
	        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
	        HashMap<String,Object> map = new HashMap<String,Object>();
	        map.put("fields", asset);
	        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

	        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
	        		StaticPropertyUtil.getProperty("jira.restapi.id"),
	        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

	        ResponseEntity<ResPcAssetVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, ResPcAssetVO.class);
	        PcVO paramPc = new PcVO();
	        paramPc.setTagNo(pcVO.getTagNo());
	        paramPc.setJiraResultMsg("insert");
	        if(responseEntity.getStatusCode().is2xxSuccessful()){
				if(StringUtils.isNotEmpty(responseEntity.getBody().getId())){
					paramPc.setTicketId(responseEntity.getBody().getId());
					paramPc.setTicketKey(responseEntity.getBody().getKey());
				}
				paramPc.setJiraResult("true");
				result = true;
	        }else{
	        	paramPc.setJiraResult("false");
				result = false;
	        }
	        ifLog.info("MIGRATION INSERT PC ASSET COUNT : {}, TAG_NO : {} ", iLoop, pcVO.getTagNo());
	        pcMapper.updatePcAsset(paramPc);

	        /**
	         * PC Asset 티켓 상태를 지급대기로 변경한다.
	         * TODO : ASIS의 티켓 상태를 확인하여 각 상태별로 status 변경 할수 있도록 상태별 프로세스 짜놔야...
	         */
	        if(result)
	        	jiraService.sendTicketStatus(paramPc.getTicketKey(), PcAssetStatusType.지급대기.getValue());

	        /**
	         * ASIS 히스토리 정보를 코멘트로 등록한다
	         * TODO : 코멘트로 등록할 String 형식 협의 필요.
	         */
	        OaRequestDtVO tagVO = new OaRequestDtVO();
	        tagVO.setTagNo(pcVO.getTagNo());
	        List<OaRequestDtVO> commentList = pcMapper.selectOaRequestDtList(tagVO);
	        String sComment = "";
	        for (OaRequestDtVO comment : commentList) {
	        	sComment = "[" + comment.getTicketTime() + "] - " + comment.getRequestCodeNm() + "\n";
	        	sComment += "용도 : " + comment.getRequestCodeNm() +"\n";
	        	sComment += "관리자 : " + comment.getAdminId() + " ("+ comment.getRequestDept() + "), ";
	        	sComment += "사용자 : " + comment.getUserName() + "("+ comment.getUserDept() + ")\n";
	        	sComment += "사용장소 : " + comment.getUseLocation() + "," + comment.getUseLocationDt() + "\n";
	        	sComment += "비고 : " + comment.getChgNote();
	        	jiraService.sendTicketComment(paramPc.getTicketKey(), sComment);
			}

	        iLoop++;

		}// for (PcVO pcVO : pcList) { END

		return result;

	}


	private static final Logger jiralogger = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_JIRA);
	/**
	 * BOAPI >>정보조회요청>> JIRA >>> BOAPI OA Asset 강제 업데이트
	 */
	@Override
	public void updatePcAssetForceSync(String assetId) throws Exception{

		try {
			String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url")+assetId;

			RestTemplate restTemplate = new RestTemplate();
			MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
			restTemplate.getMessageConverters().add(converter);
			restTemplate.setErrorHandler(new BoResponseErrorHandler());

			HttpHeaders reqHeaders = new HttpHeaders();
			reqHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<?> requestEntity = new HttpEntity<Object>(reqHeaders);

			restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
					StaticPropertyUtil.getProperty("jira.restapi.id"),
					StaticPropertyUtil.getProperty("jira.restapi.pw")));
			ResponseEntity<ReqIssueVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.GET, requestEntity, ReqIssueVO.class);

			if(responseEntity.getBody() == null) return;

			ReqBasicVO assetInfo = new ReqBasicVO();
			assetInfo.setIssue(responseEntity.getBody());

			/**
			 * 1. pc 정보 업데이트
			 */
			String assetStatus = assetInfo.getIssue().getFields().getStatus().getName();
			String tagNo = assetInfo.getIssue().getFields().getCustomfield_17200();
			PcVO pc = new PcVO();
			pc.setTagNo(tagNo);
			pc.setTicketId(assetInfo.getIssue().getId());
			pc.setTicketKey(assetInfo.getIssue().getKey());
			pc.setModelCode(assetInfo.getIssue().getFields().getCustomfield_17201());
			pc.setUserId(assetInfo.getIssue().getFields().getCustomfield_17205().getName());
			pc.setUserName(assetInfo.getIssue().getFields().getCustomfield_17205().getDisplayName());
			pc.setAdminId(assetInfo.getIssue().getFields().getCustomfield_17313().getName());
			pc.setAdminName(assetInfo.getIssue().getFields().getCustomfield_17313().getDisplayName());
			pc.setNote(assetInfo.getIssue().getFields().getDescription());
			pc.setReturnPlanDate(assetInfo.getIssue().getFields().getDuedate());
			Code codeInfo = codeService.getCodeByName("machin_use", assetInfo.getIssue().getFields().getCustomfield_17202().getValue());
			pc.setUseCode(codeInfo.getCodeId());
			codeInfo = codeService.getCodeByName("machin_type", assetInfo.getIssue().getFields().getCustomfield_17312().getValue());
			pc.setMachinType(codeInfo.getCodeId());
			codeInfo = codeService.getCodeByName("machin_use_status", assetStatus);
			pc.setUseStatus(codeInfo.getCodeId());

			pcMapper.updatePcAsset(pc);

			/**
			 * 2. 코멘트 정보 업데이트
			 */
			jiraService.setCommentInfo(assetInfo);

			/**
			 * 3.첨부파일 정보 업데이트
			 */
			jiraService.setAttachment(assetInfo);

			jiralogger.info("Force Asset Sync,"+ assetId);
		} catch (Exception e) {
			e.printStackTrace();
			jiralogger.error("Force Asset Sync,"+ assetId+",error");
		}

	}


	@Override
	public void migrationJiraSwAsset() throws Exception{

		ifLog.info("########## migrationJiraSwAsset START ##########");

		SwVO param = new SwVO();
		param.setJiraResult("false");
		List<SwVO> targetList = swMapper.selectSwList(param);

		for (SwVO sw : targetList) {

			try {
				genJiraSwAssets(sw);
			} catch (Exception e) {
				ifLog.error("MIG SW ERROR SEQ :  " + sw.getSeq());
				e.printStackTrace();
			}

		}

		ifLog.info("########## migrationJiraSwAsset END ##########");

	}

	@Async
	@Override
	public void migrationJiraSwAsset2(String seq) throws Exception{

		ifLog.info("########## migrationJiraSwAsset START ##########");

		SwVO param = new SwVO();
		param.setSeq(seq);
		SwVO sw = swMapper.selectSwInfo(param);

		try {
			genJiraSwAssets(sw);
		} catch (Exception e) {
			ifLog.error("MIG SW ERROR SEQ :  " + sw.getSeq());
			e.printStackTrace();
		}

		ifLog.info("########## migrationJiraSwAsset END ##########");

	}

	private void genJiraSwAssets(SwVO sw) {
		boolean result = false;

		try {

			if(sw != null)
			{

				SwBaseVO swBase = new SwBaseVO();
				swBase.setSeq(sw.getSoftwareBaseSeq());
				swBase = swMapper.selectSwBaseInfo(swBase);

				JiraCommonVO project = new JiraCommonVO();
				project.setKey(SwAssetType.PROJECT_KEY.getValue());
				JiraCommonVO issue = new JiraCommonVO();
				issue.setName(SwAssetType.ISSUE_TYPE.getValue());
				JiraCommonVO assignee = new JiraCommonVO();
				assignee.setName(sw.getUserId());

				PcAssetBasicVO asset = new PcAssetBasicVO();
				asset.setProject(project);
				asset.setSummary(swBase.getSoftwareName());
				asset.setDescription(sw.getNote());
				asset.setIssuetype(issue);
//					asset.setDuedate(pcVO.getReturnPlanDate());
				asset.setAssignee(assignee);

				//OA사용자
				JiraCommonVO userOA = new JiraCommonVO();
				userOA.setName(sw.getUserId());
				asset.setCustomfield_17205(userOA);

				//OA자산코드
//					asset.setCustomfield_17200(sw.getTicketKey());

				String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url");

		        restTemplate.setErrorHandler(new BoResponseErrorHandler());

		        HttpHeaders reqHeaders = new HttpHeaders();
		        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
		        HashMap<String,Object> map = new HashMap<String,Object>();
		        map.put("fields", asset);
		        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

		        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
		        		StaticPropertyUtil.getProperty("jira.restapi.id"),
		        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

		        ResponseEntity<ResPcAssetVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, ResPcAssetVO.class);
		        SwVO paramSw = new SwVO();
		        paramSw.setSeq(sw.getSeq());
		        paramSw.setJiraResultMsg("insert");

		        if(responseEntity.getStatusCode().is2xxSuccessful()){
					if(StringUtils.isNotEmpty(responseEntity.getBody().getId())){
						paramSw.setTicketId(responseEntity.getBody().getId());
						paramSw.setTicketKey(responseEntity.getBody().getKey());
					}
					paramSw.setJiraResult("true");
					result = true;
		        }else{
		        	paramSw.setJiraResult("false");
		        	paramSw.setJiraResultMsg(responseEntity.getHeaders().get("error_body_string").get(0));
					result = false;
		        }

		        ifLog.info("INSERT SOFTWARE ASSET SEQ : "+sw.getSeq() + " JIRA KEY : " + paramSw.getTicketKey());
		        swMapper.updateSwAsset(paramSw);

		        /*
		         * SW Asset 티켓 상태를 사용대기로 변경한다.
		         */
		        if(result){
		        	SwUseStatusType status =  SwUseStatusType.toValuefromString(sw.getUseStatus());
		        	this.chgJiraSwAssetStatus(sw.getSeq(), SwAssetStatusType.fromString(status.name()));
		        }

			}// END if(sw ==null) else

		} catch (Exception e) {
			e.printStackTrace();
		}
	}



}
