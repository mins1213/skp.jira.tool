package skp.bo.api.jira.vo.pc;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import skp.bo.api.jira.vo.JiraAttachmentVO;
import skp.bo.api.jira.vo.JiraCommentsVO;
import skp.bo.api.jira.vo.JiraCommonVO;

public class PcAssetBasicVO {

	/**
	 * ASSET 고정값
	 */
	private JiraCommonVO project = null;

	private String summary = null;
	private String description = null;

	/**
	 * OA자산 고정값
	 */
	private JiraCommonVO issuetype = null;

	/**
	 * 반납예정일
	 */
	private String duedate = null;
	/**
	 * 자산코드 tag_no
	 */
	private String customfield_17200 = null;
	/**
	 * 모델명 model_code
	 */
	private String customfield_17201 = null;
	/**
	 * OA기기용도 use_code
	 */
	private JiraCommonVO customfield_17202 = null;
	/**
	 * OA기기구분
	 */
	private JiraCommonVO customfield_17312 = null;
	/**
	 * OA사용자 정보 user_name
	 */
	private JiraCommonVO customfield_17205 = null;

	/**
	 * OA관리자 admin_id
	 */
	private JiraCommonVO customfield_17313 = null;
	/**
	 * assignee
	 */
	private JiraCommonVO assignee = null;

	/**
	 * status 상태.
	 */
	private JiraCommonVO status = null;

	/**
	 * 코멘트 객체
	 */
	private JiraCommentsVO comment = null;

	/**
	 * 첨부파일 객체
	 */
	private List<JiraAttachmentVO> attachment = null;





	public JiraCommonVO getStatus() {
		return status;
	}

	public void setStatus(JiraCommonVO status) {
		this.status = status;
	}

	public List<JiraAttachmentVO> getAttachment() {
		return attachment;
	}

	public void setAttachment(List<JiraAttachmentVO> attachment) {
		this.attachment = attachment;
	}

	public JiraCommentsVO getComment() {
		return comment;
	}

	public void setComment(JiraCommentsVO comment) {
		this.comment = comment;
	}


	public JiraCommonVO getProject() {
		return project;
	}

	public void setProject(JiraCommonVO project) {
		this.project = project;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public JiraCommonVO getIssuetype() {
		return issuetype;
	}

	public void setIssuetype(JiraCommonVO issuetype) {
		this.issuetype = issuetype;
	}

	public String getDuedate() {
		return duedate;
	}

	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}

	public String getCustomfield_17200() {
		return customfield_17200;
	}

	public void setCustomfield_17200(String customfield_17200) {
		this.customfield_17200 = customfield_17200;
	}



	public JiraCommonVO getAssignee() {
		return assignee;
	}

	public void setAssignee(JiraCommonVO assignee) {
		this.assignee = assignee;
	}

	public String getCustomfield_17201() {
		return customfield_17201;
	}

	public void setCustomfield_17201(String customfield_17201) {
		this.customfield_17201 = customfield_17201;
	}



	public JiraCommonVO getCustomfield_17202() {
		return customfield_17202;
	}

	public void setCustomfield_17202(JiraCommonVO customfield_17202) {
		this.customfield_17202 = customfield_17202;
	}

	public JiraCommonVO getCustomfield_17312() {
		return customfield_17312;
	}

	public void setCustomfield_17312(JiraCommonVO customfield_17312) {
		this.customfield_17312 = customfield_17312;
	}

	public JiraCommonVO getCustomfield_17205() {
		return customfield_17205;
	}

	public void setCustomfield_17205(JiraCommonVO customfield_17205) {
		this.customfield_17205 = customfield_17205;
	}

	public JiraCommonVO getCustomfield_17313() {
		return customfield_17313;
	}

	public void setCustomfield_17313(JiraCommonVO customfield_17313) {
		this.customfield_17313 = customfield_17313;
	}

	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
