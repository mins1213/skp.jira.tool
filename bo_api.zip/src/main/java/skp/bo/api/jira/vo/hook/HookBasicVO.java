package skp.bo.api.jira.vo.hook;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * PC asset JIRA Hooker URL로 인입하는 ReQ 대응
 * @author SONY
 *
 */
public class HookBasicVO {

	private HookIssueVO issue;



	public HookIssueVO getIssue() {
		return issue;
	}



	public void setIssue(HookIssueVO issue) {
		this.issue = issue;
	}



	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
