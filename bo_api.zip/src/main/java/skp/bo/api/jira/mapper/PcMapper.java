package skp.bo.api.jira.mapper;

import java.util.List;

import skp.bo.api.jira.vo.pc.OaRequestDtVO;
import skp.bo.api.jira.vo.pc.PcVO;

public interface PcMapper {

	public List<PcVO> selectPcList(PcVO vo) throws Exception;

	public PcVO selectPcInfo(PcVO vo) throws Exception;

	public void updatePcAsset(PcVO vo) throws Exception;

	public List<OaRequestDtVO> selectOaRequestDtList(OaRequestDtVO vo) throws Exception;

}
