package skp.bo.api.jira.service.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import skp.bo.api.SystemConstant;
import skp.bo.api.common.service.CodeService;
import skp.bo.api.common.vo.Code;
import skp.bo.api.hioms.mapper.HiOmsMapper;
import skp.bo.api.hioms.service.HiOmsService;
import skp.bo.api.hioms.vo.HiOmsRequestInfoVO;
import skp.bo.api.hioms.vo.HiOmsUserVO;
import skp.bo.api.hioms.vo.ILMpersonInfoVO;
import skp.bo.api.http.BoResponseErrorHandler;
import skp.bo.api.http.LoggingRequestInterceptor;
import skp.bo.api.jira.mapper.JiraTicketMapper;
import skp.bo.api.jira.mapper.PcMapper;
import skp.bo.api.jira.mapper.SwMapper;
import skp.bo.api.jira.service.AssetService;
import skp.bo.api.jira.service.JiraRespService;
import skp.bo.api.jira.type.JiraResponseType;
import skp.bo.api.jira.type.PcAssetType;
import skp.bo.api.jira.type.SwAssetStatusType;
import skp.bo.api.jira.type.SwAssetType;
import skp.bo.api.jira.vo.AttachmentVO;
import skp.bo.api.jira.vo.JiraAttachmentVO;
import skp.bo.api.jira.vo.JiraCommentVO;
import skp.bo.api.jira.vo.JiraCommonVO;
import skp.bo.api.jira.vo.JiraTransitionVO;
import skp.bo.api.jira.vo.TicketCommentVO;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.jira.vo.pc.PcAssetBasicVO;
import skp.bo.api.jira.vo.pc.ResPcAssetVO;
import skp.bo.api.jira.vo.sw.SwApiVO;
import skp.bo.api.jira.vo.sw.SwBaseVO;
import skp.bo.api.jira.vo.sw.SwVO;
import skp.bo.api.jira.vo.pc.PcVO;
import skp.bo.api.jira.vo.pc.ReqBasicVO;
import skp.bo.api.silhouette.service.SilhouetteService;
import skp.bo.api.util.DateUtil;
import skp.bo.api.util.StaticPropertyUtil;

@Service("skp.bo.api.jira.service.JiraRespService")
public class JiraRespServiceImpl implements JiraRespService{

	private static final Logger logger = LoggerFactory.getLogger(JiraRespServiceImpl.class);
	private static final Logger ifLog = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_JIRA);

	@Autowired
	JiraTicketMapper jiraTicketMapper;

	@Autowired
	HiOmsMapper hiOmsMapper;

	@Autowired
	SwMapper swMapper;

	@Autowired
	PcMapper pcMapper;

	@Resource(name="skp.bo.api.hioms.service.HiOmsService")
	HiOmsService hiOmsService;

	@Resource(name="skp.bo.api.silhouette.service.silhouetteService")
	SilhouetteService silhouetteService;

	@Resource(name="skp.bo.api.common.service.CodeService")
	CodeService codeService;

	@Autowired
	AssetService assetService;


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String parseTicketId(Map jsonMap) throws Exception{

		String ticketId = "";

		Map<String, Object> issueMap = (Map<String, Object>)jsonMap.get("issue");
		ticketId = (String)issueMap.get("id");

		ifLog.info("JIRA WebHooker send ticket. id : {}", ticketId);

		return ticketId;
	}

	public void requestJiraTicketInfo(Map<String, Object> issueMap) throws Exception{

		String ticketId = (String)issueMap.get("id");
		String ticketKey = (String)issueMap.get("key");
		String corpGubun = (String)issueMap.get("corpGubun");

		requestJiraTicketInfo(ticketId, ticketKey, corpGubun);

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@Transactional
	public void requestJiraTicketInfo(String ticketId, String ticketKey, String corpGubun) throws Exception{

		String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url")+ticketId;

		if(SystemConstant.CORP_GUBUN_SKP.equals(corpGubun))
			reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url.skp")+ticketId;

		RestTemplate restTemplate = new RestTemplate();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(converter);
        restTemplate.setErrorHandler(new BoResponseErrorHandler());

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(reqHeaders);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));
        ifLog.info("JIRA requestJiraTicketInfo IF start. ticket id : {}", ticketId);
        ResponseEntity<Map> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.GET, requestEntity, Map.class);
//        ResponseEntity<String> responseEntity2 = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.GET, requestEntity, String.class);
//        ifLog.info(responseEntity2.getBody());

		Map<String, Object> totalMap = (Map<String, Object>) responseEntity.getBody();
        Map<String, Object> fieldsMap = (Map<String, Object>) totalMap.get("fields");
        Integer iTicketId = Integer.parseInt((String)totalMap.get("id"));

        /*
         * 0. 기등록된 티켓인지 확인.
         */
        TicketInfoVO paramSelectTicketInfo = new TicketInfoVO();
        paramSelectTicketInfo.setTicketId(Integer.parseInt(ticketId));
        paramSelectTicketInfo.setCorpGubun(corpGubun);
        TicketInfoVO ticketInfo = jiraTicketMapper.selectTicketInfo(paramSelectTicketInfo);

        /*
         * 1. 티켓 기본 정보 등록
         */
        TicketInfoVO paramTicketInfoVO = setBasicTicketInfo(iTicketId, corpGubun, ticketInfo, totalMap, fieldsMap);


        /*
         * PC asset용 프로세스
         * 1. 장비교체, 장비반납 SR 티켓이 '작업중' 상태일때 대상OA asset의 상태를 '반납대기'로 변경한다
         * OA asset 임시저장 로직 신규로 인해 기능 막음
         */
//        if(paramTicketInfoVO.getDivision().startsWith("OA"))
//        	assetService.processOAasset(paramTicketInfoVO);

        /*
         * SW asset용 프로세스
         * 1. division이 SW사용신청 이고 티켓 status가  작업중 일때 요청 SW를 설치확인 으로 변경 (신청자에게 설치방법 안내 메일발송 로직추가)
         * 2. division이 SW반납신청 일때 티켓이 들어오자마자 반납 요청 SW Asset를 사용중 >> 반납대기 로 변경.
         */

        if(paramTicketInfoVO.getDivision().startsWith("SW"))
        	assetService.processSwAsset(paramTicketInfoVO);


        /*
         * 1.1 코멘트 정보 등록
         */
        Map<String, Object> commentMap = (Map<String, Object>)fieldsMap.get("comment");
        if(commentMap != null) setCommentInfo(iTicketId, corpGubun, commentMap);
        /*
         * 1.2 첨부파일 정보 등록
         */
        ArrayList<Map<String, Object>> attachmentList = (ArrayList<Map<String, Object>>)fieldsMap.get("attachment");
        if(attachmentList != null) setAttachment(iTicketId, corpGubun, attachmentList);

//        ifLog.info(responseEntity.getStatusCode().toString());
//        ifLog.info(responseEntity.getBody().toString());

        /**
         * 2. HI OMS & 실루엣 연동
         * assignee key값이 hioms_user 테이블에 존재할 경우 hioms & 실루엣 연동을 한다.
         * 1회만 인터페이스 한다. 다만 첫 req에 assignee가 없을 수 있다.
         * 티켓 상태가 '작업중' 이며  assignee가 존재하며 hioms_user 에 있을경우, api_hioms_request_info 테이블 조회하여 데이터 없을때만 인터페이스 실행(and 조건)
         */
        if(JiraResponseType.TICKET_STATUS_ING.getValue().equals(paramTicketInfoVO.getStatus())){
        	if(paramTicketInfoVO.getAssigneeKey() != null && StringUtils.isNotEmpty(paramTicketInfoVO.getAssigneeKey())){
            	if(!JiraResponseType.DEVICE_REQ.getValue().equals(paramTicketInfoVO.getDivision())){

            		List<HiOmsUserVO> omsUserInfoList = hiOmsMapper.selectHiOmsUserList(paramTicketInfoVO.getAssigneeKey());

            		if(omsUserInfoList != null && omsUserInfoList.size() > 0){

                    	HiOmsRequestInfoVO paramHioms = new HiOmsRequestInfoVO();
                    	paramHioms.setTicketId(iTicketId);
                    	paramHioms.setIfGubun("H");
                    	paramHioms.setCorpGubun(corpGubun);
                    	HiOmsRequestInfoVO hiomsInfo = hiOmsMapper.selectHiomsInfoById(paramHioms);
                    	if(hiomsInfo == null){
                    		//1. hioms 연동
                        	hiOmsService.sendTicketRequestToHiOms(Integer.toString(paramTicketInfoVO.getTicketId()), corpGubun);
                    	}//if(hiomsInfo == null){ END

                    	paramHioms = new HiOmsRequestInfoVO();
                    	paramHioms.setTicketId(iTicketId);
                    	paramHioms.setIfGubun("S");
                    	paramHioms.setCorpGubun(corpGubun);
                    	hiomsInfo = hiOmsMapper.selectHiomsInfoById(paramHioms);
                    	if(hiomsInfo == null){
                        	//2. 실루엣 연동
                        	silhouetteService.sendTicketRequestToSilhouette(Integer.toString(paramTicketInfoVO.getTicketId()), corpGubun);
                    	}//if(hiomsInfo == null){ END

                    }
                }
            }
        }//JiraResponseType.TICKET_STATUS_ING END


	}

	@SuppressWarnings("unchecked")
	private TicketInfoVO setBasicTicketInfo(
			Integer iTicketId, String corpGubun, TicketInfoVO ticketInfo, Map<String, Object> totalMap, Map<String, Object> fieldsMap) throws Exception {
		TicketInfoVO paramTicketInfoVO = new TicketInfoVO();

        paramTicketInfoVO.setTicketId(iTicketId);	//티켓ID
        paramTicketInfoVO.setTicketKey((String)totalMap.get("key"));	//티켓
        paramTicketInfoVO.setCorpGubun(corpGubun);	//회사 구분자
        if(ticketInfo != null && StringUtils.isNotEmpty(ticketInfo.getCorpGubun())){
        	paramTicketInfoVO.setCorpGubun(ticketInfo.getCorpGubun());	//회사 구분자

    	}

        String summary = (String)fieldsMap.get("summary");
        if(StringUtils.isNotEmpty(summary)) summary = Normalizer.normalize(summary, Normalizer.Form.NFC);	//JIRA에서 제목을 수정시에 자음모음 분리현상이 일어난다
        paramTicketInfoVO.setSummary(summary);	//제목
        paramTicketInfoVO.setDescription((String)fieldsMap.get("description"));	//내용상세
        paramTicketInfoVO.setCreateDate((String)fieldsMap.get("created"));	//생성일시
        paramTicketInfoVO.setUpdateDate((String)fieldsMap.get("updated"));	//수정일시
        String duedate = (String)fieldsMap.get("duedate");
        if(StringUtils.isEmpty(duedate)){
        	if(ticketInfo != null && StringUtils.isNotEmpty(ticketInfo.getDueDate())){
        		paramTicketInfoVO.setDueDate(ticketInfo.getDueDate());	//완료요청일

        	}else{
        		String now = DateUtil.currentTime("yyyyMMdd");
        		String after3day = DateUtil.addDay(now, 3); //return yyyy-MM-dd
        		paramTicketInfoVO.setDueDate(DateUtil.formatDate(after3day, "-"));	//완료요청일
        	}
        }else{
        	paramTicketInfoVO.setDueDate(duedate);	//완료요청일
        }

        if(fieldsMap.get("resolution") != null){
        	paramTicketInfoVO.setResolution((String)((Map<String,Object>)fieldsMap.get("resolution")).get("name"));	//해결상태
        	paramTicketInfoVO.setResolutionDate((String)fieldsMap.get("resolutiondate"));	//해결일시
        }

        Map<String, Object> reporterMap = (Map<String, Object>)fieldsMap.get("reporter");
        if(reporterMap !=null){
        	paramTicketInfoVO.setReporterKey((String)reporterMap.get("name"));			//생성자ID
            paramTicketInfoVO.setReporterName((String)reporterMap.get("displayName"));		//생성자명
        }

        Map<String, Object> assigneeMap = (Map<String, Object>)fieldsMap.get("assignee");
        if(assigneeMap != null){
        	paramTicketInfoVO.setAssigneeKey((String)assigneeMap.get("name"));			//처리자ID
            paramTicketInfoVO.setAssigneeName((String)assigneeMap.get("displayName"));	//처리자명
        }

        //승인자 필드는 리스트지만 최종 1명만 값이 넘어온다.
        ArrayList<Map<String, Object>> approverList =
        		(ArrayList<Map<String, Object>>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.approval"));
        if(approverList != null){
            for (Map<String, Object> approverMap : approverList) {
            	paramTicketInfoVO.setApproverKey((String)approverMap.get("name"));			//승인자ID
                paramTicketInfoVO.setApproverName((String)approverMap.get("displayName"));	//승인자명
    		}
        }

        Map<String, Object> projectMap = (Map<String, Object>)fieldsMap.get("project");
        if(projectMap != null)
        	paramTicketInfoVO.setCategory((String)projectMap.get("name"));	//대분류

        Map<String, Object> issuetypeMap = (Map<String, Object>)fieldsMap.get("issuetype");
        if(issuetypeMap != null){
        	String division = (String)issuetypeMap.get("name");
        	if(StringUtils.isNotEmpty(division))
        		paramTicketInfoVO.setDivision(division.trim());	//중분류(Type)
        }


        Map<String, Object> customMap = new HashMap<String, Object>();
        //인트라넷 개발요청
        if(JiraResponseType.INTRANET_DEV_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.intranet_dev_req"));
        }
        //인트라넷 권한신청 & 운영지원요처
        else if(JiraResponseType.INTRANET_AUTH_REQ.getValue().equals(paramTicketInfoVO.getDivision())
        		|| JiraResponseType.INTRANET_HELP_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.intranet_auth_req"));
        }
        //메인배너 등록요청
        else if(JiraResponseType.MAIN_BANNER_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.main_banner_req"));
        }
		//ERP 기본권한신청
		else if(JiraResponseType.ERP_BASIC_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.erp_basic_req"));
		}
        //ERP 특수권한신청
		else if(JiraResponseType.ERP_SPECIAL_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.erp_special_req"));
		}
        //ERP 개발요청 & 운영지원요청
		else if(JiraResponseType.ERP_DEV_REQ.getValue().equals(paramTicketInfoVO.getDivision())
				|| JiraResponseType.ERP_HELP_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.erp_dev_req"));
		}
        //단말신청
  		else if(JiraResponseType.DEVICE_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
      			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.device"));
      	}
        if(customMap != null && StringUtils.isNotEmpty((String)customMap.get("value")))
        	paramTicketInfoVO.setSection((String)customMap.get("value"));	//소분류(신청타입3)

        Map<String, Object> statusMap = (Map<String, Object>)fieldsMap.get("status");
        if(statusMap != null) paramTicketInfoVO.setStatus((String)statusMap.get("name"));	//티켓상태

        Map<String, Object> priorityMap = (Map<String, Object>)fieldsMap.get("priority");
        if(priorityMap != null) paramTicketInfoVO.setPriority((String)priorityMap.get("name"));	//티켓중요도

        /**
         * OA 신청용 필드 시작
         */
        //1. 대상장비
        //SKP11NM00003 (애플 MacBook Pro MD314KH/A(11)) 형식 값 잘라 넣기.
        String pcUserId = "";
        String pcAdminId = "";
        if(JiraResponseType.OA_CHANGE.getValue().equals(paramTicketInfoVO.getDivision())){
        	//OA장비교체신청일때 customfield_17603 / 보유자산(교체대상)
            String tagNo = (String)fieldsMap.get("customfield_17603");
            if(StringUtils.isNotEmpty(tagNo)){
            	if(tagNo.indexOf(" ") > -1){
            		paramTicketInfoVO.setChangeTagNo(tagNo.substring(0, tagNo.indexOf(" ")));
            		PcVO paramPc = new PcVO();
                    paramPc.setTagNo(paramTicketInfoVO.getChangeTagNo());
                    PcVO pcInfo = pcMapper.selectPcInfo(paramPc);
                    pcUserId = pcInfo.getUserId();
                    pcAdminId = pcInfo.getAdminId();
            	}else{
            		paramTicketInfoVO.setChangeTagNo(tagNo);
            	}
            }

        }else if(JiraResponseType.OA_RETURN.getValue().equals(paramTicketInfoVO.getDivision())){
            //OA장비반납신청 customfield_17207
            String tagNo = (String)fieldsMap.get("customfield_17207");
            if(StringUtils.isNotEmpty(tagNo)){
            	if(tagNo.indexOf(" ") > -1){
            		paramTicketInfoVO.setReturnTagNo(tagNo.substring(0, tagNo.indexOf(" ")));
            		PcVO paramPc = new PcVO();
                    paramPc.setTagNo(paramTicketInfoVO.getReturnTagNo());
                    PcVO pcInfo = pcMapper.selectPcInfo(paramPc);
                    pcUserId = pcInfo.getUserId();
                    pcAdminId = pcInfo.getAdminId();
            	}else{
            		paramTicketInfoVO.setReturnTagNo(tagNo);
            	}
            }
        }
        //지급장비 customfield_17604
        String tagNo = (String)fieldsMap.get("customfield_17604");
        if(StringUtils.isNotEmpty(tagNo)){
        	paramTicketInfoVO.setTagNo(tagNo);
        }

        //1.1 OA사용자
        Map<String, Object> pcUserIdMap = (Map<String, Object>)fieldsMap.get("customfield_17205");
        if(pcUserIdMap != null){
        	paramTicketInfoVO.setPcUserId((String)pcUserIdMap.get("name"));
        }else{
        	paramTicketInfoVO.setPcUserId(pcUserId);
        }
        //1.2 OA관리자
        Map<String, Object> pcAdminIdMap = (Map<String, Object>)fieldsMap.get("customfield_17313");
        if(pcAdminIdMap != null){
        	paramTicketInfoVO.setPcAdminId((String)pcAdminIdMap.get("name"));
        }else{
        	paramTicketInfoVO.setPcAdminId(pcAdminId);
        }

        //2. 근무사옥
        Map<String, Object> useLocationMap = (Map<String, Object>)fieldsMap.get("customfield_17314");
        if(useLocationMap != null) paramTicketInfoVO.setUseLocation((String)useLocationMap.get("value"));
        //3. 근무층
        String useLocationFloor = (String)fieldsMap.get("customfield_17315");
        if(StringUtils.isNotEmpty(useLocationFloor)) paramTicketInfoVO.setUseLocationFloor(useLocationFloor);

        //4. 기기구분
        String machinType = (String)fieldsMap.get("customfield_17503");
        if(StringUtils.isNotEmpty(machinType)) paramTicketInfoVO.setMachinType(machinType);
        //5.반납예정일 (대여용 장비 대상) customfield_17602 2020-01-29T10:16:00.000+0900 returnPlanDate
        String returnPlanDate = (String)fieldsMap.get("customfield_17602");
        if(StringUtils.isNotEmpty(returnPlanDate)) paramTicketInfoVO.setReturnPlanDate(returnPlanDate);


        /**
         * SW 신청용 필드
         */
        //1. SW용도
        Map<String, Object> usageTypeMap = (Map<String, Object>)fieldsMap.get("customfield_17309");
        if(usageTypeMap != null) paramTicketInfoVO.setUsageType((String)usageTypeMap.get("value"));
        //2. SW이름
        //MS Project Pro (SKPSW17102700025) 형식 값 잘라 넣기.
        String swManagementNo = (String)fieldsMap.get("customfield_17310");
        if(StringUtils.isNotEmpty(swManagementNo)) paramTicketInfoVO.setSwManagementNo(swManagementNo.substring(swManagementNo.lastIndexOf("(")+1, swManagementNo.lastIndexOf(")")));
        //3. 반납대상SW Asset key
        //SW-2 (IntelliJ IDEA 2017) 형식 값 잘라 넣기.
        String swlAssetKey = (String)fieldsMap.get("customfield_17311");
        if(StringUtils.isNotEmpty(swlAssetKey)) paramTicketInfoVO.setSwlAssetKey(swlAssetKey.substring(0, swlAssetKey.indexOf(" ")));

        if(ticketInfo == null){
        	jiraTicketMapper.insertTicketInfo(paramTicketInfoVO);
        }else{
        	jiraTicketMapper.updateTicketInfo(paramTicketInfoVO);
        }

		return paramTicketInfoVO;
	}


	@SuppressWarnings("unchecked")
	private void setCommentInfo(Integer ticketId, String corpGubun, Map<String, Object> commentMap) throws Exception{

		ArrayList<Map<String, Object>> commentList = (ArrayList<Map<String, Object>>)commentMap.get("comments");
		for (Map<String, Object> comment : commentList) {
			TicketCommentVO vo = new TicketCommentVO();
			vo.setTicketId(ticketId);
			vo.setCommentId(Integer.parseInt((String)comment.get("id")));
			vo.setCorpGubun(corpGubun);
			vo.setContents((String)comment.get("body"));
			vo.setCreateDate((String)comment.get("created"));
			vo.setUpdateDate((String)comment.get("updated"));

			Map<String, Object> authorMap = (Map<String, Object>)comment.get("author");
			vo.setCreatorKey((String)authorMap.get("name"));
			vo.setCreatorName((String)authorMap.get("displayName"));

			TicketCommentVO param = new TicketCommentVO();
			param.setCommentId(vo.getCommentId());
			param.setCorpGubun(corpGubun);
			TicketCommentVO commentInfo = jiraTicketMapper.selectTicketCommentInfo(param);
			if(commentInfo == null){
				jiraTicketMapper.insertTicketComment(vo);
			}else{
				jiraTicketMapper.updateTicketComment(vo);
			}
		}

	}

	@Override
	public void setCommentInfo(ReqBasicVO request) throws Exception{

		if(request.getIssue().getFields().getComment() == null) return;

		List<JiraCommentVO> commentList = request.getIssue().getFields().getComment().getComments();

		for (JiraCommentVO commentInfo : commentList) {
			TicketCommentVO vo = new TicketCommentVO();
			vo.setTicketId(Integer.parseInt(request.getIssue().getId()));
			vo.setCommentId(Integer.parseInt(commentInfo.getId()));
			vo.setCorpGubun(SystemConstant.CORP_GUBUN_11ST);
			vo.setContents(commentInfo.getBody());
			vo.setCreateDate(commentInfo.getCreated());
			vo.setUpdateDate(commentInfo.getUpdated());
			vo.setCreatorKey(commentInfo.getAuthor().getName());
			vo.setCreatorName(commentInfo.getAuthor().getDisplayName());

			TicketCommentVO param = new TicketCommentVO();
			param.setCommentId(vo.getCommentId());
			param.setCorpGubun(SystemConstant.CORP_GUBUN_11ST);
			TicketCommentVO dbInfo = jiraTicketMapper.selectTicketCommentInfo(param);
			if(dbInfo == null){
				jiraTicketMapper.insertTicketComment(vo);
			}else{
				jiraTicketMapper.updateTicketComment(vo);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void setAttachment(Integer ticketId, String corpGubun, ArrayList<Map<String, Object>> attachmentList) throws Exception{

		for (Map<String, Object> map : attachmentList) {
			String contentUrl = (String)map.get("content");
			String fileName = (String)map.get("filename");
			Integer attachId = Integer.parseInt((String)map.get("id"));
			//파일 다운로드
			String saveFilePath = downloadFileByUrl2(ticketId, corpGubun, contentUrl, fileName);

			if(StringUtils.isNotEmpty(saveFilePath)){
				logger.debug("DOWNLOAD FILE PATH :: {} / {}", saveFilePath , fileName);

				AttachmentVO vo = new AttachmentVO();
				vo.setTicketId(ticketId);
				vo.setAttachId(attachId);
				vo.setCorpGubun(corpGubun);
				vo.setFileDownloadUrl(contentUrl);
				vo.setFileName(fileName);
				vo.setSaveFilePath(saveFilePath);
				vo.setSaveFileName(fileName);
				vo.setMimeType((String)map.get("mimeType"));
				vo.setFileSize((Integer)map.get("size"));

				Map<String, Object> authorMap = (Map<String, Object>)map.get("author");
				vo.setCreatorKey((String)authorMap.get("name") );
				vo.setCreatorName((String)authorMap.get("displayName") );
				vo.setCreateDate((String)map.get("created"));

				AttachmentVO param = new AttachmentVO();
				param.setAttachId(attachId);
				param.setCorpGubun(corpGubun);
				AttachmentVO attachInfo = jiraTicketMapper.selectAttachmentInfo(param);
				if(attachInfo == null){
					jiraTicketMapper.insertAttachment(vo);
				}else{
					jiraTicketMapper.updateAttachment(vo);
				}
			}
		}
	}

	@Override
	public void setAttachment(ReqBasicVO request) throws Exception{

		if(request.getIssue().getFields().getAttachment() == null) return;

		List<JiraAttachmentVO> attachmentList = request.getIssue().getFields().getAttachment();
		Integer ticketId = Integer.parseInt(request.getIssue().getId());

		for (JiraAttachmentVO attach : attachmentList) {
			String contentUrl = attach.getContent();
			String fileName = attach.getFilename();
			Integer attachId = Integer.parseInt(attach.getId());
			//파일 다운로드
			String saveFilePath = downloadFileByUrl2(ticketId, SystemConstant.CORP_GUBUN_11ST, contentUrl, fileName);

			if(StringUtils.isNotEmpty(saveFilePath)){
				logger.debug("DOWNLOAD FILE PATH :: {} / {}", saveFilePath , fileName);

				AttachmentVO vo = new AttachmentVO();
				vo.setTicketId(ticketId);
				vo.setAttachId(attachId);
				vo.setCorpGubun(SystemConstant.CORP_GUBUN_11ST);
				vo.setFileDownloadUrl(contentUrl);
				vo.setFileName(fileName);
				vo.setSaveFilePath(saveFilePath);
				vo.setSaveFileName(fileName);
				vo.setMimeType(attach.getMimeType());
				vo.setFileSize(attach.getSize());
				vo.setCreateDate(attach.getCreated());
				vo.setCreatorKey(attach.getAuthor().getName());
				vo.setCreatorName(attach.getAuthor().getDisplayName());

				AttachmentVO param = new AttachmentVO();
				param.setAttachId(attachId);
				param.setCorpGubun(SystemConstant.CORP_GUBUN_11ST);
				AttachmentVO attachInfo = jiraTicketMapper.selectAttachmentInfo(param);
				if(attachInfo == null){
					jiraTicketMapper.insertAttachment(vo);
				}else{
					jiraTicketMapper.updateAttachment(vo);
				}
			}
		}
	}

	private String downloadFileByUrl2(Integer ticketId, String corpGubun, String fileUrl, String fileName) throws Exception{

		String defaultFilePath = StaticPropertyUtil.getProperty("jira.restapi.download.filepath");

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new BoResponseErrorHandler());

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

        ifLog.info("JIRA Download Attachment start. ticket id : {}", ticketId);
        ResponseEntity<byte[]> response = restTemplate.getForEntity(fileUrl, byte[].class);

        if(HttpStatus.OK.equals(response.getStatusCode())){
        	ifLog.debug("JIRA Download Attachment Success. ticket id : {}", ticketId);
        	Calendar cal = Calendar.getInstance();
            String yyyy = (new SimpleDateFormat("yyyy")).format(cal.getTime());
            String MMdd = (new SimpleDateFormat("MMdd")).format(cal.getTime());
            String saveFilePath = defaultFilePath + "/" + corpGubun + "/" + yyyy + "/" + MMdd + "/" + ticketId + "/";

            File dir = new File(saveFilePath);
            if(!dir.exists())
            	dir.mkdirs();

            File downloadedFile = new File(saveFilePath, fileName);
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(downloadedFile));
            try {
				bos.write(response.getBody());
				bos.flush();
				bos.close();
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("File flush error. TICKET_ID : {} \tFilename : {}", ticketId, fileName);
			} finally {
				bos.flush();
				bos.close();
			}

            return saveFilePath;

        }else{
        	ifLog.error("JIRA Download Attachment FAIL. HttpStatus : {}", response.getStatusCodeValue());
        	ifLog.error("JIRA Download Attachment FAIL. TICKET_ID : {} \n URL : {}", ticketId, fileUrl);
        }

        return null;
	}

	@Override
	public boolean sendTicketStatusCompleted(String ticketKey) throws Exception{

		boolean result = false;

		String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.completed.url");
		reqTicketInfoUrl = MessageFormat.format(reqTicketInfoUrl, ticketKey);
		JiraTransitionVO transition = new JiraTransitionVO();
		transition.setId(StaticPropertyUtil.getProperty("jira.restapi.completed.code"));

		RestTemplate restTemplate = new RestTemplate();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(converter);
        restTemplate.setErrorHandler(new BoResponseErrorHandler());

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
        HashMap<String,Object> map = new HashMap<String,Object>();
        map.put("transition", transition);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

        ResponseEntity<String> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, String.class);
        logger.debug(responseEntity.getBody());
		if(StringUtils.isEmpty(responseEntity.getBody())){
			result = true;
		}

		return result;

	}

	@Override
	public boolean sendTicketStatusCompleted(String ticketKey, String transitionCode) throws Exception{

		boolean result = false;

		String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.completed.url");
		if(ticketKey.startsWith("NXMILE"))
			reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.completed.url.skp");

		reqTicketInfoUrl = MessageFormat.format(reqTicketInfoUrl, ticketKey);
		JiraTransitionVO transition = new JiraTransitionVO();
		transition.setId(transitionCode);

		RestTemplate restTemplate = new RestTemplate();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(converter);
        restTemplate.setErrorHandler(new BoResponseErrorHandler());

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
        HashMap<String,Object> map = new HashMap<String,Object>();
        map.put("transition", transition);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

        ResponseEntity<String> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, String.class);
        logger.debug(responseEntity.getBody());
		if(StringUtils.isEmpty(responseEntity.getBody())){
			result = true;
		}

		return result;

	}

	@Override
	public boolean sendTicketStatus(String ticketKey, String transitionId) throws Exception{

		boolean result = false;

		String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.completed.url");
		reqTicketInfoUrl = MessageFormat.format(reqTicketInfoUrl, ticketKey);
		JiraTransitionVO transition = new JiraTransitionVO();
		transition.setId(transitionId);

		RestTemplate restTemplate = new RestTemplate();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(converter);
        restTemplate.setErrorHandler(new BoResponseErrorHandler());

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
        HashMap<String,Object> map = new HashMap<String,Object>();
        map.put("transition", transition);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

        ResponseEntity<String> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, String.class);
        logger.debug(responseEntity.getBody());
		if(responseEntity.getStatusCode().is2xxSuccessful()){
			result = true;
		}

		return result;

	}

	@Override
	public void sendTicketComment(String ticketId, String comment) throws Exception{


		String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.comment.url");
		if(ticketId.startsWith("NXMILE"))
			reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.comment.url.skp");

		reqTicketInfoUrl = MessageFormat.format(reqTicketInfoUrl, ticketId);

		RestTemplate restTemplate = new RestTemplate();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(converter);
        restTemplate.setErrorHandler(new BoResponseErrorHandler());

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
        HashMap<String,String> map = new HashMap<String,String>();
        map.put("body", comment);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

        ResponseEntity<String> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, String.class);

        logger.debug(responseEntity.getBody());

	}

	/**
	 * BOAPI >>> JIRA Asset 상태 변경  (SW, 다건)
	 */
	@Override
	public boolean chgJiraSwAssetStatus(List<SwApiVO> statusVO) throws Exception{

		boolean result = false;

		for (SwApiVO object : statusVO) {
			SwVO sw = new SwVO();
			sw.setSeq(object.getSeq());
			sw = swMapper.selectSwInfo(sw);

			if(StringUtils.isNotEmpty(sw.getTicketKey())){
				result = sendTicketStatus(sw.getTicketKey(), object.getStatusType().getValue());
			}else{
				result = false;
			}
		}
		return result;
	}

	@Override
	/**
	 * BOAPI >>> JIRA PC Asset 등록 (다건)
	 */
	public boolean createJiraPcAsset(List<String> tagNoList) throws Exception{

		boolean result = false;

		for (String tagNo : tagNoList) {
			result = createJiraPcAsset(tagNo);
		}

		return result;
	}

	@Autowired
	RestTemplate restTemplate;

	/**
	 * BOAPI >>> JIRA PC Asset 등록
	 */
	@Override
	public boolean createJiraPcAsset(String tagNo) throws Exception{

		boolean result = false;

		PcVO pc = new PcVO();
		pc.setTagNo(tagNo);
		List<PcVO> pcList = new ArrayList<PcVO>();
		pcList = pcMapper.selectPcList(pc);

		for (PcVO pcVO : pcList) {

			JiraCommonVO project = new JiraCommonVO();
			project.setKey(PcAssetType.PROJECT_KEY.getValue());
			JiraCommonVO issue = new JiraCommonVO();
			issue.setName(PcAssetType.ISSUE_TYPE.getValue());
			JiraCommonVO assignee = new JiraCommonVO();
			assignee.setName(pcVO.getAdminId());

			PcAssetBasicVO asset = new PcAssetBasicVO();
			asset.setProject(project);
			asset.setSummary(pcVO.getModelCode());
			asset.setDescription(pcVO.getNote());
			asset.setIssuetype(issue);
			asset.setDuedate(pcVO.getReturnPlanDate());
			asset.setAssignee(assignee);

			//OA관리자셋팅
			JiraCommonVO adminOA = new JiraCommonVO();
			adminOA.setName(pcVO.getAdminId());
			asset.setCustomfield_17313(adminOA);

			//OA사용자
			JiraCommonVO userOA = new JiraCommonVO();
			userOA.setName(pcVO.getUserId());
			asset.setCustomfield_17205(userOA);

			//OA자산코드
			asset.setCustomfield_17200(pcVO.getTagNo());

			//OA모델명
			asset.setCustomfield_17201(pcVO.getModelCode());

			//OA기기용도
			Code pcUseCodeInfo = codeService.getCodeById("machin_use", pcVO.getUseCode());
			JiraCommonVO assetUseCode = new JiraCommonVO();
			assetUseCode.setValue(pcUseCodeInfo.getCodeName()); //16600[일반용], 16601[대여용], 16603[개인용], 16604[교육용], 16605[해외용], 16606[임원용], 16607[SOC용]
			asset.setCustomfield_17202(assetUseCode);

			//OA기기구분
			pcUseCodeInfo = codeService.getCodeById("machin_type", pcVO.getMachinType());
			JiraCommonVO assetMachinType = new JiraCommonVO();
			assetMachinType.setValue(pcUseCodeInfo.getCodeName());
			asset.setCustomfield_17312(assetMachinType);


			String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url");

			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
			interceptors.add(new LoggingRequestInterceptor());
			interceptors.add(new BasicAuthorizationInterceptor(
					StaticPropertyUtil.getProperty("jira.restapi.id"),
					StaticPropertyUtil.getProperty("jira.restapi.pw")));
			restTemplate.setInterceptors(interceptors);
	        restTemplate.setErrorHandler(new BoResponseErrorHandler());

	        HttpHeaders reqHeaders = new HttpHeaders();
	        reqHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON_UTF8));
	        reqHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
	        HashMap<String,Object> map = new HashMap<String,Object>();
	        map.put("fields", asset);
	        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);


	        ResponseEntity<ResPcAssetVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, ResPcAssetVO.class);

	        PcVO paramPc = new PcVO();
	        paramPc.setTagNo(tagNo);
	        paramPc.setJiraResultMsg("insert");
	        if(responseEntity.getStatusCode().is2xxSuccessful()){
				if(StringUtils.isNotEmpty(responseEntity.getBody().getId())){
					paramPc.setTicketId(responseEntity.getBody().getId());
					paramPc.setTicketKey(responseEntity.getBody().getKey());
				}
				paramPc.setJiraResult("true");
				result = true;
	        }else{
	        	paramPc.setJiraResult("false");
	        	paramPc.setJiraResultMsg(responseEntity.getHeaders().get("error_body_string").get(0));
				result = false;
	        }
	        ifLog.info("INSERT PC ASSET TAG_NO : {} ", tagNo);
	        pcMapper.updatePcAsset(paramPc);

	        /*
	         * PC Asset 티켓 상태를 지급대기로 변경한다.
	         */
	        if(result){
	        	if(StringUtils.isNotEmpty(pcVO.getUseStatus())){
	        		pcUseCodeInfo = codeService.getCodeById("machin_use_status", pcVO.getUseStatus());
	        		assetService.chgJiraOaAssetStatus(tagNo, pcVO.getUseStatus());
	        	}

	        }

		}// for (PcVO pcVO : pcList) { END

		return result;

	}

	/**
	 * BOAPI >>> JIRA PC Asset 업데이트
	 * @param List<String> tagNoList
	 * @throws Exception
	 */
	@Override
	public Boolean updateJiraPcAsset(List<String> tagNoList) throws Exception{

		boolean result = false;
		if(tagNoList == null) return result;

		for (String tagNo : tagNoList) {
			result = updateJiraPcAsset(tagNo);
		}

		return result;
	}

	/**
	 * BOAPI >>> JIRA PC Asset 업데이트
	 * @param String tagNo
	 * @throws Exception
	 */
	@Override
	public Boolean updateJiraPcAsset(String tagNo) throws Exception{

		boolean result = false;

		if(StringUtils.isEmpty(tagNo)) return result;

		PcVO paramPc = new PcVO();
		paramPc.setTagNo(tagNo);

		PcVO pcVO = pcMapper.selectPcInfo(paramPc);

		if(StringUtils.isNotEmpty(pcVO.getTicketId())){
			JiraCommonVO project = new JiraCommonVO();
			project.setKey(PcAssetType.PROJECT_KEY.getValue());
			JiraCommonVO issue = new JiraCommonVO();
			issue.setName(PcAssetType.ISSUE_TYPE.getValue());
			JiraCommonVO assignee = new JiraCommonVO();
			assignee.setName(pcVO.getAdminId());

			PcAssetBasicVO asset = new PcAssetBasicVO();
			asset.setProject(project);
			asset.setSummary(pcVO.getModelCode());
			asset.setDescription(pcVO.getNote());
			asset.setIssuetype(issue);
			asset.setDuedate(pcVO.getReturnPlanDate());
			asset.setAssignee(assignee);

			//OA관리자셋팅
			JiraCommonVO adminOA = new JiraCommonVO();
			adminOA.setName(pcVO.getAdminId());
			asset.setCustomfield_17313(adminOA);

			//OA사용자
			JiraCommonVO userOA = new JiraCommonVO();
			userOA.setName(pcVO.getUserId());
			asset.setCustomfield_17205(userOA);

			//OA자산코드
			asset.setCustomfield_17200(pcVO.getTagNo());

			//OA모델명
			asset.setCustomfield_17201(pcVO.getModelCode());

			//OA기기용도
			Code pcUseCodeInfo = codeService.getCodeById("machin_use", pcVO.getUseCode());
			JiraCommonVO assetUseCode = new JiraCommonVO();
			assetUseCode.setValue(pcUseCodeInfo.getCodeName()); //16600[일반용], 16601[대여용], 16603[개인용], 16604[교육용], 16605[해외용], 16606[임원용], 16607[SOC용]
			asset.setCustomfield_17202(assetUseCode);

			//OA기기구분
			pcUseCodeInfo = codeService.getCodeById("machin_type", pcVO.getMachinType());
			JiraCommonVO assetMachinType = new JiraCommonVO();
			assetMachinType.setValue(pcUseCodeInfo.getCodeName());
			asset.setCustomfield_17312(assetMachinType);



			List<ClientHttpRequestInterceptor> interceptors = new ArrayList<ClientHttpRequestInterceptor>();
			interceptors.add(new LoggingRequestInterceptor());
			interceptors.add(new BasicAuthorizationInterceptor(
					StaticPropertyUtil.getProperty("jira.restapi.id"),
					StaticPropertyUtil.getProperty("jira.restapi.pw")));
			restTemplate.setInterceptors(interceptors);
	        restTemplate.setErrorHandler(new BoResponseErrorHandler());

	        HttpHeaders reqHeaders = new HttpHeaders();
	        reqHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON_UTF8));
	        reqHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);

	        HashMap<String,Object> map = new HashMap<String,Object>();
	        map.put("fields", asset);
	        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

	        String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url") + pcVO.getTicketKey();

	        ResponseEntity<ResPcAssetVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.PUT, requestEntity, ResPcAssetVO.class);
	        paramPc = new PcVO();
	        paramPc.setTagNo(tagNo);
	        paramPc.setJiraResultMsg("update");
	        if(responseEntity.getStatusCode().is2xxSuccessful()){
				paramPc.setJiraResult("true");
				result = true;

				/**
				 * OA Asset 상태 변경
				 */
				if(StringUtils.isNotEmpty(pcVO.getUseStatus())){
	        		pcUseCodeInfo = codeService.getCodeById("machin_use_status", pcVO.getUseStatus());
	        		assetService.chgJiraOaAssetStatus(tagNo, pcVO.getUseStatus());
	        	}

	        }else{
	        	paramPc.setJiraResult("false");
	        	paramPc.setJiraResultMsg(responseEntity.getHeaders().get("error_body_string").get(0));
				result = false;
	        }

	        ifLog.info("UPDATE PC ASSET TAG_NO : {} ", tagNo);
			pcMapper.updatePcAsset(paramPc);

			return result;
		}else{
			return createJiraPcAsset(tagNo);
		}
	}

	@Override
	/**
	 * JIRA >>> BOAPI PC Asset 업데이트
	 */
	public void updatePcAsset(ReqBasicVO assetInfo) throws Exception{

		if(assetInfo == null) return;

		/**
		 * 1. pc 정보 업데이트
		 */
		String assetStatus = assetInfo.getIssue().getFields().getStatus().getName();
		String tagNo = assetInfo.getIssue().getFields().getCustomfield_17200();
		PcVO pc = new PcVO();
		pc.setTagNo(tagNo);
		pc.setTicketId(assetInfo.getIssue().getId());
		pc.setTicketKey(assetInfo.getIssue().getKey());
		pc.setModelCode(assetInfo.getIssue().getFields().getCustomfield_17201());
		pc.setUserId(assetInfo.getIssue().getFields().getCustomfield_17205().getName());
		ILMpersonInfoVO ilmVO = hiOmsMapper.selectILMpersonInfo(pc.getUserId());
		if(ilmVO != null){
			pc.setUserName(ilmVO.getHname());
		}else{
			pc.setUserName(assetInfo.getIssue().getFields().getCustomfield_17205().getDisplayName());
		}
		pc.setAdminId(assetInfo.getIssue().getFields().getCustomfield_17313().getName());
		ilmVO = hiOmsMapper.selectILMpersonInfo(pc.getAdminId());
		if(ilmVO != null){
			pc.setAdminName(ilmVO.getHname());
		}else{
			pc.setAdminName(assetInfo.getIssue().getFields().getCustomfield_17313().getDisplayName());
		}
		pc.setNote(assetInfo.getIssue().getFields().getDescription());
		pc.setReturnPlanDate(assetInfo.getIssue().getFields().getDuedate());
		Code codeInfo = codeService.getCodeByName("machin_use", assetInfo.getIssue().getFields().getCustomfield_17202().getValue());
		pc.setUseCode(codeInfo.getCodeId());
		codeInfo = codeService.getCodeByName("machin_type", assetInfo.getIssue().getFields().getCustomfield_17312().getValue());
		pc.setMachinType(codeInfo.getCodeId());
		codeInfo = codeService.getCodeByName("machin_use_status", assetStatus);
		pc.setUseStatus(codeInfo.getCodeId());

		pcMapper.updatePcAsset(pc);

		/*
		 * bo_adm에서 처리하고 있어 중복로직으로 인해 주석처리.
		 */
		//Pc asset 상태가 사용중 or 유휴 일경우 해당 SR 티켓을 종료 처리 한다. 단 SR티켓 상태가 작업중 상태인 것만 처리한다.
//		if(PcAssetStatusType.사용중.name().equals(assetStatus)
//				|| PcAssetStatusType.유휴.name().equals(assetStatus)){
//			TicketInfoVO ticket = new TicketInfoVO();
//			ticket.setTagNo(tagNo);
//			ticket.setStatus(JiraResponseType.TICKET_STATUS_ING.getValue());
//			ticket = jiraTicketMapper.selectTicketInfoByTagNo(ticket);
//
//			//해당하는 SR티켓이 존재하면 종료처리 한다.
//			if(ticket != null){
//				sendTicketStatusCompleted(ticket.getTicketKey());
//			}
//		}

		/**
		 * 2. 코멘트 정보 업데이트
		 */
		setCommentInfo(assetInfo);

		/**
		 * 3.첨부파일 정보 업데이트
		 */
		setAttachment(assetInfo);

	}

	@Override
	/**
	 * BOAPI >>> JIRA Sw Asset 등록
	 */
	public boolean createJiraSwAsset(List<String> seqList) throws Exception{

		for (String seq : seqList) {
			createJiraSwAsset(seq);
		}

		return true;

	}

	@Override
	/**
	 * BOAPI >>> JIRA Sw Asset 등록
	 */
	public boolean createJiraSwAsset(String seq) throws Exception{

		if(seq == null){
			return false;
		}

		boolean result = false;

		SwVO sw = new SwVO();
		sw.setSeq(seq);
		sw = swMapper.selectSwInfo(sw);

		if(sw != null)
		{

			SwBaseVO swBase = new SwBaseVO();
			swBase.setSeq(sw.getSoftwareBaseSeq());
			swBase = swMapper.selectSwBaseInfo(swBase);

			JiraCommonVO project = new JiraCommonVO();
			project.setKey(SwAssetType.PROJECT_KEY.getValue());
			JiraCommonVO issue = new JiraCommonVO();
			issue.setName(SwAssetType.ISSUE_TYPE.getValue());
			JiraCommonVO assignee = new JiraCommonVO();
			assignee.setName(sw.getUserId());

			PcAssetBasicVO asset = new PcAssetBasicVO();
			asset.setProject(project);
			asset.setSummary(swBase.getSoftwareName());
			asset.setDescription(sw.getNote());
			asset.setIssuetype(issue);
//			asset.setDuedate(pcVO.getReturnPlanDate());
			asset.setAssignee(assignee);

			//OA사용자
			JiraCommonVO userOA = new JiraCommonVO();
			userOA.setName(sw.getUserId());
			asset.setCustomfield_17205(userOA);

			//OA자산코드
//			asset.setCustomfield_17200(sw.getTicketKey());

			String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url");

	        restTemplate.setErrorHandler(new BoResponseErrorHandler());

	        HttpHeaders reqHeaders = new HttpHeaders();
	        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
	        HashMap<String,Object> map = new HashMap<String,Object>();
	        map.put("fields", asset);
	        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

	        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
	        		StaticPropertyUtil.getProperty("jira.restapi.id"),
	        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

	        ResponseEntity<ResPcAssetVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.POST, requestEntity, ResPcAssetVO.class);
	        SwVO paramSw = new SwVO();
	        paramSw.setSeq(seq);
	        paramSw.setJiraResultMsg("insert");

	        if(responseEntity.getStatusCode().is2xxSuccessful()){
				if(StringUtils.isNotEmpty(responseEntity.getBody().getId())){
					paramSw.setTicketId(responseEntity.getBody().getId());
					paramSw.setTicketKey(responseEntity.getBody().getKey());
				}
				paramSw.setJiraResult("true");
				result = true;
	        }else{
	        	paramSw.setJiraResult("false");
	        	paramSw.setJiraResultMsg(responseEntity.getHeaders().get("error_body_string").get(0));
				result = false;
	        }

	        ifLog.info("INSERT SOFTWARE ASSET SEQ : {} ", seq);
	        swMapper.updateSwAsset(paramSw);

	        /*
	         * SW Asset 티켓 상태를 사용대기로 변경한다.
	         */
	        if(result){
	        	if(StringUtils.isEmpty(sw.getUseStatus())){
					assetService.chgJiraSwAssetStatus(seq, SwAssetStatusType.사용대기);
	        	}else{
	        		Code code = codeService.getCodeById("sw_use_status", sw.getUseStatus());
					assetService.chgJiraSwAssetStatus(seq, SwAssetStatusType.fromString(code.getCodeName()));
	        	}

	        }

		}// END if(sw ==null) else

		return result;

	}

	@Override
	/**
	 * BOAPI >>> JIRA Sw Asset 업데이트
	 */
	public boolean updateJiraSwAsset(List<String> seqList) throws Exception{

		for (String seq : seqList) {
			updateJiraSwAsset(seq);
		}
		return true;
	}

	@Override
	/**
	 * BOAPI >>> JIRA Sw Asset 업데이트
	 */
	public boolean updateJiraSwAsset(String seq) throws Exception{

		if(seq == null){
			return false;
		}

		boolean result = false;

		SwVO sw = new SwVO();
		sw.setSeq(seq);
		sw = swMapper.selectSwInfo(sw);

		if(sw != null && StringUtils.isNotEmpty(sw.getTicketId())){
			SwBaseVO swBase = new SwBaseVO();
			swBase.setSeq(sw.getSoftwareBaseSeq());
			swBase = swMapper.selectSwBaseInfo(swBase);

			JiraCommonVO project = new JiraCommonVO();
			project.setKey(SwAssetType.PROJECT_KEY.getValue());
			JiraCommonVO issue = new JiraCommonVO();
			issue.setName(SwAssetType.ISSUE_TYPE.getValue());
			JiraCommonVO assignee = new JiraCommonVO();
			assignee.setName(sw.getUserId());

			PcAssetBasicVO asset = new PcAssetBasicVO();
			asset.setProject(project);
			asset.setSummary(swBase.getSoftwareName());
			asset.setDescription(sw.getNote());
			asset.setIssuetype(issue);
//			asset.setDuedate(pcVO.getReturnPlanDate());
			asset.setAssignee(assignee);

			//OA사용자
			JiraCommonVO userOA = new JiraCommonVO();
			userOA.setName(sw.getUserId());
			asset.setCustomfield_17205(userOA);

			//OA자산코드
			asset.setCustomfield_17200(sw.getTicketKey());

			//sw_use_status
//			Code codeInfo = codeService.getCodeById("sw_use_status", sw.getUseStatus());
//			JiraCommonVO status = new JiraCommonVO();
//			status.setValue(codeInfo.getCodeName());
//			asset.setStatus(status);

			String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url") + sw.getTicketKey();

	        restTemplate.setErrorHandler(new BoResponseErrorHandler());

	        HttpHeaders reqHeaders = new HttpHeaders();
	        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
	        HashMap<String,Object> map = new HashMap<String,Object>();
	        map.put("fields", asset);
	        HttpEntity<?> requestEntity = new HttpEntity<Object>(map, reqHeaders);

	        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
	        		StaticPropertyUtil.getProperty("jira.restapi.id"),
	        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

	        ResponseEntity<ResPcAssetVO> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.PUT, requestEntity, ResPcAssetVO.class);
	        SwVO paramSw = new SwVO();
	        paramSw.setSeq(seq);
	        paramSw.setJiraResultMsg("update");

	        if(responseEntity.getStatusCode().is2xxSuccessful()){
				paramSw.setJiraResult("true");
				result = true;

				/**
				 * SW asset 상태변경
				 */
				if(StringUtils.isNotEmpty(sw.getUseStatus())){
					Code code = codeService.getCodeById("sw_use_status", sw.getUseStatus());
					assetService.chgJiraSwAssetStatus(seq, SwAssetStatusType.fromString(code.getCodeName()));
				}
	        }else{
	        	paramSw.setJiraResult("false");
	        	paramSw.setJiraResultMsg(responseEntity.getHeaders().get("error_body_string").get(0));
				result = false;
	        }

	        ifLog.info("UPDATE SOFTWARE ASSET SEQ : {} ", seq);
	        swMapper.updateSwAsset(paramSw);
		}else{
			return createJiraSwAsset(seq);
		}

		return result;

	}

	@Override
	/**
	 * JIRA >>> BOAPI SW Asset 업데이트
	 */
	public void updateSwAsset(ReqBasicVO assetInfo) throws Exception{

		if(assetInfo == null) return;

		/**
		 * 1. SW 정보 업데이트
		 */
		SwVO sw = new SwVO();
		sw.setTicketKey(assetInfo.getIssue().getKey());
		sw = swMapper.selectSwInfo(sw);

		if(sw != null){
			SwVO paramSw = new SwVO();
			paramSw.setSeq(sw.getSeq());
			paramSw.setTicketKey(assetInfo.getIssue().getKey());
			paramSw.setNote(assetInfo.getIssue().getFields().getDescription());

			Code codeInfo = codeService.getCodeByName("sw_use_status", assetInfo.getIssue().getFields().getStatus().getName());
			paramSw.setUseStatus(codeInfo.getCodeId());

			paramSw.setUserId(assetInfo.getIssue().getFields().getAssignee().getName());
			ILMpersonInfoVO ilmVO = hiOmsMapper.selectILMpersonInfo(paramSw.getUserId());

			paramSw.setUserName(ilmVO.getHname());
			paramSw.setDepartmentName(ilmVO.getDeptnm());

			swMapper.updateSwAsset(paramSw);

			/**
			 * 2. 코멘트 정보 업데이트
			 */
			setCommentInfo(assetInfo);

			/**
			 * 3.첨부파일 정보 업데이트
			 */
			setAttachment(assetInfo);
		}

	}

	@SuppressWarnings("unused")
	private String downloadFileByUrl(Integer ticketId, String fileUrl, String fileName) throws Exception{

		String resultFullPathFileName = "";
		String defaultFilePath = StaticPropertyUtil.getProperty("jira.restapi.download.filepath");

        Calendar cal = Calendar.getInstance();
        String yyyy = (new SimpleDateFormat("yyyy")).format(cal.getTime());
        String MMdd = (new SimpleDateFormat("MMdd")).format(cal.getTime());
        String saveFilePath = defaultFilePath + "/"+yyyy+"/"+MMdd+"/"+ticketId + "/";

        File dir = new File(saveFilePath);
        if(!dir.exists())
        	dir.mkdirs();

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new BoResponseErrorHandler());

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

        RequestCallback requestCallback = request -> request.getHeaders()
        		.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM, MediaType.ALL));

        ResponseExtractor<Void> responseExtractor = response -> {
            Path path = Paths.get(saveFilePath);
            Files.copy(response.getBody(), path);
            return null;
        };

        restTemplate.execute(URI.create(fileUrl), HttpMethod.GET, requestCallback, responseExtractor);

		return resultFullPathFileName;
	}

	/**
	 * JIRA >>> BOAPI Sub TASK 업데이트
	 * 자산실사를 위한 처리
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@Transactional
	public void updatePcReal(String ticketId) throws Exception{

		String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url")+ticketId;

		RestTemplate restTemplate = new RestTemplate();
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(converter);
        restTemplate.setErrorHandler(new BoResponseErrorHandler());

        HttpHeaders reqHeaders = new HttpHeaders();
        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<?> requestEntity = new HttpEntity<Object>(reqHeaders);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
        		StaticPropertyUtil.getProperty("jira.restapi.id"),
        		StaticPropertyUtil.getProperty("jira.restapi.pw")));
        ifLog.info("JIRA requestJiraTicketInfo IF start. ticket id : {}", ticketId);
        ResponseEntity<Map> responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.GET, requestEntity, Map.class);

		Map<String, Object> totalMap = (Map<String, Object>) responseEntity.getBody();
        Map<String, Object> fieldsMap = (Map<String, Object>) totalMap.get("fields");
        Integer iTicketId = Integer.parseInt((String)totalMap.get("id"));

        /*
         * 0. 기등록된 티켓인지 확인.
         */
        TicketInfoVO ticketInfo = jiraTicketMapper.selectSubTicketInfo(ticketId);

        /*
         * 1. 티켓 기본 정보 등록
         */
        TicketInfoVO paramTicketInfoVO = setSubTicketInfo(iTicketId, ticketInfo, totalMap, fieldsMap);




        /*
         * 1.1 코멘트 정보 등록
         */
        Map<String, Object> commentMap = (Map<String, Object>)fieldsMap.get("comment");
        if(commentMap != null) setCommentInfo(iTicketId, SystemConstant.CORP_GUBUN_11ST, commentMap);
        /*
         * 1.2 첨부파일 정보 등록
         */
        ArrayList<Map<String, Object>> attachmentList = (ArrayList<Map<String, Object>>)fieldsMap.get("attachment");
        if(attachmentList != null) setAttachment(iTicketId, SystemConstant.CORP_GUBUN_11ST, attachmentList);

	}

	/**
	 * JIRA >>> BOAPI Sub TASK 업데이트
	 * 자산실사를 위한 처리
	 */
	@SuppressWarnings("unchecked")
	private TicketInfoVO setSubTicketInfo(
			Integer iTicketId, TicketInfoVO ticketInfo, Map<String, Object> totalMap, Map<String, Object> fieldsMap) throws Exception {
		TicketInfoVO paramTicketInfoVO = new TicketInfoVO();

        paramTicketInfoVO.setTicketId(iTicketId);	//티켓ID
        paramTicketInfoVO.setTicketKey((String)totalMap.get("key"));	//티켓
        String summary = (String)fieldsMap.get("summary");
        if(StringUtils.isNotEmpty(summary)) summary = Normalizer.normalize(summary, Normalizer.Form.NFC);	//JIRA에서 제목을 수정시에 자음모음 분리현상이 일어난다
        paramTicketInfoVO.setSummary(summary);	//제목
        paramTicketInfoVO.setDescription((String)fieldsMap.get("description"));	//내용상세
        paramTicketInfoVO.setCreateDate((String)fieldsMap.get("created"));	//생성일시
        paramTicketInfoVO.setUpdateDate((String)fieldsMap.get("updated"));	//수정일시
        String duedate = (String)fieldsMap.get("duedate");
        if(StringUtils.isEmpty(duedate)){
        	if(ticketInfo != null && StringUtils.isNotEmpty(ticketInfo.getDueDate())){
        		paramTicketInfoVO.setDueDate(ticketInfo.getDueDate());	//완료요청일

        	}else{
        		String now = DateUtil.currentTime("yyyyMMdd");
        		String after3day = DateUtil.addDay(now, 3); //return yyyy-MM-dd
        		paramTicketInfoVO.setDueDate(DateUtil.formatDate(after3day, "-"));	//완료요청일
        	}
        }else{
        	paramTicketInfoVO.setDueDate(duedate);	//완료요청일
        }

        if(fieldsMap.get("resolution") != null){
        	paramTicketInfoVO.setResolution((String)((Map<String,Object>)fieldsMap.get("resolution")).get("name"));	//해결상태
        	paramTicketInfoVO.setResolutionDate((String)fieldsMap.get("resolutiondate"));	//해결일시
        }

        Map<String, Object> reporterMap = (Map<String, Object>)fieldsMap.get("reporter");
        if(reporterMap !=null){
        	paramTicketInfoVO.setReporterKey((String)reporterMap.get("name"));			//생성자ID
            paramTicketInfoVO.setReporterName((String)reporterMap.get("displayName"));		//생성자명
        }

        Map<String, Object> assigneeMap = (Map<String, Object>)fieldsMap.get("assignee");
        if(assigneeMap != null){
        	paramTicketInfoVO.setAssigneeKey((String)assigneeMap.get("name"));			//처리자ID
            paramTicketInfoVO.setAssigneeName((String)assigneeMap.get("displayName"));	//처리자명
        }

        Map<String, Object> projectMap = (Map<String, Object>)fieldsMap.get("project");
        if(projectMap != null)
        	paramTicketInfoVO.setCategory((String)projectMap.get("name"));	//대분류

        Map<String, Object> issuetypeMap = (Map<String, Object>)fieldsMap.get("issuetype");
        if(issuetypeMap != null){
        	String division = (String)issuetypeMap.get("name");
        	if(StringUtils.isNotEmpty(division))
        		paramTicketInfoVO.setDivision(division.trim());	//중분류(Type)
        }


        Map<String, Object> customMap = new HashMap<String, Object>();
        //인트라넷 개발요청
        if(JiraResponseType.INTRANET_DEV_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.intranet_dev_req"));
        }
        //인트라넷 권한신청 & 운영지원요처
        else if(JiraResponseType.INTRANET_AUTH_REQ.getValue().equals(paramTicketInfoVO.getDivision())
        		|| JiraResponseType.INTRANET_HELP_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.intranet_auth_req"));
        }
        //메인배너 등록요청
        else if(JiraResponseType.MAIN_BANNER_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
        	customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.main_banner_req"));
        }
		//ERP 기본권한신청
		else if(JiraResponseType.ERP_BASIC_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.erp_basic_req"));
		}
        //ERP 특수권한신청
		else if(JiraResponseType.ERP_SPECIAL_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.erp_special_req"));
		}
        //ERP 개발요청 & 운영지원요청
		else if(JiraResponseType.ERP_DEV_REQ.getValue().equals(paramTicketInfoVO.getDivision())
				|| JiraResponseType.ERP_HELP_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.erp_dev_req"));
		}
        //단말신청
  		else if(JiraResponseType.DEVICE_REQ.getValue().equals(paramTicketInfoVO.getDivision())){
      			customMap = (Map<String, Object>)fieldsMap.get(StaticPropertyUtil.getProperty("jira.restapi.field.device"));
      	}
        if(customMap != null && StringUtils.isNotEmpty((String)customMap.get("value")))
        	paramTicketInfoVO.setSection((String)customMap.get("value"));	//소분류(신청타입3)

        Map<String, Object> statusMap = (Map<String, Object>)fieldsMap.get("status");
        if(statusMap != null) paramTicketInfoVO.setStatus((String)statusMap.get("name"));	//티켓상태

        Map<String, Object> priorityMap = (Map<String, Object>)fieldsMap.get("priority");
        if(priorityMap != null) paramTicketInfoVO.setPriority((String)priorityMap.get("name"));	//티켓중요도

//        Map<String, Object> tagNoMap = (Map<String, Object>)fieldsMap.get("customfield_17200");
//        if(tagNoMap != null) paramTicketInfoVO.setTagNo((String)tagNoMap.get("name"));	//TagNo
        paramTicketInfoVO.setTagNo((String)fieldsMap.get("customfield_17200"));	//TagNo



        if(ticketInfo == null){
        	jiraTicketMapper.insertSubTicketInfo(paramTicketInfoVO);
        }else{
        	jiraTicketMapper.updateSubTicketInfo(paramTicketInfoVO);
        }

		return paramTicketInfoVO;
	}


}
