package skp.bo.api.jira.vo.pc;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class ReqIssueVO {

	private String id;
	private String key;

	private PcAssetBasicVO fields;



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getKey() {
		return key;
	}



	public void setKey(String key) {
		this.key = key;
	}



	public PcAssetBasicVO getFields() {
		return fields;
	}



	public void setFields(PcAssetBasicVO fields) {
		this.fields = fields;
	}



	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
