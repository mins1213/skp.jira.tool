package skp.bo.api.jira.vo;

public class TicketInfoVO {

	private Integer ticketId;
	private String ticketKey;
	private String corpGubun;
	private String summary;
	private String description;
	private String category;
	private String division;
	private String section;
	private String status;
	private String priority;
	private String dueDate;
	private String resolution;
	private String resolutionDate;
	private String components;
	private String labels;
	private String reporterKey;
	private String reporterName;
	private String assigneeKey;
	private String assigneeName;
	private String approverKey;
	private String approverName;
	private String createDate;
	private String updateDate;
	private String requestNumber;
	private String requestSendYN;
	private String requestSendDay;
	private String requestUserID;
	private String requestOmsUserID;
	private String requestResultYN;
	private String tagNo;
	private String pcUserId;
	private String pcAdminId;
	private String useLocation;
	private String useLocationFloor;
	private String machinType;
	private String returnPlanDate;
	private String usageType;
	private String swManagementNo;
	private String swlAssetKey;

	private String returnTagNo;
	private String changeTagNo;


	public String getCorpGubun() {
		return corpGubun;
	}
	public void setCorpGubun(String corpGubun) {
		this.corpGubun = corpGubun;
	}
	public String getReturnTagNo() {
		return returnTagNo;
	}
	public void setReturnTagNo(String returnTagNo) {
		this.returnTagNo = returnTagNo;
	}
	public String getChangeTagNo() {
		return changeTagNo;
	}
	public void setChangeTagNo(String changeTagNo) {
		this.changeTagNo = changeTagNo;
	}
	public String getReturnPlanDate() {
		return returnPlanDate;
	}
	public void setReturnPlanDate(String returnPlanDate) {
		this.returnPlanDate = returnPlanDate;
	}
	public String getMachinType() {
		return machinType;
	}
	public void setMachinType(String machinType) {
		this.machinType = machinType;
	}
	public String getPcAdminId() {
		return pcAdminId;
	}
	public void setPcAdminId(String pcAdminId) {
		this.pcAdminId = pcAdminId;
	}
	public String getPcUserId() {
		return pcUserId;
	}
	public void setPcUserId(String pcUserId) {
		this.pcUserId = pcUserId;
	}
	public String getUseLocation() {
		return useLocation;
	}
	public void setUseLocation(String useLocation) {
		this.useLocation = useLocation;
	}
	public String getUseLocationFloor() {
		return useLocationFloor;
	}
	public void setUseLocationFloor(String useLocationFloor) {
		this.useLocationFloor = useLocationFloor;
	}
	public String getUsageType() {
		return usageType;
	}
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	public String getSwManagementNo() {
		return swManagementNo;
	}
	public void setSwManagementNo(String swManagementNo) {
		this.swManagementNo = swManagementNo;
	}
	public String getSwlAssetKey() {
		return swlAssetKey;
	}
	public void setSwlAssetKey(String swlAssetKey) {
		this.swlAssetKey = swlAssetKey;
	}
	public String getTagNo() {
		return tagNo;
	}
	public void setTagNo(String tagNo) {
		this.tagNo = tagNo;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getRequestNumber() {
		return requestNumber;
	}
	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}
	public String getRequestSendYN() {
		return requestSendYN;
	}
	public void setRequestSendYN(String requestSendYN) {
		this.requestSendYN = requestSendYN;
	}
	public String getRequestSendDay() {
		return requestSendDay;
	}
	public void setRequestSendDay(String requestSendDay) {
		this.requestSendDay = requestSendDay;
	}
	public String getRequestUserID() {
		return requestUserID;
	}
	public void setRequestUserID(String requestUserID) {
		this.requestUserID = requestUserID;
	}
	public String getRequestOmsUserID() {
		return requestOmsUserID;
	}
	public void setRequestOmsUserID(String requestOmsUserID) {
		this.requestOmsUserID = requestOmsUserID;
	}
	public String getRequestResultYN() {
		return requestResultYN;
	}
	public void setRequestResultYN(String requestResultYN) {
		this.requestResultYN = requestResultYN;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	public String getResolutionDate() {
		return resolutionDate;
	}
	public void setResolutionDate(String resolutionDate) {
		this.resolutionDate = resolutionDate;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getReporterKey() {
		return reporterKey;
	}
	public void setReporterKey(String reporterKey) {
		this.reporterKey = reporterKey;
	}
	public String getReporterName() {
		return reporterName;
	}
	public void setReporterName(String reporterName) {
		this.reporterName = reporterName;
	}
	public String getApproverKey() {
		return approverKey;
	}
	public void setApproverKey(String approverKey) {
		this.approverKey = approverKey;
	}
	public String getApproverName() {
		return approverName;
	}
	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}
	public Integer getTicketId() {
		return ticketId;
	}
	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}
	public String getTicketKey() {
		return ticketKey;
	}
	public void setTicketKey(String ticketKey) {
		this.ticketKey = ticketKey;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getComponents() {
		return components;
	}
	public void setComponents(String components) {
		this.components = components;
	}
	public String getLabels() {
		return labels;
	}
	public void setLabels(String labels) {
		this.labels = labels;
	}
	public String getAssigneeKey() {
		return assigneeKey;
	}
	public void setAssigneeKey(String assigneeKey) {
		this.assigneeKey = assigneeKey;
	}
	public String getAssigneeName() {
		return assigneeName;
	}
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}
