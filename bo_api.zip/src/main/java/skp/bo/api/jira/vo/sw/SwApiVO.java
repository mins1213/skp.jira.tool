package skp.bo.api.jira.vo.sw;

import skp.bo.api.jira.type.SwAssetStatusType;

public class SwApiVO {

	/*
	 * software.seq
	 */
	private String seq;
	/*
	 * SW Asset 상태값 정의
	 */
	private SwAssetStatusType statusType;

	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public SwAssetStatusType getStatusType() {
		return statusType;
	}
	public void setStatusType(SwAssetStatusType statusType) {
		this.statusType = statusType;
	}

}
