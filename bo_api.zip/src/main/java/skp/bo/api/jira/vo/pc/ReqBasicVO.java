package skp.bo.api.jira.vo.pc;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * PC asset JIRA Hooker URL로 인입하는 ReQ 대응
 * @author SONY
 *
 */
public class ReqBasicVO {

	private ReqIssueVO issue;



	public ReqIssueVO getIssue() {
		return issue;
	}



	public void setIssue(ReqIssueVO issue) {
		this.issue = issue;
	}



	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
