package skp.bo.api.jira.type;

public enum PcAssetType {

	PROJECT_KEY("ASSET"),
	ISSUE_TYPE("OA자산"),

	OK("OK");


	private String reqType;

	private PcAssetType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}
}
