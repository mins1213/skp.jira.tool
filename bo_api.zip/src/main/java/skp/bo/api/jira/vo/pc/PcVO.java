package skp.bo.api.jira.vo.pc;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class PcVO {

	private String seq;
	private String tagNo;
	private String ticketId;
	private String ticketKey;
	private String pridSeq;
	private String modelCode;
	private String useCode;
	private String machinMaker;
	private String machinIp;
	private String firstTag;
	private String serialNo;
	private String macAddress;
	private String wlessMacAddress;
	private String addMacAddress1;
	private String addMacAddress2;
	private String inDate;
	private String telskId;
	private String telskName;
	private String buyPrice;
	private String warranty;
	private String telskGroupId;
	private String telskGroupName;
	private String setupDate;
	private String userId;
	private String userName;
	private String userTelno;
	private String adminId;
	private String adminName;
	private String useLocationCode;
	private String useLocation;
	private String useLocationDt;
	private String returnPlanDate;
	private String changePlanDate;
	private String machinType;
	private String netprtTagNo;
	private String netprtSerialNo;
	private String useStatus;
	private String idleStatus;
	private String assetCode;
	private String assetType;
	private String budgetType;
	private String budgetYear;
	private String budgetMonth;
	private String settleYear;
	private String settleMonth;
	private String note;
	private String regiTime;
	private String updateDate;
	private String updateField;
	private String confirmOk;
	private String amicYn;
	private String budgetYn;
	private String leftCost;
	private String afeNo;
	private String lastInspect;
	private String inspectStatus;
	private String inspectStatusCode;
	private String osMigration;
	private String adslYn;
	private String puid;
	private String machinDns;
	private String machinGateway;
	private String useCodeDt;
	private String onsiteAgentId;
	private String ramInfo;
	private String cidCode;
	private String jiraResult;
	private String jiraResultMsg;

	public String getJiraResult() {
		return jiraResult;
	}
	public void setJiraResult(String jiraResult) {
		this.jiraResult = jiraResult;
	}
	public String getJiraResultMsg() {
		return jiraResultMsg;
	}
	public void setJiraResultMsg(String jiraResultMsg) {
		this.jiraResultMsg = jiraResultMsg;
	}
	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	public String getTicketKey() {
		return ticketKey;
	}
	public void setTicketKey(String ticketKey) {
		this.ticketKey = ticketKey;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTagNo() {
		return tagNo;
	}
	public void setTagNo(String tagNo) {
		this.tagNo = tagNo;
	}
	public String getPridSeq() {
		return pridSeq;
	}
	public void setPridSeq(String pridSeq) {
		this.pridSeq = pridSeq;
	}
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getUseCode() {
		return useCode;
	}
	public void setUseCode(String useCode) {
		this.useCode = useCode;
	}
	public String getMachinMaker() {
		return machinMaker;
	}
	public void setMachinMaker(String machinMaker) {
		this.machinMaker = machinMaker;
	}
	public String getMachinIp() {
		return machinIp;
	}
	public void setMachinIp(String machinIp) {
		this.machinIp = machinIp;
	}
	public String getFirstTag() {
		return firstTag;
	}
	public void setFirstTag(String firstTag) {
		this.firstTag = firstTag;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getWlessMacAddress() {
		return wlessMacAddress;
	}
	public void setWlessMacAddress(String wlessMacAddress) {
		this.wlessMacAddress = wlessMacAddress;
	}
	public String getAddMacAddress1() {
		return addMacAddress1;
	}
	public void setAddMacAddress1(String addMacAddress1) {
		this.addMacAddress1 = addMacAddress1;
	}
	public String getAddMacAddress2() {
		return addMacAddress2;
	}
	public void setAddMacAddress2(String addMacAddress2) {
		this.addMacAddress2 = addMacAddress2;
	}
	public String getInDate() {
		return inDate;
	}
	public void setInDate(String inDate) {
		this.inDate = inDate;
	}
	public String getTelskId() {
		return telskId;
	}
	public void setTelskId(String telskId) {
		this.telskId = telskId;
	}
	public String getTelskName() {
		return telskName;
	}
	public void setTelskName(String telskName) {
		this.telskName = telskName;
	}
	public String getBuyPrice() {
		return buyPrice;
	}
	public void setBuyPrice(String buyPrice) {
		this.buyPrice = buyPrice;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getTelskGroupId() {
		return telskGroupId;
	}
	public void setTelskGroupId(String telskGroupId) {
		this.telskGroupId = telskGroupId;
	}
	public String getTelskGroupName() {
		return telskGroupName;
	}
	public void setTelskGroupName(String telskGroupName) {
		this.telskGroupName = telskGroupName;
	}
	public String getSetupDate() {
		return setupDate;
	}
	public void setSetupDate(String setupDate) {
		this.setupDate = setupDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserTelno() {
		return userTelno;
	}
	public void setUserTelno(String userTelno) {
		this.userTelno = userTelno;
	}
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getUseLocationCode() {
		return useLocationCode;
	}
	public void setUseLocationCode(String useLocationCode) {
		this.useLocationCode = useLocationCode;
	}
	public String getUseLocation() {
		return useLocation;
	}
	public void setUseLocation(String useLocation) {
		this.useLocation = useLocation;
	}
	public String getUseLocationDt() {
		return useLocationDt;
	}
	public void setUseLocationDt(String useLocationDt) {
		this.useLocationDt = useLocationDt;
	}
	public String getReturnPlanDate() {
		return returnPlanDate;
	}
	public void setReturnPlanDate(String returnPlanDate) {
		this.returnPlanDate = returnPlanDate;
	}
	public String getChangePlanDate() {
		return changePlanDate;
	}
	public void setChangePlanDate(String changePlanDate) {
		this.changePlanDate = changePlanDate;
	}
	public String getMachinType() {
		return machinType;
	}
	public void setMachinType(String machinType) {
		this.machinType = machinType;
	}
	public String getNetprtTagNo() {
		return netprtTagNo;
	}
	public void setNetprtTagNo(String netprtTagNo) {
		this.netprtTagNo = netprtTagNo;
	}
	public String getNetprtSerialNo() {
		return netprtSerialNo;
	}
	public void setNetprtSerialNo(String netprtSerialNo) {
		this.netprtSerialNo = netprtSerialNo;
	}
	public String getUseStatus() {
		return useStatus;
	}
	public void setUseStatus(String useStatus) {
		this.useStatus = useStatus;
	}
	public String getIdleStatus() {
		return idleStatus;
	}
	public void setIdleStatus(String idleStatus) {
		this.idleStatus = idleStatus;
	}
	public String getAssetCode() {
		return assetCode;
	}
	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getBudgetType() {
		return budgetType;
	}
	public void setBudgetType(String budgetType) {
		this.budgetType = budgetType;
	}
	public String getBudgetYear() {
		return budgetYear;
	}
	public void setBudgetYear(String budgetYear) {
		this.budgetYear = budgetYear;
	}
	public String getBudgetMonth() {
		return budgetMonth;
	}
	public void setBudgetMonth(String budgetMonth) {
		this.budgetMonth = budgetMonth;
	}
	public String getSettleYear() {
		return settleYear;
	}
	public void setSettleYear(String settleYear) {
		this.settleYear = settleYear;
	}
	public String getSettleMonth() {
		return settleMonth;
	}
	public void setSettleMonth(String settleMonth) {
		this.settleMonth = settleMonth;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getRegiTime() {
		return regiTime;
	}
	public void setRegiTime(String regiTime) {
		this.regiTime = regiTime;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateField() {
		return updateField;
	}
	public void setUpdateField(String updateField) {
		this.updateField = updateField;
	}
	public String getConfirmOk() {
		return confirmOk;
	}
	public void setConfirmOk(String confirmOk) {
		this.confirmOk = confirmOk;
	}
	public String getAmicYn() {
		return amicYn;
	}
	public void setAmicYn(String amicYn) {
		this.amicYn = amicYn;
	}
	public String getBudgetYn() {
		return budgetYn;
	}
	public void setBudgetYn(String budgetYn) {
		this.budgetYn = budgetYn;
	}
	public String getLeftCost() {
		return leftCost;
	}
	public void setLeftCost(String leftCost) {
		this.leftCost = leftCost;
	}
	public String getAfeNo() {
		return afeNo;
	}
	public void setAfeNo(String afeNo) {
		this.afeNo = afeNo;
	}
	public String getLastInspect() {
		return lastInspect;
	}
	public void setLastInspect(String lastInspect) {
		this.lastInspect = lastInspect;
	}
	public String getInspectStatus() {
		return inspectStatus;
	}
	public void setInspectStatus(String inspectStatus) {
		this.inspectStatus = inspectStatus;
	}
	public String getInspectStatusCode() {
		return inspectStatusCode;
	}
	public void setInspectStatusCode(String inspectStatusCode) {
		this.inspectStatusCode = inspectStatusCode;
	}
	public String getOsMigration() {
		return osMigration;
	}
	public void setOsMigration(String osMigration) {
		this.osMigration = osMigration;
	}
	public String getAdslYn() {
		return adslYn;
	}
	public void setAdslYn(String adslYn) {
		this.adslYn = adslYn;
	}
	public String getPuid() {
		return puid;
	}
	public void setPuid(String puid) {
		this.puid = puid;
	}
	public String getMachinDns() {
		return machinDns;
	}
	public void setMachinDns(String machinDns) {
		this.machinDns = machinDns;
	}
	public String getMachinGateway() {
		return machinGateway;
	}
	public void setMachinGateway(String machinGateway) {
		this.machinGateway = machinGateway;
	}
	public String getUseCodeDt() {
		return useCodeDt;
	}
	public void setUseCodeDt(String useCodeDt) {
		this.useCodeDt = useCodeDt;
	}
	public String getOnsiteAgentId() {
		return onsiteAgentId;
	}
	public void setOnsiteAgentId(String onsiteAgentId) {
		this.onsiteAgentId = onsiteAgentId;
	}
	public String getRamInfo() {
		return ramInfo;
	}
	public void setRamInfo(String ramInfo) {
		this.ramInfo = ramInfo;
	}
	public String getCidCode() {
		return cidCode;
	}
	public void setCidCode(String cidCode) {
		this.cidCode = cidCode;
	}

	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
