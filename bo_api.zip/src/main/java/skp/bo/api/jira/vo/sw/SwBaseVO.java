package skp.bo.api.jira.vo.sw;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class SwBaseVO {

	private String seq;
	private String swManagementNo;
	private String standardType;
	private String contractType;
	private String usageType;
	private String usageDetail;
	private String softwareName;
	private String tcoSoftwareName;
	private String softwareDeveloper;
	private String contractCount;
	private String managementCount;
	private String evidenceYn;
	private String evidenceType;
	private String softwarePublisher;
	private String certificationKey;
	private String certificationType;
	private String certificationGroup;
	private String installStep;
	private String installType;
	private String installUrl;
	private String note;
	private String regDate;
	private String modDate;
	private String regUserId;
	private String modUserId;
	private String license;


	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getSwManagementNo() {
		return swManagementNo;
	}
	public void setSwManagementNo(String swManagementNo) {
		this.swManagementNo = swManagementNo;
	}
	public String getStandardType() {
		return standardType;
	}
	public void setStandardType(String standardType) {
		this.standardType = standardType;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getUsageType() {
		return usageType;
	}
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	public String getUsageDetail() {
		return usageDetail;
	}
	public void setUsageDetail(String usageDetail) {
		this.usageDetail = usageDetail;
	}
	public String getSoftwareName() {
		return softwareName;
	}
	public void setSoftwareName(String softwareName) {
		this.softwareName = softwareName;
	}
	public String getTcoSoftwareName() {
		return tcoSoftwareName;
	}
	public void setTcoSoftwareName(String tcoSoftwareName) {
		this.tcoSoftwareName = tcoSoftwareName;
	}
	public String getSoftwareDeveloper() {
		return softwareDeveloper;
	}
	public void setSoftwareDeveloper(String softwareDeveloper) {
		this.softwareDeveloper = softwareDeveloper;
	}
	public String getContractCount() {
		return contractCount;
	}
	public void setContractCount(String contractCount) {
		this.contractCount = contractCount;
	}
	public String getManagementCount() {
		return managementCount;
	}
	public void setManagementCount(String managementCount) {
		this.managementCount = managementCount;
	}
	public String getEvidenceYn() {
		return evidenceYn;
	}
	public void setEvidenceYn(String evidenceYn) {
		this.evidenceYn = evidenceYn;
	}
	public String getEvidenceType() {
		return evidenceType;
	}
	public void setEvidenceType(String evidenceType) {
		this.evidenceType = evidenceType;
	}
	public String getSoftwarePublisher() {
		return softwarePublisher;
	}
	public void setSoftwarePublisher(String softwarePublisher) {
		this.softwarePublisher = softwarePublisher;
	}
	public String getCertificationKey() {
		return certificationKey;
	}
	public void setCertificationKey(String certificationKey) {
		this.certificationKey = certificationKey;
	}
	public String getCertificationType() {
		return certificationType;
	}
	public void setCertificationType(String certificationType) {
		this.certificationType = certificationType;
	}
	public String getCertificationGroup() {
		return certificationGroup;
	}
	public void setCertificationGroup(String certificationGroup) {
		this.certificationGroup = certificationGroup;
	}
	public String getInstallStep() {
		return installStep;
	}
	public void setInstallStep(String installStep) {
		this.installStep = installStep;
	}
	public String getInstallType() {
		return installType;
	}
	public void setInstallType(String installType) {
		this.installType = installType;
	}
	public String getInstallUrl() {
		return installUrl;
	}
	public void setInstallUrl(String installUrl) {
		this.installUrl = installUrl;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getModDate() {
		return modDate;
	}
	public void setModDate(String modDate) {
		this.modDate = modDate;
	}
	public String getRegUserId() {
		return regUserId;
	}
	public void setRegUserId(String regUserId) {
		this.regUserId = regUserId;
	}
	public String getModUserId() {
		return modUserId;
	}
	public void setModUserId(String modUserId) {
		this.modUserId = modUserId;
	}


	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
