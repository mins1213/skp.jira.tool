package skp.bo.api.jira.vo;

public class TicketCommentVO {

	private Integer commentId;
	private Integer ticketId;
	private String corpGubun;
	private String creatorKey;
	private String creatorName;
	private String contents;
	private String createDate;
	private String updateDate;


	public String getCorpGubun() {
		return corpGubun;
	}
	public void setCorpGubun(String corpGubun) {
		this.corpGubun = corpGubun;
	}
	public Integer getCommentId() {
		return commentId;
	}
	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}
	public Integer getTicketId() {
		return ticketId;
	}
	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}
	public String getCreatorKey() {
		return creatorKey;
	}
	public void setCreatorKey(String creatorKey) {
		this.creatorKey = creatorKey;
	}
	public String getCreatorName() {
		return creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}


}
