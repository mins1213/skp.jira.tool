package skp.bo.api.jira.type;

import java.util.HashMap;
import java.util.Map;

public enum SwUseStatusType {

	SW입고("US01"),
	사용대기("US02"),
	설치확인("US03"),
	SW파기("US08"),
	사용중("US04"),
	반납대기("US05"),
	반납확인("US06"),
	라이선스_초기화("US07"),

	OK("OK");


	private String reqType;

	private SwUseStatusType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}

	private static final Map<String, SwUseStatusType> stringToEnum2 = new HashMap<>();
	static{
		for(SwUseStatusType type : values()){
			stringToEnum2.put(type.getValue(), type);
		}
	}

	public static SwUseStatusType toValuefromString(String value){
		return stringToEnum2.get(value);
	}
}
