package skp.bo.api.hioms.service;

import skp.bo.api.hioms.xml.ReqBaseXml;
import skp.bo.api.hioms.xml.Response.ResBaseXml;

public interface HiOmsService {

	public String sendTicketRequestToHiOms(String ticketId, String corpGubun) throws Exception;

	public Object interfaceHiOms(ReqBaseXml requestVO, Object response) throws Exception;

}
