package skp.bo.api.hioms.Type;

public enum HiOmsReqType {

	SVCI00001_SVCID("svci00001"),
	SVCI00002_SVCID("svci00002"),
	SVCI00003_SVCID("svci00003"),
	SVCS00001_SVCID("svcs00001"),
	SVCS00032_SVCID("svcs00032"),
	REQUEST_NUM_PREFIX("S"),
	CUST_CO_APV_NO_PREFIX("A"),
	CLL_CUST_CO_CD_SKP("34"),						//고객사_요청_번호 SKP
	CLL_CUST_CO_CD_11ST("45"),						//고객사_요청_번호 11ST
	CLL_CUST_CO_BUSI_UNT_CD("01"),				//요청_고객사_사업_단위_코드
	OS_CLL_TP_CD("6402"),						//OS_요청_유형_코드(시스템개선 요청)
	OS_CLL_KIND_CD("640205"),					//OS_요청_종류_코드
	CLL_RSN_BDWN("[IT요청관리]작업이 필요한 문서입니다."),	//요청_사유_내역
	IF_SNO("1"),								//처리자_일련번호
	IF_CS01_MSG_FAIL("총 0 건"),					//인터페이스 파라메터 에러로 HIoms에 등록이 되지 않았을때 0건으로 나옴.

	IF_SEND_COMPLETE("Y"),
	IF_SEND_INCOMPLETE("N"),
	IF_COMPLETED("Y"),
	IF_INCOMPLETE("N"),
	IF_MSG_FAIL("F"),
	IF_ERROR("E"),
	IF_ERROR_MSG("인터페이스 처리중 에러가 발생 하였습니다"),

	REQ_COMPLETED("종료"),
	REQ_RETURNED("반려처리완료"),
	REQ_INCOMPLETE("미완료"),
	RESOLUTION_DONE("DONE"),
	OK("OK");

	private String reqType;

	private HiOmsReqType(String reqType){
		this.reqType = reqType;
	}

	public String getValue(){
		return this.reqType;
	}

}
