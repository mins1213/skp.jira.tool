package skp.bo.api.hioms.controller;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import skp.bo.api.hioms.service.HiOmsService;
import skp.bo.api.silhouette.service.SilhouetteService;

@RestController
public class HiOmsController {

	private static final Logger logger = LoggerFactory.getLogger(HiOmsController.class);

	@Resource(name="skp.bo.api.hioms.service.HiOmsService")
	private HiOmsService hiOmsService;

	@Autowired
	private SilhouetteService silhouetteService;

	@RequestMapping(value = "/hioms/sendticket/{ticketKey}", method = RequestMethod.GET)
	public String sendHiOmsRequest(@PathVariable("ticketKey")String ticketKey, Model model)throws Exception {

		hiOmsService.sendTicketRequestToHiOms(ticketKey, "S");

		return null;
	}

	@RequestMapping(value = "/sil/sendticket/{ticketId}", method = RequestMethod.GET)
	public String sendSilRequest(@PathVariable("ticketId")String ticketId, Model model)throws Exception {

		silhouetteService.sendTicketRequestToSilhouette(ticketId, "S");

		return null;
	}

}
