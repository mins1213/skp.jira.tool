package skp.bo.api.hioms.test;

import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import skp.bo.api.hioms.xml.ReqBaseXml;
import skp.bo.api.hioms.xml.Svci00001;

public class ZtestXmlMarshalMain {

	public static void main(String[] args) throws JAXBException, IOException{

		Svci00001 ci01 = new Svci00001();
		ci01.setSys_key("<<시스템 키 넣을 곳>> ");
		ci01.setSvc_id("서비스ID");

		ReqBaseXml xml = new ReqBaseXml();
		xml.getCi01().add(ci01);

		JAXBContext context = JAXBContext.newInstance(ReqBaseXml.class);
		Marshaller m = context.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

     // Write to System.out
        m.marshal(xml, System.out);


	}

}
