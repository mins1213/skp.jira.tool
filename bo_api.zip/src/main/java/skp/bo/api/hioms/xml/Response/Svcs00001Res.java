package skp.bo.api.hioms.xml.Response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="dataSet")
@XmlType(propOrder={"message", "fields", "recordSet"})
public class Svcs00001Res {

	Fields fields;

	public Svcs00001Res(){
		Fields fields = new Fields();
		this.fields = fields;

	}

	private List<ResMessage> message = new ArrayList<ResMessage>();
	public List<ResMessage> getMessage() {
		return message;
	}

	public void setMessage(List<ResMessage> message) {
		this.message = message;
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name="fields")
	public static class Fields{
		private String reqtNo;

		public String getReqtNo() {
			return reqtNo;
		}

		public void setReqtNo(String reqtNo) {
			this.reqtNo = reqtNo;
		}
	}

	public void setFieldsReqtNo(String reqtNo){
		this.fields.setReqtNo(reqtNo);
	}

	private List<Svcs00001RecordSetRes>  recordSet = null;
	public List<Svcs00001RecordSetRes> getRecordSet() {
		return recordSet;
	}
	public void setRecordSet(List<Svcs00001RecordSetRes> recordSet) {
		this.recordSet = recordSet;
	}






}
