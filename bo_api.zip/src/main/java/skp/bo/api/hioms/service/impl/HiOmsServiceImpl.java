package skp.bo.api.hioms.service.impl;

import java.io.File;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;


import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import skp.bo.api.hioms.xml.Response.Ci01ResBaseXml;
import skp.bo.api.SystemConstant;
import skp.bo.api.hioms.Type.HiOmsReqType;
import skp.bo.api.hioms.mapper.HiOmsMapper;
import skp.bo.api.hioms.service.HiOmsService;
import skp.bo.api.hioms.vo.HiOmsRequestInfoVO;
import skp.bo.api.hioms.vo.HiOmsUserVO;
import skp.bo.api.hioms.xml.ReqBaseXml;
import skp.bo.api.hioms.xml.Svci00001;
import skp.bo.api.hioms.xml.Svci00002;
import skp.bo.api.hioms.xml.Svci00003;
import skp.bo.api.jira.mapper.JiraTicketMapper;
import skp.bo.api.jira.vo.AttachmentVO;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.util.FtpClient;
import skp.bo.api.util.SftpClient;
import skp.bo.api.util.StaticPropertyUtil;

@org.springframework.stereotype.Service("skp.bo.api.hioms.service.HiOmsService")
public class HiOmsServiceImpl implements HiOmsService {

	private static final Logger logger = LoggerFactory.getLogger(HiOmsServiceImpl.class);
	private static final Logger ifLog = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_HIOMS);

	@Autowired
	JiraTicketMapper jiraTicketMapper;

	@Autowired
	HiOmsMapper hiOmsMapper;

	@Transactional
	@Override
	public String sendTicketRequestToHiOms(String ticketId, String corpGubun) throws Exception{

		TicketInfoVO paramSelectTicketInfo = new TicketInfoVO();
        paramSelectTicketInfo.setTicketId(Integer.parseInt(ticketId));
        paramSelectTicketInfo.setCorpGubun(corpGubun);
        TicketInfoVO ticket = jiraTicketMapper.selectTicketInfo(paramSelectTicketInfo);
		List<HiOmsUserVO> omsUserInfo = hiOmsMapper.selectHiOmsUserList(ticket.getAssigneeKey());
		String omsUserId = "";
		int hiomsYnCnt = 0;
		for (HiOmsUserVO hiOmsUserVO : omsUserInfo) {
			omsUserId = hiOmsUserVO.getHiomsId();
			//HI-OMS 인터페이스 전송자가 있는지 확인
			if("Y".equals(hiOmsUserVO.getHiomsYn())){
				hiomsYnCnt++;
			}
		}
		//HI-OMS 인터페이스 전송자가 1명도 없을 경우 그대로 완료처리
		if(hiomsYnCnt <= 0){
			return null;
		}

        ReqBaseXml reqCi01Xml = setSvci00001Xml(ticket);
        Ci01ResBaseXml resCi01Xml = (Ci01ResBaseXml)interfaceHiOms(reqCi01Xml, new Ci01ResBaseXml());

        boolean bExecuteNextIFyn = false;

        if(resCi01Xml != null){
        	Svci00001 ci01 = reqCi01Xml.getCi01().get(0);
        	HiOmsRequestInfoVO hiomsVO = new HiOmsRequestInfoVO();

        	String ifResult = resCi01Xml.getCi01().get(0).getMessage().get(0).getResult();

        	hiomsVO.setTicketId(ticket.getTicketId());
        	hiomsVO.setTicketKey(ticket.getTicketKey());
        	hiomsVO.setIfGubun("H");	//인터페이스 구분 : H - hioms, S - 실루엣
        	hiomsVO.setCorpGubun(corpGubun);	//회사 구분
        	hiomsVO.setRequestNumber(ci01.getCust_co_cll_no());
        	hiomsVO.setRequestSendYn(HiOmsReqType.IF_SEND_COMPLETE.getValue());
        	hiomsVO.setRequestSendDay("NOW");
        	hiomsVO.setRequestUserId(ticket.getReporterKey());
        	hiomsVO.setRequestOmsUserId(omsUserId);

        	//Y: 완료, N: 미완료, E:에러, HIOMS에서 처리완료 된후 Y 값 넣는다. 처음 등록시 N 미처리 등록
        	hiomsVO.setRequestResultYn(HiOmsReqType.IF_INCOMPLETE.getValue());
        	if("OK".equals(ifResult)){
        		bExecuteNextIFyn = true;
        	}else if("FAIL".equals(ifResult)){
        		hiomsVO.setRequestResultYn(HiOmsReqType.IF_ERROR.getValue());
        	}
        	hiomsVO.setRequestReponse(transVoToString(resCi01Xml));

        	hiOmsMapper.insertRequestInfo(hiomsVO);

            if(bExecuteNextIFyn){

            	//svci00003 담당자 정보 등록 인터페이스 시작
            	int ii = 1;
            	for (HiOmsUserVO hiOmsUserVO : omsUserInfo){
            		if("Y".equals(hiOmsUserVO.getHiomsYn())){
            			ReqBaseXml reqCi03Xml = setSvci00003Xml(hiomsVO);
                		reqCi03Xml.getCi03().get(0).setIf_sno(Integer.toString(ii));
                		reqCi03Xml.getCi03().get(0).setPrc_eno(hiOmsUserVO.getHiomsId());
                    	Ci01ResBaseXml resCi03Xml = (Ci01ResBaseXml)interfaceHiOms(reqCi03Xml, new Ci01ResBaseXml());
                    	ii++;
            		}
            	}

            	AttachmentVO paramSelectAttachmentList = new AttachmentVO();
        		paramSelectAttachmentList.setTicketId(Integer.parseInt(ticketId));
        		paramSelectAttachmentList.setCorpGubun(corpGubun);
                List<AttachmentVO> attachment = jiraTicketMapper.selectAttachmentList(paramSelectAttachmentList);
                if(attachment.size() > 0){
                	ReqBaseXml reqCi02Xml = setSvci00002Xml(hiomsVO, attachment);
                	Ci01ResBaseXml resCi02Xml = (Ci01ResBaseXml)interfaceHiOms(reqCi02Xml, new Ci01ResBaseXml());

                	int iFile = 1;
                    for (AttachmentVO fileInfo : attachment) {
                    	String ext = "";
            			if(fileInfo.getSaveFileName().indexOf(".") > -1){
            				ext = fileInfo.getSaveFileName().substring(fileInfo.getSaveFileName().indexOf("."), fileInfo.getSaveFileName().length());
            			}
                    	File realFile = new File(fileInfo.getSaveFilePath() + hiomsVO.getRequestNumber() + "_" + iFile + ext);
                    	ifLog.info("Hi-OMS SFTP Upload target File : {} , {}",fileInfo.getSaveFilePath()+fileInfo.getSaveFileName(), realFile.getName());

                    	if(realFile.exists()){
//                    		ftp().storeFile(new FileInputStream(realFile), realFile.getName(), "");
                    		sftp().upload(realFile);
                    	}else{
                    		ifLog.error("Hi-OMS FTP FILEUPLOAD ERROR. FILE NOT FOUND! API_ATTACHMENT.ATTACH_ID : {}",fileInfo.getAttachId());
                    	}
                    	iFile++;
            		}//for attachment END
                }//if attachment.size() > 0 END
            }//if if(bExecuteNextIFyn) END
        }else{
        	//ResBaseXml resCi01Xml = interfaceHiOms(reqCi01Xml); 결과값이 null 일때
        	Svci00001 ci01 = reqCi01Xml.getCi01().get(0);
        	HiOmsRequestInfoVO hiomsVO = new HiOmsRequestInfoVO();

        	hiomsVO.setTicketId(ticket.getTicketId());
        	hiomsVO.setTicketKey(ticket.getTicketKey());
        	hiomsVO.setIfGubun("H");	//인터페이스 구분 : H - hioms, S - 실루엣
        	hiomsVO.setCorpGubun(corpGubun);	//회사 구분
        	hiomsVO.setRequestNumber(ci01.getCust_co_cll_no());
        	hiomsVO.setRequestSendYn(HiOmsReqType.IF_SEND_COMPLETE.getValue());
        	hiomsVO.setRequestSendDay("NOW");
        	hiomsVO.setRequestUserId(ticket.getReporterKey());
        	hiomsVO.setRequestOmsUserId(omsUserId);
        	hiomsVO.setRequestResultYn(HiOmsReqType.IF_ERROR.getValue());
        	hiomsVO.setRequestReponse(HiOmsReqType.IF_ERROR_MSG.getValue());

        	hiOmsMapper.insertRequestInfo(hiomsVO);
        }

		return null;
	}

	private ReqBaseXml setSvci00002Xml(HiOmsRequestInfoVO hiomsVO, List<AttachmentVO> attachment) throws Exception{
		ReqBaseXml mainXml = new ReqBaseXml();

		String CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_11ST.getValue();
		if("S".equals(hiomsVO.getCorpGubun())){//11번가 - E , SKP - S
			CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_SKP.getValue();
		}

		Svci00002 ci02 = new Svci00002();
		ci02.setSys_key(StaticPropertyUtil.getProperty("hioms.sys_key"));
		ci02.setSvc_id(HiOmsReqType.SVCI00002_SVCID.getValue());
		ci02.setCust_co_cll_no(hiomsVO.getRequestNumber());
		ci02.setCll_cust_co_cd(CLL_CUST_CO_CD);
		String fileNm = hiomsVO.getRequestNumber() + "_";

		for (int i = 0; i < attachment.size(); i++) {
			AttachmentVO attach = attachment.get(i);
			String ext = "";
			if(attach.getSaveFileName().indexOf(".") > -1){
				ext = attach.getSaveFileName().substring(attach.getSaveFileName().indexOf("."), attach.getSaveFileName().length());
			}
			if(i==0){
				ci02.setN1_atch_file_nm(attach.getSaveFileName());
				Files.copy(Paths.get(attach.getSaveFilePath() + attach.getSaveFileName()), Paths.get(attach.getSaveFilePath() + fileNm + "1" + ext),StandardCopyOption.REPLACE_EXISTING);
			}
			else if(i==1){
				ci02.setN2_atch_file_nm(attach.getSaveFileName());
				Files.copy(Paths.get(attach.getSaveFilePath() + attach.getSaveFileName()), Paths.get(attach.getSaveFilePath() + fileNm + "2" + ext),StandardCopyOption.REPLACE_EXISTING);
			}
			else if(i==2){
				ci02.setN3_atch_file_nm(attach.getSaveFileName());
				Files.copy(Paths.get(attach.getSaveFilePath() + attach.getSaveFileName()), Paths.get(attach.getSaveFilePath() + fileNm + "3" + ext),StandardCopyOption.REPLACE_EXISTING);
			}
			else if(i==3){
				ci02.setN4_atch_file_nm(attach.getSaveFileName());
				Files.copy(Paths.get(attach.getSaveFilePath() + attach.getSaveFileName()), Paths.get(attach.getSaveFilePath() + fileNm + "4" + ext),StandardCopyOption.REPLACE_EXISTING);
			}
			else if(i==4){
				ci02.setN5_atch_file_nm(attach.getSaveFileName());
				Files.copy(Paths.get(attach.getSaveFilePath() + attach.getSaveFileName()), Paths.get(attach.getSaveFilePath() + fileNm + "5" + ext),StandardCopyOption.REPLACE_EXISTING);
			}
		}

		mainXml.setCi02(new ArrayList<Svci00002>());
		mainXml.getCi02().add(ci02);

		return mainXml;
	}

	private ReqBaseXml setSvci00003Xml(HiOmsRequestInfoVO hiomsVO) throws Exception{
		ReqBaseXml mainXml = new ReqBaseXml();

		String CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_11ST.getValue();
		if("S".equals(hiomsVO.getCorpGubun())){	//11번가 - E , SKP - S
			CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_SKP.getValue();
		}

		Svci00003 ci03 = new Svci00003();
		ci03.setSys_key(StaticPropertyUtil.getProperty("hioms.sys_key"));
		ci03.setSvc_id(HiOmsReqType.SVCI00003_SVCID.getValue());
		ci03.setCust_co_cll_no(hiomsVO.getRequestNumber());
		ci03.setCll_cust_co_cd(CLL_CUST_CO_CD);		//요청_고객사_코드
		ci03.setIf_sno(HiOmsReqType.IF_SNO.getValue());
		ci03.setPrc_eno(hiomsVO.getRequestOmsUserId());
		ci03.setCtrl_twr_yn("");
		mainXml.setCi03(new ArrayList<Svci00003>());
		mainXml.getCi03().add(ci03);

		return mainXml;
	}
	private ReqBaseXml setSvci00001Xml(TicketInfoVO ticket) throws Exception{

		ReqBaseXml mainXml = new ReqBaseXml();

		String CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_11ST.getValue();
		if("S".equals(ticket.getCorpGubun())){//11번가 - E , SKP - S
			CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_SKP.getValue();
		}

		String custReqNo = HiOmsReqType.REQUEST_NUM_PREFIX.getValue() + ticket.getCorpGubun() + StringUtils.leftPad(Integer.toString(ticket.getTicketId()), 10, "0");
		String cllDt = ticket.getCreateDate().split("T")[0].replaceAll("-", "");
		String hopeDt = null;
		if(ticket.getDueDate() != null){
			hopeDt = StringUtils.defaultString(ticket.getDueDate()).split("T")[0].replaceAll("-", "");
		}

//		ILMpersonInfoVO personInfo = hiOmsMapper.selectILMpersonInfo(ticket.getReporterKey());

		Svci00001 ci01 = new Svci00001();
		ci01.setSys_key(StaticPropertyUtil.getProperty("hioms.sys_key"));	//OMS시스템에서 각 연계시스템 별로 발급 한 Key
		ci01.setSvc_id(HiOmsReqType.SVCI00001_SVCID.getValue());				//요청하고자 하는 연계서비스 아이디
		ci01.setCust_co_cll_no(custReqNo);									//고객사_요청_번호
		ci01.setCll_cust_co_cd(CLL_CUST_CO_CD);		//요청_고객사_코드
		ci01.setCll_cust_co_busi_unt_cd(
				HiOmsReqType.CLL_CUST_CO_BUSI_UNT_CD.getValue());				//요청_고객사_사업_단위_코드
		ci01.setCust_co_apv_no(
				HiOmsReqType.CUST_CO_APV_NO_PREFIX.getValue() +custReqNo);		//고객사_승인_번호
		ci01.setCll_eno(ticket.getReporterKey());							//요청_사원번호
		ci01.setOs_cll_tp_cd(HiOmsReqType.OS_CLL_TP_CD.getValue());			//OS_요청_유형_코드
		ci01.setOs_cll_kind_cd(HiOmsReqType.OS_CLL_KIND_CD.getValue()); 		//OS_요청_종류_코드
		ci01.setCll_dt(cllDt); 												//요청_일자
		ci01.setHope_dt(hopeDt); 											//희망_일자
		ci01.setCll_rsn_bdwn(HiOmsReqType.CLL_RSN_BDWN.getValue());			//요청_사유_내역
		ci01.setCll_titl(ticket.getSummary());								//요청_제목
		ci01.setCll_cntn(StringUtils.defaultString(ticket.getDescription(), "내용없음")); 	//요청_내용
		ci01.setPrc_cust_co_busi_unt_cd(
				HiOmsReqType.CLL_CUST_CO_BUSI_UNT_CD.getValue()); 				//처리_고객사_사업_단위_코드
		ci01.setPrc_cust_co_cd(CLL_CUST_CO_CD); 		//처리_고객사_코드
		mainXml.setCi01(new ArrayList<Svci00001>());
		mainXml.getCi01().add(ci01);

		return mainXml;

	}

	@Override
	public Object interfaceHiOms(ReqBaseXml requestVO, Object response) throws Exception{

		Object xmlVO = null;

		String strRequestParam = transVoToString(requestVO);

		try {
			// 웹 서비스 access point 지정
			String endpoint = StaticPropertyUtil.getProperty("hioms.ws.url");

			// 원격 웹 서비스에 대한 Service 객체 생성후, Call 객체 생성
			Service service = new Service();
			Call call = (Call) service.createCall();

			// 입출력 인자정보 및 웹 서비스 access point 를 Call 객체에 바인딩
			call.setTargetEndpointAddress( new URL(endpoint) );
			call.setOperationName(
					new QName("http://webservice.om.skcc.com","getOmWebservice")  );
						call.addParameter("request", XMLType.XSD_STRING, ParameterMode.IN);
						call.setReturnType(XMLType.XSD_STRING);

			// 입력 인자값을 가지고 웹 서비스 호출하여 실행결과 얻어옴
			String responseXml = (String)call.invoke(new Object[] {new String(strRequestParam)});
			ifLog.debug("HI-OMS RESPONSE XML : {} \n", responseXml);

			Unmarshaller um = JAXBContext.newInstance(response.getClass()).createUnmarshaller();
			xmlVO = (Object)um.unmarshal(new StringReader(responseXml));

		} catch (Exception e) {
			ifLog.error("Hi-OMS IF ERROR \n", e);
		}

		return xmlVO;
	}

	public String transVoToString(Object jaxbParam){

		String result = "";
		try {
			JAXBContext context = JAXBContext.newInstance(jaxbParam.getClass());
			Marshaller m = context.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        Writer writer = new StringWriter();
	        m.marshal(jaxbParam, writer);
	        result = writer.toString();

		} catch (JAXBException e) {
			e.printStackTrace();
			ifLog.error("Trans value object to String error\n",e);
		}
		ifLog.info(result);
		return result;
	}

	public FtpClient ftp() {

		String ftpIp = StaticPropertyUtil.getProperty("hioms.ftp.ip");
		int ftpPort = Integer.parseInt(StaticPropertyUtil.getProperty("hioms.ftp.port"));
		String ftpId = StaticPropertyUtil.getProperty("hioms.ftp.id");
		String ftpPw = StaticPropertyUtil.getProperty("hioms.ftp.pw");
		String ftpRemoteDir = StaticPropertyUtil.getProperty("hioms.ftp.upload.dir");
		FtpClient ftp = null;
		try {
			ftp = new FtpClient(ftpIp, ftpPort, ftpId, ftpPw, ftpRemoteDir);
		} catch (Exception e) {
			ifLog.error("Ftp Connect Error ",e);
		}
		return ftp;
	}

	public SftpClient sftp() {

		String ftpIp = StaticPropertyUtil.getProperty("hioms.ftp.ip");
		int ftpPort = Integer.parseInt(StaticPropertyUtil.getProperty("hioms.ftp.port"));
		String ftpId = StaticPropertyUtil.getProperty("hioms.ftp.id");
		String ftpPw = StaticPropertyUtil.getProperty("hioms.ftp.pw");
		String ftpRemoteDir = StaticPropertyUtil.getProperty("hioms.ftp.upload.dir");
		SftpClient sftp = null;
		try {
			sftp = new SftpClient(ftpIp, ftpPort, ftpId, ftpPw, ftpRemoteDir);
		} catch (Exception e) {
			ifLog.error("SFtp Connect Error ",e);
		}
		return sftp;
	}


}
