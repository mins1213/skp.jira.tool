package skp.bo.api.hioms.vo;

public class HiOmsUserVO {

	private String userId;
	private String hiomsId;
	private String hiomsYn;
	private String silhouetteYn;
	private String regDate;


	public String getHiomsYn() {
		return hiomsYn;
	}
	public void setHiomsYn(String hiomsYn) {
		this.hiomsYn = hiomsYn;
	}
	public String getSilhouetteYn() {
		return silhouetteYn;
	}
	public void setSilhouetteYn(String silhouetteYn) {
		this.silhouetteYn = silhouetteYn;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getHiomsId() {
		return hiomsId;
	}
	public void setHiomsId(String hiomsId) {
		this.hiomsId = hiomsId;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}


}
