package skp.bo.api.hioms.xml.Response;

import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class UnmarshallerTest {

	public static void main(String[] args) throws JAXBException {

		ResBaseXml xml = new ResBaseXml();

		Svci00001Res ci01res = new Svci00001Res();
		ci01res.setFieldsReqtNo("EXT-000046-00001-0000365");

		ResMessage msg = new ResMessage();
		msg.setResult("OK");
		msg.setMessageId("SKFI4002");
		msg.setMessageName("총 1건 입력");
		msg.setMessageReason("");
		msg.setMessageRemark("Insert");

		ci01res.getMessage().add(msg);
		xml.setCi01(new ArrayList<Svci00001Res>());
		xml.getCi01().add(ci01res);

		ResTransaction trs = new ResTransaction();
		trs.setId("skcc.om.EXTIF.EXTIFMgr#svci00001");
		trs.setStartDate("2017-07-31T15:02:50.045");
		trs.setEndDate("2017-07-31T15:02:50.161");

		xml.setTransaction(trs);



		JAXBContext context = JAXBContext.newInstance(ResBaseXml.class);
		Marshaller m = context.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);

     // Write to System.out
        Writer writer = new StringWriter();
        m.marshal(xml, writer);

		String strInParam = writer.toString();
		strInParam = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + strInParam;
		System.out.println(strInParam);


		Unmarshaller um = context.createUnmarshaller();
		ResBaseXml xmlVO = (ResBaseXml)um.unmarshal(new StringReader(strInParam));

		System.out.println(xmlVO.getTransaction().getStartDate());


	}

}
