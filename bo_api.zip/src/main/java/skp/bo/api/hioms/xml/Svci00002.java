package skp.bo.api.hioms.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="fields")
public class Svci00002 {

	private String sys_key = "";
	private String svc_id = "";
	private String cust_co_cll_no = "";
	private String cll_cust_co_cd = "";
	private String n1_atch_file_nm = "";
	private String n2_atch_file_nm = "";
	private String n3_atch_file_nm = "";
	private String n4_atch_file_nm = "";
	private String n5_atch_file_nm = "";


	public String getSys_key() {
		return sys_key;
	}
	public void setSys_key(String sys_key) {
		this.sys_key = sys_key;
	}
	public String getSvc_id() {
		return svc_id;
	}
	public void setSvc_id(String svc_id) {
		this.svc_id = svc_id;
	}
	public String getCust_co_cll_no() {
		return cust_co_cll_no;
	}
	public void setCust_co_cll_no(String cust_co_cll_no) {
		this.cust_co_cll_no = cust_co_cll_no;
	}
	public String getCll_cust_co_cd() {
		return cll_cust_co_cd;
	}
	public void setCll_cust_co_cd(String cll_cust_co_cd) {
		this.cll_cust_co_cd = cll_cust_co_cd;
	}
	public String getN1_atch_file_nm() {
		return n1_atch_file_nm;
	}
	public void setN1_atch_file_nm(String n1_atch_file_nm) {
		this.n1_atch_file_nm = n1_atch_file_nm;
	}
	public String getN2_atch_file_nm() {
		return n2_atch_file_nm;
	}
	public void setN2_atch_file_nm(String n2_atch_file_nm) {
		this.n2_atch_file_nm = n2_atch_file_nm;
	}
	public String getN3_atch_file_nm() {
		return n3_atch_file_nm;
	}
	public void setN3_atch_file_nm(String n3_atch_file_nm) {
		this.n3_atch_file_nm = n3_atch_file_nm;
	}
	public String getN4_atch_file_nm() {
		return n4_atch_file_nm;
	}
	public void setN4_atch_file_nm(String n4_atch_file_nm) {
		this.n4_atch_file_nm = n4_atch_file_nm;
	}
	public String getN5_atch_file_nm() {
		return n5_atch_file_nm;
	}
	public void setN5_atch_file_nm(String n5_atch_file_nm) {
		this.n5_atch_file_nm = n5_atch_file_nm;
	}

}
