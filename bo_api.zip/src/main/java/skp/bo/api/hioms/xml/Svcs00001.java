package skp.bo.api.hioms.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="fields")
public class Svcs00001 {

	private String sys_key = "";
	private String svc_id = "";
	private String sc_strt_dt = "";
	private String sc_end_dt = "";
	private String sc_cb_cust = "";
	private String sc_cust_co_cll_no = "";
	private String sc_prc_yn = "";

	public String getSys_key() {
		return sys_key;
	}
	public void setSys_key(String sys_key) {
		this.sys_key = sys_key;
	}
	public String getSvc_id() {
		return svc_id;
	}
	public void setSvc_id(String svc_id) {
		this.svc_id = svc_id;
	}
	public String getSc_strt_dt() {
		return sc_strt_dt;
	}
	public void setSc_strt_dt(String sc_strt_dt) {
		this.sc_strt_dt = sc_strt_dt;
	}
	public String getSc_end_dt() {
		return sc_end_dt;
	}
	public void setSc_end_dt(String sc_end_dt) {
		this.sc_end_dt = sc_end_dt;
	}
	public String getSc_cb_cust() {
		return sc_cb_cust;
	}
	public void setSc_cb_cust(String sc_cb_cust) {
		this.sc_cb_cust = sc_cb_cust;
	}
	public String getSc_cust_co_cll_no() {
		return sc_cust_co_cll_no;
	}
	public void setSc_cust_co_cll_no(String sc_cust_co_cll_no) {
		this.sc_cust_co_cll_no = sc_cust_co_cll_no;
	}
	public String getSc_prc_yn() {
		return sc_prc_yn;
	}
	public void setSc_prc_yn(String sc_prc_yn) {
		this.sc_prc_yn = sc_prc_yn;
	}



}
