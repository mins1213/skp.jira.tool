package skp.bo.api.hioms.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="fields")
public class Svci00003 {

	private String sys_key = "";
	private String svc_id = "";
	private String cust_co_cll_no = "";
	private String cll_cust_co_cd = "";
	private String if_sno = "";
	private String prc_eno = "";
	private String ctrl_twr_yn = "";

	public String getSys_key() {
		return sys_key;
	}
	public void setSys_key(String sys_key) {
		this.sys_key = sys_key;
	}
	public String getSvc_id() {
		return svc_id;
	}
	public void setSvc_id(String svc_id) {
		this.svc_id = svc_id;
	}
	public String getCust_co_cll_no() {
		return cust_co_cll_no;
	}
	public void setCust_co_cll_no(String cust_co_cll_no) {
		this.cust_co_cll_no = cust_co_cll_no;
	}
	public String getCll_cust_co_cd() {
		return cll_cust_co_cd;
	}
	public void setCll_cust_co_cd(String cll_cust_co_cd) {
		this.cll_cust_co_cd = cll_cust_co_cd;
	}
	public String getIf_sno() {
		return if_sno;
	}
	public void setIf_sno(String if_sno) {
		this.if_sno = if_sno;
	}
	public String getPrc_eno() {
		return prc_eno;
	}
	public void setPrc_eno(String prc_eno) {
		this.prc_eno = prc_eno;
	}
	public String getCtrl_twr_yn() {
		return ctrl_twr_yn;
	}
	public void setCtrl_twr_yn(String ctrl_twr_yn) {
		this.ctrl_twr_yn = ctrl_twr_yn;
	}



}
