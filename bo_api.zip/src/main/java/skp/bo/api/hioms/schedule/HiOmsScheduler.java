package skp.bo.api.hioms.schedule;

import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import skp.bo.api.SystemConstant;
import skp.bo.api.hioms.Type.HiOmsReqType;
import skp.bo.api.hioms.mapper.HiOmsMapper;
import skp.bo.api.hioms.service.HiOmsService;
import skp.bo.api.hioms.vo.HiOmsRequestInfoVO;
import skp.bo.api.hioms.xml.ReqBaseXml;
import skp.bo.api.hioms.xml.Svcs00001;
import skp.bo.api.hioms.xml.Svcs00032;
import skp.bo.api.hioms.xml.Response.Cs01ResBaseXml;
import skp.bo.api.hioms.xml.Response.Cs32ResBaseXml;
import skp.bo.api.http.BoResponseErrorHandler;
import skp.bo.api.jira.mapper.JiraTicketMapper;
import skp.bo.api.jira.service.JiraRespService;
import skp.bo.api.jira.vo.TicketInfoVO;
import skp.bo.api.util.DateUtil;
import skp.bo.api.util.StaticPropertyUtil;

@Component
public class HiOmsScheduler {

	private static final Logger log = LoggerFactory.getLogger(HiOmsScheduler.class);

	private static final Logger logger = LoggerFactory.getLogger(SystemConstant.LOG4J_APPENDER_HIOMS);


	@Autowired
	HiOmsMapper hiOmsMapper;

	@Autowired
	JiraTicketMapper jiraTicketMapper;

	@Resource(name="skp.bo.api.hioms.service.HiOmsService")
	private HiOmsService hiOmsService;

	@Resource(name="skp.bo.api.jira.service.JiraRespService")
	private JiraRespService jiraRespService;

//	@Scheduled(cron = "0 0/1 * * * *") //매분 실행, 테스트용, 초 분 시 일 월 요일 연도
	@Scheduled(cron = "0 5 0/1 * * *")	//매시각 5분 실행.
	public void getHiOmsTicketStatus() {

		logger.info("##### HiOmsScheduler Start #####");

		try {
			HiOmsRequestInfoVO vo = new HiOmsRequestInfoVO();
			vo.setIfGubun("H");
			vo.setRequestResultYn("EN");	//ERROR or NOT 상태 가져오기.
			List<HiOmsRequestInfoVO> list = hiOmsMapper.selectHiomsInfo(vo);

			for (HiOmsRequestInfoVO omsInfo : list) {
				logger.info("## Ticket : {} \t REQ_NUM : {} ##", omsInfo.getTicketId(), omsInfo.getRequestNumber());

				if("E".equals(omsInfo.getRequestResultYn())){
					hiOmsService.sendTicketRequestToHiOms(Integer.toString(omsInfo.getTicketId()), omsInfo.getCorpGubun());
				}else{
					ReqBaseXml cs01Xml = new ReqBaseXml();
					Svcs00001 cs01 = new Svcs00001();
					cs01.setSys_key(StaticPropertyUtil.getProperty("hioms.sys_key"));
					cs01.setSvc_id(HiOmsReqType.SVCS00001_SVCID.getValue());
					cs01.setSc_strt_dt(omsInfo.getRequestSendDay());
					cs01.setSc_end_dt(DateUtil.currdate("yyyyMMdd"));

					String CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_11ST.getValue();
					if("S".equals(omsInfo.getCorpGubun())){//11번가 - E , SKP - S
						CLL_CUST_CO_CD = HiOmsReqType.CLL_CUST_CO_CD_SKP.getValue();
					}

					cs01.setSc_cb_cust(CLL_CUST_CO_CD);
					cs01.setSc_cust_co_cll_no(omsInfo.getRequestNumber());
					cs01Xml.setCs01(new ArrayList<Svcs00001>());
					cs01Xml.getCs01().add(cs01);

					Cs01ResBaseXml resCs01Xml = (Cs01ResBaseXml)hiOmsService.interfaceHiOms(cs01Xml, new Cs01ResBaseXml());
					if(resCs01Xml !=null){
						String processCompletedYn = resCs01Xml.getCs01().get(0).getRecordSet().get(0).getPrc_yn();
						String cs01Msg = StringUtils.defaultString(resCs01Xml.getCs01().get(0).getMessage().get(0).getMessageName());
						if(cs01Msg.indexOf(HiOmsReqType.IF_CS01_MSG_FAIL.getValue()) > -1){
							//hioms 인터페이스 정보 셋팅
							HiOmsRequestInfoVO paramHiomsInfo = new HiOmsRequestInfoVO();
							paramHiomsInfo.setTicketId(omsInfo.getTicketId());
							paramHiomsInfo.setIfGubun("H");
							paramHiomsInfo.setRequestNumber(omsInfo.getRequestNumber());
							paramHiomsInfo.setCorpGubun(omsInfo.getCorpGubun());
							paramHiomsInfo.setRequestReponse(transVoToString(resCs01Xml));
							paramHiomsInfo.setRequestResultDesc(cs01Msg);
							paramHiomsInfo.setUpdateDate("now");
							paramHiomsInfo.setRequestResultYn(HiOmsReqType.IF_MSG_FAIL.getValue());
							hiOmsMapper.updateRequestInfo(paramHiomsInfo);
						}

						if("Y".equals(processCompletedYn)){
							ReqBaseXml cs32Xml = new ReqBaseXml();
							Svcs00032 cs32 = new Svcs00032();
							//os_cll_no는 hioms에 등록 요청한 티켓이 hioms 배치를 통해 등록됐을 경우 생성된다.
							String os_cll_no = resCs01Xml.getCs01().get(0).getRecordSet().get(0).getOs_cll_no();
							cs32.setSys_key(StaticPropertyUtil.getProperty("hioms.sys_key"));
							cs32.setSvc_id(HiOmsReqType.SVCS00032_SVCID.getValue());
							cs32.setOs_cll_no(os_cll_no);
							cs32Xml.setCs32(new ArrayList<Svcs00032>());
							cs32Xml.getCs32().add(cs32);

							Cs32ResBaseXml resCs32Xml = (Cs32ResBaseXml)hiOmsService.interfaceHiOms(cs32Xml, new Cs32ResBaseXml());
							if(resCs32Xml != null){
								// api_hioms_request_info 테이블 업데이트
								String stts_cd_nm = resCs32Xml.getCs32().get(0).getStts_cd_nm();	//요청서 처리 상태
								String wrk_prc_cntn = resCs32Xml.getCs32().get(0).getWrk_prc_cntn();	//요청서 작업 처리 내용
								//hioms 인터페이스 정보 셋팅
								HiOmsRequestInfoVO paramHiomsInfo = new HiOmsRequestInfoVO();
								paramHiomsInfo.setTicketId(omsInfo.getTicketId());
								paramHiomsInfo.setIfGubun("H");
								paramHiomsInfo.setRequestNumber(omsInfo.getRequestNumber());
								paramHiomsInfo.setCorpGubun(omsInfo.getCorpGubun());
								paramHiomsInfo.setSearchRequestNumber(omsInfo.getRequestNumber());	//where 검색용
								paramHiomsInfo.setRequestReponse(transVoToString(resCs32Xml));
								paramHiomsInfo.setRequestResultDesc(wrk_prc_cntn);
								paramHiomsInfo.setUpdateDate("now");
								paramHiomsInfo.setRequestResultYn(HiOmsReqType.IF_COMPLETED.getValue());

								//우리쪽 api_ticket_info 에 update 하지 않는 이유 : 지라에 완료처리 인터페이스 하면 지라에서 다시 우리쪽에 상태값 정보를 넘겨준다. 이때 update
								if(HiOmsReqType.REQ_COMPLETED.getValue().equals(stts_cd_nm)
										|| HiOmsReqType.REQ_RETURNED.getValue().equals(stts_cd_nm)){
									//요청서 처리 종료, 반려처리완료
									if(omsInfo.getTicketKey().startsWith("NXMILE")){
										jiraRespService.sendTicketStatusCompleted(omsInfo.getTicketKey(),
												StaticPropertyUtil.getProperty("jira.restapi.completed.code.nxmile"));
									}else{
										jiraRespService.sendTicketStatusCompleted(omsInfo.getTicketKey());
									}
									jiraRespService.sendTicketComment(omsInfo.getTicketKey(), wrk_prc_cntn);
								}else{
									//미처리 (처리중)
									paramHiomsInfo.setRequestResultYn(HiOmsReqType.IF_INCOMPLETE.getValue());
								}
								hiOmsMapper.updateRequestInfo(paramHiomsInfo);

							}//if(resCs32Xml != null){ END
						}//if("Y".equals(processCompletedYn)){ END
					}//if(resCs01Xml !=null){ END
				}


			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("##### HiOmsScheduler END #####");
	}

	public String transVoToString(Object jaxbParam){

		String result = "";
		try {
			JAXBContext context = JAXBContext.newInstance(jaxbParam.getClass());
			Marshaller m = context.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        Writer writer = new StringWriter();
	        m.marshal(jaxbParam, writer);
	        result = writer.toString();

		} catch (JAXBException e) {
			e.printStackTrace();
			logger.error("Trans value object to String error\n",e);
		}
		return result;
	}

//	@Scheduled(cron = "0 0/1 * * * *") //매분 실행, 테스트용, 초 분 시 일 월 요일 연도
//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	@Scheduled(cron = "0 15,45 7-20 * * MON-FRI")	//월-금, 07시부터 20시까지, 매시각 15, 45분에 실행.
	// 지라 후커 변경으로 싱크를 따로 맞출 필요가 없음. 20190416 pp23455
	public void checkJiraTicket() throws Exception{

		logger.info("##### checkJiraTicket Scheduler START #####");

		List<TicketInfoVO> checkList = jiraTicketMapper.selectCheckTicketList();

		logger.info("##### checkJiraTicket Scheduler Check Cnt : {} #", checkList.size());

		for (TicketInfoVO ticketInfoVO : checkList) {

			String reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url")+ ticketInfoVO.getTicketId();
			if(SystemConstant.CORP_GUBUN_SKP.equals(ticketInfoVO.getCorpGubun())){
				reqTicketInfoUrl = StaticPropertyUtil.getProperty("jira.restapi.url.skp")+ ticketInfoVO.getTicketId();
			}

			RestTemplate restTemplate = new RestTemplate();
			MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
	        restTemplate.getMessageConverters().add(converter);
	        restTemplate.setErrorHandler(new BoResponseErrorHandler());

	        HttpHeaders reqHeaders = new HttpHeaders();
	        reqHeaders.setContentType(MediaType.APPLICATION_JSON);
	        HttpEntity<?> requestEntity = new HttpEntity<Object>(reqHeaders);

	        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(
	        		StaticPropertyUtil.getProperty("jira.restapi.id"),
	        		StaticPropertyUtil.getProperty("jira.restapi.pw")));

	        ResponseEntity<Map> responseEntity;
			try {
				responseEntity = restTemplate.exchange(reqTicketInfoUrl,  HttpMethod.GET, requestEntity, Map.class);

				if(responseEntity.getStatusCode().is2xxSuccessful()){
		        	Map<String, Object> totalMap = (Map<String, Object>) responseEntity.getBody();
			        Map<String, Object> fieldsMap = (Map<String, Object>) totalMap.get("fields");

			        String jiraTicketStatus = "";
			        Map<String, Object> statusMap = (Map<String, Object>)fieldsMap.get("status");
			        if(statusMap != null)  jiraTicketStatus = StringUtils.defaultString((String)statusMap.get("name"));	//티켓상태

			        logger.info("Check Jira Ticket Status ticket Key : {}, JIRA : {}, IBAS : {}, CORP {}", new Object[]{ticketInfoVO.getTicketKey(),jiraTicketStatus,ticketInfoVO.getStatus(), ticketInfoVO.getCorpGubun()});

			        if(!jiraTicketStatus.equals(ticketInfoVO.getStatus())){
			        	log.error("Ticket Status Not Match! ticket Key : {}, JIRA : {}, IBAS : {}, CORP {}", new Object[]{ticketInfoVO.getTicketKey(),jiraTicketStatus,ticketInfoVO.getStatus(), ticketInfoVO.getCorpGubun()});
			        	try {
							jiraRespService.requestJiraTicketInfo(Integer.toString(ticketInfoVO.getTicketId()), ticketInfoVO.getTicketKey(), ticketInfoVO.getCorpGubun());
						} catch (Exception e) {
							e.printStackTrace();
							log.error("Ticket Status Sync Error ticket Key : {}, JIRA : {}, IBAS : {}, CORP {}", new Object[]{ticketInfoVO.getTicketKey(),jiraTicketStatus,ticketInfoVO.getStatus(), ticketInfoVO.getCorpGubun()});
						}
			        }
		        }else{
		        	String errorMsg = responseEntity.getHeaders().get("error_body_string").get(0);
		        	logger.info("Check Jira Ticket Status ticket Key : {}, ErrorMsg : {}", ticketInfoVO.getTicketKey(), errorMsg);
		        }

			} catch (Exception e1) {
				e1.printStackTrace();
				logger.error("Check Jira Ticket Status ticket Key : {}, ErrorMsg : {}", ticketInfoVO.getTicketKey(), e1);
			}

		}

		logger.info("##### checkJiraTicket Scheduler END #####");

	}
}
