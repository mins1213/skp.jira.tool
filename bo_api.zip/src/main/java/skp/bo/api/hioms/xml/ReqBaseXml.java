package skp.bo.api.hioms.xml;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="request")
public class ReqBaseXml {

	@XmlElementWrapper(name="dataSet")
	@XmlElement(name="fields")
	private List<Svci00001> ci01 = null;
	public List<Svci00001> getCi01() {
		return ci01;
	}
	public void setCi01(List<Svci00001> ci01) {
		this.ci01 = ci01;
	}

	@XmlElementWrapper(name="dataSet")
	@XmlElement(name="fields")
	private List<Svci00003> ci03 = null;
	public List<Svci00003> getCi03() {
		return ci03;
	}
	public void setCi03(List<Svci00003> ci03) {
		this.ci03 = ci03;
	}

	@XmlElementWrapper(name="dataSet")
	@XmlElement(name="fields")
	private List<Svci00002> ci02 = null;
	public List<Svci00002> getCi02() {
		return ci02;
	}
	public void setCi02(List<Svci00002> ci02) {
		this.ci02 = ci02;
	}

	@XmlElementWrapper(name="dataSet")
	@XmlElement(name="fields")
	private List<Svcs00001> cs01 = null;
	public List<Svcs00001> getCs01() {
		return cs01;
	}
	public void setCs01(List<Svcs00001> cs01) {
		this.cs01 = cs01;
	}

	@XmlElementWrapper(name="dataSet")
	@XmlElement(name="fields")
	private List<Svcs00032> cs32 = null;
	public List<Svcs00032> getCs32() {
		return cs32;
	}
	public void setCs32(List<Svcs00032> cs32) {
		this.cs32 = cs32;
	}



}
