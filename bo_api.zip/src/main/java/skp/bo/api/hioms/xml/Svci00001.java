package skp.bo.api.hioms.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="fields")
public class Svci00001 {

	private String sys_key = "";
	private String svc_id = "";
	private String cust_co_cll_no = "";
	private String cll_cust_co_cd = "";
	private String cll_cust_co_busi_unt_cd = "";
	private String cust_co_apv_no = "";
	private String cll_eno = "";
	private String use_eno = "";
	private String mngm_eno = "";
	private String os_cll_tp_cd = "";
	private String os_cll_kind_cd = "";
	private String cll_dt = "";
	private String hope_dt = "";
	private String strt_dt = "";
	private String end_dt = "";
	private String ice_svc_ds_cd = "";
	private String sw_svc_ds_cd = "";
	private String rtrv_eqp_tag_no = "";
	private String intl_plac_desc = "";
	private String cll_rsn_bdwn = "";
	private String cll_titl = "";
	private String cll_cntn = "";
	private String prc_yn = "";
	private String cll_if_dtm = "";
	private String os_cll_no = "";
	private String agcy_rgs_yn = "";
	private String edms_folder_id = "";
	private String rgsr_emp_id = "";
	private String rgs_dtm = "";
	private String lst_updr_emp_id = "";
	private String lst_updt_dtm = "";
	private String apv_eno = "";
	private String apv_emp_nm = "";
	private String apv_tlno = "";
	private String apv_eml_addr = "";
	private String prc_cust_co_busi_unt_cd = "";
	private String prc_cust_co_cd = "";
	private String sor_tp_lclf_cd = "";
	private String sor_tp_mlf_cd = "";
	private String sor_tp_scl_cd = "";


	public String getSys_key() {
		return sys_key;
	}
	public void setSys_key(String sys_key) {
		this.sys_key = sys_key;
	}
	public String getSvc_id() {
		return svc_id;
	}
	public void setSvc_id(String svc_id) {
		this.svc_id = svc_id;
	}
	public String getCust_co_cll_no() {
		return cust_co_cll_no;
	}
	public void setCust_co_cll_no(String cust_co_cll_no) {
		this.cust_co_cll_no = cust_co_cll_no;
	}
	public String getCll_cust_co_cd() {
		return cll_cust_co_cd;
	}
	public void setCll_cust_co_cd(String cll_cust_co_cd) {
		this.cll_cust_co_cd = cll_cust_co_cd;
	}
	public String getCll_cust_co_busi_unt_cd() {
		return cll_cust_co_busi_unt_cd;
	}
	public void setCll_cust_co_busi_unt_cd(String cll_cust_co_busi_unt_cd) {
		this.cll_cust_co_busi_unt_cd = cll_cust_co_busi_unt_cd;
	}
	public String getCust_co_apv_no() {
		return cust_co_apv_no;
	}
	public void setCust_co_apv_no(String cust_co_apv_no) {
		this.cust_co_apv_no = cust_co_apv_no;
	}
	public String getCll_eno() {
		return cll_eno;
	}
	public void setCll_eno(String cll_eno) {
		this.cll_eno = cll_eno;
	}
	public String getUse_eno() {
		return use_eno;
	}
	public void setUse_eno(String use_eno) {
		this.use_eno = use_eno;
	}
	public String getMngm_eno() {
		return mngm_eno;
	}
	public void setMngm_eno(String mngm_eno) {
		this.mngm_eno = mngm_eno;
	}
	public String getOs_cll_tp_cd() {
		return os_cll_tp_cd;
	}
	public void setOs_cll_tp_cd(String os_cll_tp_cd) {
		this.os_cll_tp_cd = os_cll_tp_cd;
	}
	public String getOs_cll_kind_cd() {
		return os_cll_kind_cd;
	}
	public void setOs_cll_kind_cd(String os_cll_kind_cd) {
		this.os_cll_kind_cd = os_cll_kind_cd;
	}
	public String getCll_dt() {
		return cll_dt;
	}
	public void setCll_dt(String cll_dt) {
		this.cll_dt = cll_dt;
	}
	public String getHope_dt() {
		return hope_dt;
	}
	public void setHope_dt(String hope_dt) {
		this.hope_dt = hope_dt;
	}
	public String getStrt_dt() {
		return strt_dt;
	}
	public void setStrt_dt(String strt_dt) {
		this.strt_dt = strt_dt;
	}
	public String getEnd_dt() {
		return end_dt;
	}
	public void setEnd_dt(String end_dt) {
		this.end_dt = end_dt;
	}
	public String getIce_svc_ds_cd() {
		return ice_svc_ds_cd;
	}
	public void setIce_svc_ds_cd(String ice_svc_ds_cd) {
		this.ice_svc_ds_cd = ice_svc_ds_cd;
	}
	public String getSw_svc_ds_cd() {
		return sw_svc_ds_cd;
	}
	public void setSw_svc_ds_cd(String sw_svc_ds_cd) {
		this.sw_svc_ds_cd = sw_svc_ds_cd;
	}
	public String getRtrv_eqp_tag_no() {
		return rtrv_eqp_tag_no;
	}
	public void setRtrv_eqp_tag_no(String rtrv_eqp_tag_no) {
		this.rtrv_eqp_tag_no = rtrv_eqp_tag_no;
	}
	public String getIntl_plac_desc() {
		return intl_plac_desc;
	}
	public void setIntl_plac_desc(String intl_plac_desc) {
		this.intl_plac_desc = intl_plac_desc;
	}
	public String getCll_rsn_bdwn() {
		return cll_rsn_bdwn;
	}
	public void setCll_rsn_bdwn(String cll_rsn_bdwn) {
		this.cll_rsn_bdwn = cll_rsn_bdwn;
	}
	public String getCll_titl() {
		return cll_titl;
	}
	public void setCll_titl(String cll_titl) {
		this.cll_titl = cll_titl;
	}
	public String getCll_cntn() {
		return cll_cntn;
	}
	public void setCll_cntn(String cll_cntn) {
		this.cll_cntn = cll_cntn;
	}
	public String getPrc_yn() {
		return prc_yn;
	}
	public void setPrc_yn(String prc_yn) {
		this.prc_yn = prc_yn;
	}
	public String getCll_if_dtm() {
		return cll_if_dtm;
	}
	public void setCll_if_dtm(String cll_if_dtm) {
		this.cll_if_dtm = cll_if_dtm;
	}
	public String getOs_cll_no() {
		return os_cll_no;
	}
	public void setOs_cll_no(String os_cll_no) {
		this.os_cll_no = os_cll_no;
	}
	public String getAgcy_rgs_yn() {
		return agcy_rgs_yn;
	}
	public void setAgcy_rgs_yn(String agcy_rgs_yn) {
		this.agcy_rgs_yn = agcy_rgs_yn;
	}
	public String getEdms_folder_id() {
		return edms_folder_id;
	}
	public void setEdms_folder_id(String edms_folder_id) {
		this.edms_folder_id = edms_folder_id;
	}
	public String getRgsr_emp_id() {
		return rgsr_emp_id;
	}
	public void setRgsr_emp_id(String rgsr_emp_id) {
		this.rgsr_emp_id = rgsr_emp_id;
	}
	public String getRgs_dtm() {
		return rgs_dtm;
	}
	public void setRgs_dtm(String rgs_dtm) {
		this.rgs_dtm = rgs_dtm;
	}
	public String getLst_updr_emp_id() {
		return lst_updr_emp_id;
	}
	public void setLst_updr_emp_id(String lst_updr_emp_id) {
		this.lst_updr_emp_id = lst_updr_emp_id;
	}
	public String getLst_updt_dtm() {
		return lst_updt_dtm;
	}
	public void setLst_updt_dtm(String lst_updt_dtm) {
		this.lst_updt_dtm = lst_updt_dtm;
	}
	public String getApv_eno() {
		return apv_eno;
	}
	public void setApv_eno(String apv_eno) {
		this.apv_eno = apv_eno;
	}
	public String getApv_emp_nm() {
		return apv_emp_nm;
	}
	public void setApv_emp_nm(String apv_emp_nm) {
		this.apv_emp_nm = apv_emp_nm;
	}
	public String getApv_tlno() {
		return apv_tlno;
	}
	public void setApv_tlno(String apv_tlno) {
		this.apv_tlno = apv_tlno;
	}
	public String getApv_eml_addr() {
		return apv_eml_addr;
	}
	public void setApv_eml_addr(String apv_eml_addr) {
		this.apv_eml_addr = apv_eml_addr;
	}
	public String getPrc_cust_co_busi_unt_cd() {
		return prc_cust_co_busi_unt_cd;
	}
	public void setPrc_cust_co_busi_unt_cd(String prc_cust_co_busi_unt_cd) {
		this.prc_cust_co_busi_unt_cd = prc_cust_co_busi_unt_cd;
	}
	public String getPrc_cust_co_cd() {
		return prc_cust_co_cd;
	}
	public void setPrc_cust_co_cd(String prc_cust_co_cd) {
		this.prc_cust_co_cd = prc_cust_co_cd;
	}
	public String getSor_tp_lclf_cd() {
		return sor_tp_lclf_cd;
	}
	public void setSor_tp_lclf_cd(String sor_tp_lclf_cd) {
		this.sor_tp_lclf_cd = sor_tp_lclf_cd;
	}
	public String getSor_tp_mlf_cd() {
		return sor_tp_mlf_cd;
	}
	public void setSor_tp_mlf_cd(String sor_tp_mlf_cd) {
		this.sor_tp_mlf_cd = sor_tp_mlf_cd;
	}
	public String getSor_tp_scl_cd() {
		return sor_tp_scl_cd;
	}
	public void setSor_tp_scl_cd(String sor_tp_scl_cd) {
		this.sor_tp_scl_cd = sor_tp_scl_cd;
	}



}
