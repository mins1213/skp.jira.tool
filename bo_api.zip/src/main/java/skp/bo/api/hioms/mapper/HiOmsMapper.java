package skp.bo.api.hioms.mapper;

import java.util.List;

import skp.bo.api.hioms.vo.HiOmsRequestInfoVO;
import skp.bo.api.hioms.vo.HiOmsUserVO;
import skp.bo.api.hioms.vo.ILMpersonInfoVO;

public interface HiOmsMapper {

	public List<HiOmsRequestInfoVO> selectHiomsInfo(HiOmsRequestInfoVO vo) throws Exception;

	public HiOmsRequestInfoVO selectHiomsInfoById(HiOmsRequestInfoVO vo) throws Exception;

//	public Integer selectRequestNumber(String ticketId) throws Exception;

	public void updateRequestInfo(HiOmsRequestInfoVO vo) throws Exception;

	public void insertRequestInfo(HiOmsRequestInfoVO vo) throws Exception;

	public ILMpersonInfoVO selectILMpersonInfo(String empno) throws Exception;

	public List<HiOmsUserVO> selectHiOmsUserList(String userId) throws Exception;
}
