package skp.bo.api.hioms.vo;

public class ILMpersonInfoVO {

	private String empno;
	private String hname;
	private String ename;
	private String regno;
	private String indept;
	private String deptnm;
	private String sosok;
	private String tsosok;
	private String intelno;
	private String movetelno;
	private String email;


	public String getEmpno() {
		return empno;
	}
	public void setEmpno(String empno) {
		this.empno = empno;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getIndept() {
		return indept;
	}
	public void setIndept(String indept) {
		this.indept = indept;
	}
	public String getDeptnm() {
		return deptnm;
	}
	public void setDeptnm(String deptnm) {
		this.deptnm = deptnm;
	}
	public String getSosok() {
		return sosok;
	}
	public void setSosok(String sosok) {
		this.sosok = sosok;
	}
	public String getTsosok() {
		return tsosok;
	}
	public void setTsosok(String tsosok) {
		this.tsosok = tsosok;
	}
	public String getIntelno() {
		return intelno;
	}
	public void setIntelno(String intelno) {
		this.intelno = intelno;
	}
	public String getMovetelno() {
		return movetelno;
	}
	public void setMovetelno(String movetelno) {
		this.movetelno = movetelno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


}
