package skp.bo.api.hioms.vo;

public class HiOmsRequestInfoVO {

	private Integer ticketId;
	private String ticketKey;
	private String requestNumber;
	private String corpGubun;
	private String searchRequestNumber;
	private String requestSendYn;
	private String requestSendDay;
	private String requestUserId;
	private String requestOmsUserId;
	private String requestResultYn;
	private String requestReponse;
	private String requestResultDesc;
	private String createDate;
	private String updateDate;
	private String ifGubun;



	public String getCorpGubun() {
		return corpGubun;
	}
	public void setCorpGubun(String corpGubun) {
		this.corpGubun = corpGubun;
	}
	public String getIfGubun() {
		return ifGubun;
	}
	public void setIfGubun(String ifGubun) {
		this.ifGubun = ifGubun;
	}
	public String getSearchRequestNumber() {
		return searchRequestNumber;
	}
	public void setSearchRequestNumber(String searchRequestNumber) {
		this.searchRequestNumber = searchRequestNumber;
	}
	public String getRequestResultDesc() {
		return requestResultDesc;
	}
	public void setRequestResultDesc(String requestResultDesc) {
		this.requestResultDesc = requestResultDesc;
	}
	public Integer getTicketId() {
		return ticketId;
	}
	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}
	public String getTicketKey() {
		return ticketKey;
	}
	public void setTicketKey(String ticketKey) {
		this.ticketKey = ticketKey;
	}
	public String getRequestNumber() {
		return requestNumber;
	}
	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}
	public String getRequestSendYn() {
		return requestSendYn;
	}
	public void setRequestSendYn(String requestSendYn) {
		this.requestSendYn = requestSendYn;
	}
	public String getRequestSendDay() {
		return requestSendDay;
	}
	public void setRequestSendDay(String requestSendDay) {
		this.requestSendDay = requestSendDay;
	}
	public String getRequestUserId() {
		return requestUserId;
	}
	public void setRequestUserId(String requestUserId) {
		this.requestUserId = requestUserId;
	}
	public String getRequestOmsUserId() {
		return requestOmsUserId;
	}
	public void setRequestOmsUserId(String requestOmsUserId) {
		this.requestOmsUserId = requestOmsUserId;
	}
	public String getRequestResultYn() {
		return requestResultYn;
	}
	public void setRequestResultYn(String requestResultYn) {
		this.requestResultYn = requestResultYn;
	}
	public String getRequestReponse() {
		return requestReponse;
	}
	public void setRequestReponse(String requestReponse) {
		this.requestReponse = requestReponse;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}



}
