package skp.bo.api.hioms.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="fields")
public class Svcs00032 {

	private String sys_key = "";
	private String svc_id = "";
	private String os_cll_no = "";

	public String getSys_key() {
		return sys_key;
	}
	public void setSys_key(String sys_key) {
		this.sys_key = sys_key;
	}
	public String getSvc_id() {
		return svc_id;
	}
	public void setSvc_id(String svc_id) {
		this.svc_id = svc_id;
	}
	public String getOs_cll_no() {
		return os_cll_no;
	}
	public void setOs_cll_no(String os_cll_no) {
		this.os_cll_no = os_cll_no;
	}

}
