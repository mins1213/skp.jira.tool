package skp.bo.api.hioms.xml.Response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="dataSet")
@XmlType(propOrder={"message", "fields"})
public class Svcs00032Res {

	Fields fields;

	public Svcs00032Res(){
		Fields fields = new Fields();
		this.fields = fields;

	}

	private List<ResMessage> message = new ArrayList<ResMessage>();
	public List<ResMessage> getMessage() {
		return message;
	}

	public void setMessage(List<ResMessage> message) {
		this.message = message;
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name="fields")
	public static class Fields{
		private String os_cll_no;
		private String wrk_prc_mpm;
		private String wrk_snct;
		private String stts_cd_nm;
		private String prc_plan_sq2_dscs_dtm;
		private String prc_plan_sq1_dscs_dtm;
		private String wrk_prc_cntn;

		public String getOs_cll_no() {
			return os_cll_no;
		}
		public void setOs_cll_no(String os_cll_no) {
			this.os_cll_no = os_cll_no;
		}
		public String getWrk_prc_mpm() {
			return wrk_prc_mpm;
		}
		public void setWrk_prc_mpm(String wrk_prc_mpm) {
			this.wrk_prc_mpm = wrk_prc_mpm;
		}
		public String getWrk_snct() {
			return wrk_snct;
		}
		public void setWrk_snct(String wrk_snct) {
			this.wrk_snct = wrk_snct;
		}
		public String getStts_cd_nm() {
			return stts_cd_nm;
		}
		public void setStts_cd_nm(String stts_cd_nm) {
			this.stts_cd_nm = stts_cd_nm;
		}
		public String getPrc_plan_sq2_dscs_dtm() {
			return prc_plan_sq2_dscs_dtm;
		}
		public void setPrc_plan_sq2_dscs_dtm(String prc_plan_sq2_dscs_dtm) {
			this.prc_plan_sq2_dscs_dtm = prc_plan_sq2_dscs_dtm;
		}
		public String getPrc_plan_sq1_dscs_dtm() {
			return prc_plan_sq1_dscs_dtm;
		}
		public void setPrc_plan_sq1_dscs_dtm(String prc_plan_sq1_dscs_dtm) {
			this.prc_plan_sq1_dscs_dtm = prc_plan_sq1_dscs_dtm;
		}
		public String getWrk_prc_cntn() {
			return wrk_prc_cntn;
		}
		public void setWrk_prc_cntn(String wrk_prc_cntn) {
			this.wrk_prc_cntn = wrk_prc_cntn;
		}

	}

	public String getOs_cll_no() {
		return this.fields.getOs_cll_no();
	}
	public void setOs_cll_no(String os_cll_no) {
		this.fields.setOs_cll_no(os_cll_no);
	}
	public String getWrk_prc_mpm() {
		return this.fields.getWrk_prc_mpm();
	}
	public void setWrk_prc_mpm(String wrk_prc_mpm) {
		this.fields.setWrk_prc_mpm(wrk_prc_mpm);
	}
	public String getWrk_snct() {
		return this.fields.getWrk_snct();
	}
	public void setWrk_snct(String wrk_snct) {
		this.fields.setWrk_snct(wrk_snct);
	}
	public String getStts_cd_nm() {
		return this.fields.getStts_cd_nm();
	}
	public void setStts_cd_nm(String stts_cd_nm) {
		this.fields.setStts_cd_nm(stts_cd_nm);
	}
	public String getPrc_plan_sq2_dscs_dtm() {
		return this.fields.getPrc_plan_sq2_dscs_dtm();
	}
	public void setPrc_plan_sq2_dscs_dtm(String prc_plan_sq2_dscs_dtm) {
		this.fields.setPrc_plan_sq2_dscs_dtm(prc_plan_sq2_dscs_dtm);
	}
	public String getPrc_plan_sq1_dscs_dtm() {
		return this.fields.getPrc_plan_sq1_dscs_dtm();
	}
	public void setPrc_plan_sq1_dscs_dtm(String prc_plan_sq1_dscs_dtm) {
		this.fields.setPrc_plan_sq1_dscs_dtm(prc_plan_sq1_dscs_dtm);
	}
	public String getWrk_prc_cntn() {
		return this.fields.getWrk_prc_cntn();
	}
	public void setWrk_prc_cntn(String wrk_prc_cntn) {
		this.fields.setWrk_prc_cntn(wrk_prc_cntn);
	}





}
