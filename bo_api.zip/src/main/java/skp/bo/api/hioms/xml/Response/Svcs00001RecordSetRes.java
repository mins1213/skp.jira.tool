package skp.bo.api.hioms.xml.Response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import skp.bo.api.hioms.xml.Response.Svci00001Res.Fields;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="recordSet")
@XmlType(propOrder={"nc_pageNo", "nc_recordCountPerPage","nc_totalRecordCount", "record"})
public class Svcs00001RecordSetRes {

	@XmlAttribute(name="id")
	private String id;

	private String nc_pageNo;
	private String nc_recordCountPerPage;
	private String nc_totalRecordCount;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNc_pageNo() {
		return nc_pageNo;
	}
	public void setNc_pageNo(String nc_pageNo) {
		this.nc_pageNo = nc_pageNo;
	}
	public String getNc_recordCountPerPage() {
		return nc_recordCountPerPage;
	}
	public void setNc_recordCountPerPage(String nc_recordCountPerPage) {
		this.nc_recordCountPerPage = nc_recordCountPerPage;
	}
	public String getNc_totalRecordCount() {
		return nc_totalRecordCount;
	}
	public void setNc_totalRecordCount(String nc_totalRecordCount) {
		this.nc_totalRecordCount = nc_totalRecordCount;
	}

	Record record;
	public Svcs00001RecordSetRes(){
		Record record = new Record();
		this.record = record;

	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlRootElement(name="record")
	public static class Record{
		private String cust_co_cll_no = "";
		private String cll_cust_co_cd = "";
		private String os_cll_tp_cd = "";
		private String os_cll_kind_cd = "";
		private String os_cll_no = "";
		private String cll_emp_nm = "";
		private String hope_dt = "";
		private String cll_titl = "";
		private String err_sno = "";
		private String prc_yn = "";
		private String edms_folder_id = "";

		public String getCust_co_cll_no() {
			return cust_co_cll_no;
		}
		public void setCust_co_cll_no(String cust_co_cll_no) {
			this.cust_co_cll_no = cust_co_cll_no;
		}
		public String getCll_cust_co_cd() {
			return cll_cust_co_cd;
		}
		public void setCll_cust_co_cd(String cll_cust_co_cd) {
			this.cll_cust_co_cd = cll_cust_co_cd;
		}
		public String getOs_cll_tp_cd() {
			return os_cll_tp_cd;
		}
		public void setOs_cll_tp_cd(String os_cll_tp_cd) {
			this.os_cll_tp_cd = os_cll_tp_cd;
		}
		public String getOs_cll_kind_cd() {
			return os_cll_kind_cd;
		}
		public void setOs_cll_kind_cd(String os_cll_kind_cd) {
			this.os_cll_kind_cd = os_cll_kind_cd;
		}
		public String getOs_cll_no() {
			return os_cll_no;
		}
		public void setOs_cll_no(String os_cll_no) {
			this.os_cll_no = os_cll_no;
		}
		public String getCll_emp_nm() {
			return cll_emp_nm;
		}
		public void setCll_emp_nm(String cll_emp_nm) {
			this.cll_emp_nm = cll_emp_nm;
		}
		public String getHope_dt() {
			return hope_dt;
		}
		public void setHope_dt(String hope_dt) {
			this.hope_dt = hope_dt;
		}
		public String getCll_titl() {
			return cll_titl;
		}
		public void setCll_titl(String cll_titl) {
			this.cll_titl = cll_titl;
		}
		public String getErr_sno() {
			return err_sno;
		}
		public void setErr_sno(String err_sno) {
			this.err_sno = err_sno;
		}
		public String getPrc_yn() {
			return prc_yn;
		}
		public void setPrc_yn(String prc_yn) {
			this.prc_yn = prc_yn;
		}
		public String getEdms_folder_id() {
			return edms_folder_id;
		}
		public void setEdms_folder_id(String edms_folder_id) {
			this.edms_folder_id = edms_folder_id;
		}
	}

	public String getCust_co_cll_no() {
		return this.record.getCust_co_cll_no();
	}
	public void setCust_co_cll_no(String cust_co_cll_no) {
		this.record.setCust_co_cll_no(cust_co_cll_no);
	}
	public String getCll_cust_co_cd() {
		return this.record.getCll_cust_co_cd();
	}
	public void setCll_cust_co_cd(String cll_cust_co_cd) {
		this.record.setCll_cust_co_cd(cll_cust_co_cd);
	}
	public String getOs_cll_tp_cd() {
		return this.record.getOs_cll_tp_cd();
	}
	public void setOs_cll_tp_cd(String os_cll_tp_cd) {
		this.record.setOs_cll_tp_cd(os_cll_tp_cd);
	}
	public String getOs_cll_kind_cd() {
		return this.record.getOs_cll_kind_cd();
	}
	public void setOs_cll_kind_cd(String os_cll_kind_cd) {
		this.record.setOs_cll_kind_cd(os_cll_kind_cd);
	}
	public String getOs_cll_no() {
		return this.record.getOs_cll_no();
	}
	public void setOs_cll_no(String os_cll_no) {
		this.record.setOs_cll_no(os_cll_no);
	}
	public String getCll_emp_nm() {
		return this.record.getCll_emp_nm();
	}
	public void setCll_emp_nm(String cll_emp_nm) {
		this.record.setCll_emp_nm(cll_emp_nm);
	}
	public String getHope_dt() {
		return this.record.getHope_dt();
	}
	public void setHope_dt(String hope_dt) {
		this.record.setHope_dt(hope_dt);
	}
	public String getCll_titl() {
		return this.record.getCll_titl();
	}
	public void setCll_titl(String cll_titl) {
		this.record.setCll_titl(cll_titl);
	}
	public String getErr_sno() {
		return this.record.getErr_sno();
	}
	public void setErr_sno(String err_sno) {
		this.record.setErr_sno(err_sno);
	}
	public String getPrc_yn() {
		return this.record.getPrc_yn();
	}
	public void setPrc_yn(String prc_yn) {
		this.record.setPrc_yn(prc_yn);
	}
	public String getEdms_folder_id() {
		return this.record.getEdms_folder_id();
	}
	public void setEdms_folder_id(String edms_folder_id) {
		this.record.setEdms_folder_id(edms_folder_id);
	}


}
